#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
web_viewer.py

A PyQt5 application that embeds a web browser to display
The Ramjet website and supports downloading files without navigation buttons.
"""

import sys
from PyQt5.QtCore import QUrl
from PyQt5.QtWidgets import QApplication, QMainWindow, QFileDialog
from PyQt5.QtWebEngineWidgets import QWebEngineView


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Window settings
        self.setWindowTitle("Ramjet Web Viewer")
        self.resize(1024, 768)

        # Create the browser widget
        self.browser = QWebEngineView()
        self.browser.setUrl(QUrl("https://ramjet.great-site.net"))

        # Set browser as the central widget
        self.setCentralWidget(self.browser)

        # Enable download handling
        profile = self.browser.page().profile()
        profile.downloadRequested.connect(self.on_downloadRequested)

    def on_downloadRequested(self, download):
        # Suggested filename from the download
        suggested_name = download.downloadFileName()
        # Prompt user where to save
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save File As",
            suggested_name
        )
        if path:
            download.setPath(path)
            download.accept()


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
