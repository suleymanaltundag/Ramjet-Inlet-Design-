#!/usr/bin/env python
import os
import glob
import subprocess


def run_cfd_simulations(cfg_dir="cfg files", num_procs=6, simulation_command="SU2_CFD"):
    """
    Runs CFD simulations sequentially for all .cfg files in the specified directory.

    For each .cfg file found in the "cfg files" folder, the script constructs the command:
      mpirun -n <num_procs> SU2_CFD <config_filename>
    and executes it with the working directory set to the cfg folder.

    Parameters:
      cfg_dir (str): Directory containing the .cfg files.
      num_procs (int): Number of processors to use with mpirun.
      simulation_command (str): CFD simulation executable command.
    """
    # Find all .cfg files in the specified directory
    cfg_files = sorted(glob.glob(os.path.join(cfg_dir, "*.cfg")))
    if not cfg_files:
        print(f"No .cfg files found in '{cfg_dir}'.")
        return

    # Process each .cfg file sequentially
    for cfg_file in cfg_files:
        # Get only the basename (e.g., "3.0_0.2_0.2_12.0_0.9.cfg")
        config_filename = os.path.basename(cfg_file)
        print(f"\nStarting simulation for: {config_filename}")

        # Build the command with only the basename of the config file
        command = ["mpirun", "-n", str(num_procs), simulation_command, config_filename]
        print("Executing command:", " ".join(command))

        try:
            # Run the command with the working directory set to cfg_dir
            subprocess.run(command, check=True, cwd=cfg_dir)
            print("CFD simulation completed successfully for:", config_filename)
        except subprocess.CalledProcessError as e:
            print("Error running CFD simulation for:", config_filename)
            print("Error:", e)
            # Optionally, break here if you want to stop on error.
            # break


if __name__ == "__main__":
    run_cfd_simulations()
