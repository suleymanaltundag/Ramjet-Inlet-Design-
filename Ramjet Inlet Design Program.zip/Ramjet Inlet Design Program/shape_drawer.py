#!/usr/bin/env python3
import re
import numpy as np
import pyvista as pv

# --- CONFIGURATION ---
GEO_PATH         = '/home/sulo/PyCharmMiscProject/geo files/3.0_0.2_0.2_0.2_12.0_0.9.geo'  # adjust as needed
REVOLUTION_STEPS = 180                            # angular resolution
SOLID_COLOR      = 'lightsteelblue'               # mesh color

# --- 1) Parse .geo: numeric variables & "wall" IDs ---
variables = {}
wall_line_ids = []
with open(GEO_PATH, 'r') as f:
    for line in f:
        s = line.strip()
        mv = re.match(r'([A-Za-z_]\w*)\s*=\s*([+-]?\d+(\.\d*)?([eE][+-]?\d+)?);', s)
        if mv:
            variables[mv.group(1)] = float(mv.group(2))
        if 'Physical Curve("wall")' in s:
            wall_line_ids = [int(x) for x in re.search(r'\{([^}]+)\}', s).group(1).split(',')]

# --- 2) Read Points & Lines ---
points = {}
lines = {}
with open(GEO_PATH, 'r') as f:
    for line in f:
        s = line.strip()
        mpt = re.match(r'Point\((\d+)\)\s*=\s*\{([^}]+)\}', s)
        if mpt:
            pid = int(mpt.group(1))
            exprs = mpt.group(2).split(',')[:3]
            points[pid] = [eval(e, {}, variables) for e in exprs]
            continue
        mln = re.match(r'Line\((\d+)\)\s*=\s*\{(\d+),\s*(\d+)\}', s)
        if mln:
            lid, p1, p2 = map(int, mln.groups())
            lines[lid] = (p1, p2)

# --- 3) Build ordered chain of the wall profile ---
sorted_ids = sorted(wall_line_ids)
a, b = lines[sorted_ids[0]]
chain = [a, b]
for lid in sorted_ids[1:]:
    u, v = lines[lid]
    chain.append(v if chain[-1] == u else u)

# --- 4) Extract (x,y) and extend last point to x_max_global ---
xy = np.array([points[p][:2] for p in chain])
x_vals = xy[:,0].copy()
y_vals = xy[:,1].copy()
x_max_global = max(pt[0] for pt in points.values())
if x_vals[-1] < x_max_global:
    x_vals = np.append(x_vals, x_max_global)
    y_vals = np.append(y_vals, y_vals[-1])

# Determine inner (smallest) and outer (largest) end radii
inner_radius = min(y_vals)
outer_radius = max(y_vals)

# --- 5) Revolve profile into a single mesh (no auto-capping) ---
# Build profile in Y–Z plane so extrude_rotate spins around Z
pts3d = np.column_stack([
    np.zeros_like(x_vals),  # X=0
    y_vals,                 # Y=radius
    x_vals                  # Z=height
])
profile = pv.PolyData(pts3d)
profile.lines = np.hstack([[len(pts3d)], np.arange(len(pts3d))])
mesh = profile.extrude_rotate(
    angle=360.0,
    resolution=REVOLUTION_STEPS,
    capping=False
)
# Remap axes: (X,Y,Z)->(Z,X,Y) to make it an X-axis revolution
pts = mesh.points.copy()
mesh.points = np.column_stack([pts[:,2], pts[:,0], pts[:,1]])

# --- 6) Build caps at x_max_global ---
phi = np.linspace(0, 2*np.pi, REVOLUTION_STEPS)

# 6a) Inner disk (smallest circle)
inner_pts = np.column_stack([
    np.full_like(phi, x_max_global),
    inner_radius * np.cos(phi),
    inner_radius * np.sin(phi)
])
inner_cap = pv.PolyData(inner_pts)
inner_cap.faces = np.hstack([[len(phi)], np.arange(len(phi))])

# 6b) Annular ring between inner_radius and outer_radius
outer_pts = np.column_stack([
    np.full_like(phi, x_max_global),
    outer_radius * np.cos(phi),
    outer_radius * np.sin(phi)
])
ring_pts = np.vstack([outer_pts, inner_pts])
n = len(phi)
faces = []
for i in range(n):
    o0 = i
    o1 = (i+1) % n
    i0 = n + i
    i1 = n + o1
    faces.append([4, o0, o1, i1, i0])
faces = np.hstack(faces)
ring_cap = pv.PolyData(ring_pts, faces)

# --- 7) Combine mesh and caps ---
mesh_total = mesh
mesh_total += inner_cap
mesh_total += ring_cap

# --- 8) Render as a true solid ---
plotter = pv.Plotter(window_size=(900,600))
plotter.add_mesh(mesh_total,
                 color=SOLID_COLOR,
                 smooth_shading=True,
                 specular=0.4,
                 specular_power=20,
                 ambient=0.25,
                 diffuse=0.75,
                 opacity=1.0)
plotter.add_light(pv.Light(position=(1,1,1), focal_point=(0,0,0)))
plotter.add_axes(interactive=True)
plotter.set_background('white')
plotter.show(title='Solid Axisymmetric with Inner Disk, Gap, and Outer Ring Cap')
