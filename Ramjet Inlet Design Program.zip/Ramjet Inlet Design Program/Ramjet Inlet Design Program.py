#!/usr/bin/env python3
import os
import sys
import glob
import subprocess
import threading
import time
import signal
import shutil
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox, simpledialog
import pandas as pd
import numpy as np
import joblib
import re
import pyvista as pv
import logging
import platform
from uuid import uuid4

from sklearn.model_selection import KFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputRegressor
from xgboost import XGBRegressor

import combined  # for filtering & analysis pipelines
from project_ml_gui import (
    load_data, get_id, run_point_calculator, move_result_files,
    run_cfd, check_convergence, calc_errors, calc_prc_error,
    add_current_analysis_to_training, open_vtu
)

def format_time(seconds):
    """Format seconds into a human-readable string."""
    if seconds < 0:
        seconds = 0
    m = int(seconds // 60)
    s = int(seconds % 60)
    if m < 60:
        return f"{m} min {s} sec"
    h = m // 60
    m = m % 60
    return f"{h} hr {m} min {s} sec"

def get_cfg_filename(rn, M, ramp_len, angle, bp):
    """
    Construct the expected .cfg filename from parameters.
    e.g. M_rampLen_repeated_theta_bp.cfg
    """
    M_str = str(M)
    angle_str = str(angle)
    back_p = str(bp)
    try:
        count = int(rn)
        name_parts = [str(ramp_len)] * count
    except:
        name_parts = [str(ramp_len)]
    name_2 = "_".join(name_parts)
    return f"{M_str}_{name_2}_{angle_str}_{back_p}.cfg"

def draw_3d_shape(geo_path):
    """
    Parse the .geo file at geo_path, build an axisymmetric 3D mesh,
    and display it with pyvista.
    """
    # Configuration
    REVOLUTION_STEPS = 180
    SOLID_COLOR = 'lightsteelblue'

    # 1) Parse variables & Physical Curve("wall") line IDs
    variables = {}
    wall_line_ids = []
    with open(geo_path, 'r') as f:
        for line in f:
            s = line.strip()
            mv = re.match(r'([A-Za-z_]\w*)\s*=\s*([+-]?\d+(\.\d*)?([eE][+-]?\d+)?);', s)
            if mv:
                variables[mv.group(1)] = float(mv.group(2))
            if 'Physical Curve("wall")' in s:
                wall_line_ids = [int(x) for x in re.search(r'\{([^}]+)\}', s).group(1).split(',')]

    # 2) Read Points & Lines
    points = {}
    lines = {}
    with open(geo_path, 'r') as f:
        for line in f:
            s = line.strip()
            mpt = re.match(r'Point\((\d+)\)\s*=\s*\{([^}]+)\}', s)
            if mpt:
                pid = int(mpt.group(1))
                exprs = mpt.group(2).split(',')[:3]
                points[pid] = [eval(e, {}, variables) for e in exprs]
                continue
            mln = re.match(r'Line\((\d+)\)\s*=\s*\{(\d+),\s*(\d+)\}', s)
            if mln:
                lid, p1, p2 = map(int, mln.groups())
                lines[lid] = (p1, p2)

    # 3) Build ordered chain of the wall profile
    sorted_ids = sorted(wall_line_ids)
    a, b = lines[sorted_ids[0]]
    chain = [a, b]
    for lid in sorted_ids[1:]:
        u, v = lines[lid]
        chain.append(v if chain[-1] == u else u)

    # 4) Extract (x,y) and extend last point to x_max_global
    xy = np.array([points[p][:2] for p in chain])
    x_vals = xy[:, 0].copy()
    y_vals = xy[:, 1].copy()
    x_max_global = max(pt[0] for pt in points.values())
    if x_vals[-1] < x_max_global:
        x_vals = np.append(x_vals, x_max_global)
        y_vals = np.append(y_vals, y_vals[-1])

    inner_radius = min(y_vals)
    outer_radius = max(y_vals)

    # 5) Revolve profile into a single mesh (no auto-capping)
    pts3d = np.column_stack([
        np.zeros_like(x_vals),  # X=0
        y_vals,  # Y=radius
        x_vals  # Z=height
    ])
    profile = pv.PolyData(pts3d)
    profile.lines = np.hstack([[len(pts3d)], np.arange(len(pts3d))])
    mesh = profile.extrude_rotate(
        angle=360.0,
        resolution=REVOLUTION_STEPS,
        capping=False
    )
    # Remap axes: (X,Y,Z)->(Z,X,Y)
    pts = mesh.points.copy()
    mesh.points = np.column_stack([pts[:, 2], pts[:, 0], pts[:, 1]])

    # 6) Build caps at x_max_global
    phi = np.linspace(0, 2 * np.pi, REVOLUTION_STEPS)
    # Inner cap
    inner_pts = np.column_stack([
        np.full_like(phi, x_max_global),
        inner_radius * np.cos(phi),
        inner_radius * np.sin(phi)
    ])
    inner_cap = pv.PolyData(inner_pts)
    inner_cap.faces = np.hstack([[len(phi)], np.arange(len(phi))])
    # Outer ring cap
    outer_pts = np.column_stack([
        np.full_like(phi, x_max_global),
        outer_radius * np.cos(phi),
        outer_radius * np.sin(phi)
    ])
    ring_pts = np.vstack([outer_pts, inner_pts])
    n = len(phi)
    faces = []
    for i in range(n):
        o0 = i
        o1 = (i + 1) % n
        i0 = n + i
        i1 = n + o1
        faces.append([4, o0, o1, i1, i0])
    faces = np.hstack(faces)
    ring_cap = pv.PolyData(ring_pts, faces)

    # 7) Combine mesh and caps
    mesh_total = mesh
    mesh_total += inner_cap
    mesh_total += ring_cap

    # 8) Render
    plotter = pv.Plotter(window_size=(900, 600))
    plotter.add_mesh(mesh_total,
                     color=SOLID_COLOR,
                     smooth_shading=True,
                     specular=0.4,
                     specular_power=20,
                     ambient=0.25,
                     diffuse=0.75,
                     opacity=1.0)
    plotter.add_light(pv.Light(position=(1, 1, 1), focal_point=(0, 0, 0)))
    plotter.add_axes(interactive=True)
    plotter.set_background('white')
    plotter.show(title=f'3D Shape: {os.path.basename(geo_path)}')

def open_folder(path):
    """Open a folder in the system's default file explorer."""
    try:
        os.makedirs(path, exist_ok=True)
        logging.info(f"Created/opened folder: {path}")
        system = platform.system()
        if system == "Windows":
            subprocess.run(["explorer", path.replace("/", "\\")])
        elif system == "Darwin":  # macOS
            subprocess.run(["open", path])
        elif system == "Linux":
            subprocess.run(["xdg-open", path])
        else:
            raise OSError(f"Unsupported platform: {system}")
        return True
    except Exception as e:
        logging.error(f"Failed to open folder {path}: {str(e)}")
        return False

def open_csv_file(path):
    """Open a CSV file with the system's default application."""
    try:
        if not os.path.exists(path):
            raise FileNotFoundError(f"File {path} does not exist")
        logging.info(f"Opening CSV file: {path}")
        system = platform.system()
        if system == "Windows":
            os.startfile(path)
        elif system == "Darwin":  # macOS
            subprocess.run(["open", path])
        elif system == "Linux":
            subprocess.run(["xdg-open", path])
        else:
            raise OSError(f"Unsupported platform: {system}")
        return True
    except Exception as e:
        logging.error(f"Failed to open CSV file {path}: {str(e)}")
        return False

class SettingsChoiceDialog(tk.Toplevel):
    """Custom dialog to choose between mesh quality, geo file templates, checked data file, web viewer, or altitude."""
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Settings Options")
        self.geometry("400x350")
        self.resizable(False, False)
        self.choice = None

        # Center the dialog relative to parent
        self.transient(parent)
        self.grab_set()

        # Main frame
        frame = ttk.Frame(self, padding=20)
        frame.pack(fill="both", expand=True)

        # Question label
        ttk.Label(frame, text="What would you like to do?", font=('Arial', 12, 'bold')).pack(pady=10)

        # Buttons
        ttk.Button(frame, text="Change Mesh Quality", command=self.choose_mesh, style='Accent.TButton').pack(fill="x", pady=5)
        ttk.Button(frame, text="Change Geo File Templates", command=self.choose_geo, style='Accent.TButton').pack(fill="x", pady=5)
        ttk.Button(frame, text="Update Checked Data File", command=self.choose_checked_data, style='Accent.TButton').pack(fill="x", pady=5)
        ttk.Button(frame, text="Download/Upload data.csv from Web", command=self.choose_web_viewer, style='Accent.TButton').pack(fill="x", pady=5)
        ttk.Button(frame, text="Change Altitude", command=self.choose_altitude, style='Accent.TButton').pack(fill="x", pady=5)
        ttk.Button(frame, text="Cancel", command=self.cancel, style='TButton').pack(fill="x", pady=5)

    def choose_mesh(self):
        self.choice = "mesh"
        self.destroy()

    def choose_geo(self):
        self.choice = "geo"
        self.destroy()

    def choose_checked_data(self):
        self.choice = "checked_data"
        self.destroy()

    def choose_web_viewer(self):
        self.choice = "web_viewer"
        self.destroy()

    def choose_altitude(self):
        self.choice = "altitude"
        self.destroy()

    def cancel(self):
        self.choice = None
        self.destroy()

class MainApp(tk.Tk):
    def __init__(self):
        super().__init__()
        # Setup logging
        logging.basicConfig(filename='gui.log', level=logging.ERROR,
                            format='%(asctime)s - %(levelname)s - %(message)s')
        try:
            self.title("Ramjet Calculator GUI")
            self.geometry("1200x850")
            self.minsize(1000, 650)
            self.style = ttk.Style()
            self.style.theme_use('clam')
            self.style.configure('TButton', padding=8, font=('Arial', 11), background='#add8e6', foreground='black')
            self.style.configure('TLabel', font=('Arial', 12))
            self.style.configure('TLabelFrame', font=('Arial', 13, 'bold'))
            self.style.configure('Accent.TButton', font=('Arial', 12, 'bold'), background='#28a745', foreground='white', width=30)
            self.style.configure('Header.TLabel', font=('Arial', 16, 'bold'))
            self.style.configure('Subheader.TLabel', font=('Arial', 14))
            self.altitude = 10000  # Default altitude

            container = ttk.Frame(self)
            container.pack(fill="both", expand=True, padx=15, pady=15)
            container.columnconfigure(0, weight=1)
            container.rowconfigure(0, weight=1)

            self.frames = {}
            for Page in (HomePage, OperationPage, SolveCFDPage, FilterPage, MLPage, SettingsPage, AltitudePage):
                self.frames[Page] = Page(parent=container, controller=self)
                self.frames[Page].grid(row=0, column=0, sticky="nsew")

            self.show_frame(HomePage)
        except Exception as e:
            logging.error(f"MainApp initialization failed: {str(e)}")
            raise

    def show_frame(self, page):
        try:
            self.frames[page].tkraise()
        except Exception as e:
            logging.error(f"Failed to show frame {page.__name__}: {str(e)}")
            raise

class HomePage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(padding=25)
        # Header with icon
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 15))
        # Placeholder for logo
        # TODO: Add image 'ramjet_logo.png' (e.g., logo_img = tk.PhotoImage(file='ramjet_logo.png'); ttk.Label(header_frame, image=logo_img).pack())
        ttk.Label(header_frame, text="Ramjet Calculator", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Choose what you would like to do.", style='Subheader.TLabel').pack(pady=5)

        # Buttons with icon placeholders
        button_frame = ttk.Frame(self)
        button_frame.pack(fill="x", padx=40)
        buttons = [
            ("Solve CFD with Custom Parameters", lambda: controller.show_frame(OperationPage), "cfd_icon.png"),
            ("Work with Trained ML Model", lambda: (
                controller.frames[MLPage].set_mode('existing'),
                controller.frames[MLPage].set_back_target(HomePage),
                controller.show_frame(MLPage)
            ), "ml_icon.png"),
            ("Adjust Settings", lambda: self.open_settings(), "settings_icon.png")
        ]
        for text, cmd, icon in buttons:
            btn_frame = ttk.Frame(button_frame)
            btn_frame.pack(fill="x", pady=10)
            # TODO: Add icon (e.g., icon_img = tk.PhotoImage(file='icon); ttk.Label(btn_frame, image=icon_img).pack(side="left", padx=5))
            ttk.Button(btn_frame, text=text, command=cmd, style='Accent.TButton').pack(padx=10)
        # Footer
        ttk.Label(self, text="Version 1.0 | Developed by Yunus & Süleyman", font=("Arial", 12, "italic")).pack(
            side="bottom", pady=15)

    def open_settings(self):
        """Prompt user to choose between mesh quality settings, .geo file templates, checked data file, web viewer, or altitude."""
        dialog = SettingsChoiceDialog(self)
        self.wait_window(dialog)
        if dialog.choice == "mesh":
            self.controller.show_frame(SettingsPage)
        elif dialog.choice == "geo":
            geo_folder = os.path.join(os.getcwd(), "geo file template")
            if open_folder(geo_folder):
                messagebox.showinfo("Folder Opened", f"Opened folder: {geo_folder}")
            else:
                messagebox.showerror("Error", f"Failed to open folder: {geo_folder}")
        elif dialog.choice == "checked_data":
            csv_file = os.path.join(os.getcwd(), "csv files", "checked_data.csv")
            if open_csv_file(csv_file):
                messagebox.showinfo("File Opened", f"Opened file: {csv_file}")
            else:
                messagebox.showerror("Error", f"Failed to open file: {csv_file}")
        elif dialog.choice == "web_viewer":
            try:
                subprocess.run(["python", "web_viewer.py"], check=True)
                messagebox.showinfo("Success", "Web viewer launched successfully.")
            except subprocess.CalledProcessError as e:
                messagebox.showerror("Error", f"Failed to launch web viewer: {str(e)}")
            except FileNotFoundError:
                messagebox.showerror("Error", "web_viewer.py not found in the current directory.")
        elif dialog.choice == "altitude":
            self.controller.show_frame(AltitudePage)

class OperationPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.configure(padding=25)
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 15))
        # Placeholder for workflow icon
        # TODO: Add image 'workflow_icon.png' (e.g., icon_img = tk.PhotoImage(file='workflow_icon.png'); ttk.Label(header_frame, image=icon_img).pack())
        ttk.Label(header_frame, text="CFD Workflow Options", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Select a workflow to proceed", style='Subheader.TLabel').pack(pady=5)

        # Buttons
        button_frame = ttk.Frame(self)
        button_frame.pack(fill="x", padx=50)
        buttons = [
            ("Solve CFD Simulations", lambda: controller.show_frame(SolveCFDPage), "simulation_icon.png"),
            ("Filter CFD Data", lambda: controller.show_frame(FilterPage), "filter_icon.png"),
            ("Train & Run ML Model", lambda: (
                controller.frames[MLPage].set_mode('fresh'),
                controller.frames[MLPage].set_back_target(OperationPage),
                controller.show_frame(MLPage)
            ), "ml_train_icon.png")
        ]
        for text, cmd, icon in buttons:
            btn_frame = ttk.Frame(button_frame)
            btn_frame.pack(fill="x", pady=8)
            # TODO: Add icon (e.g., icon_img = tk.PhotoImage(file='icon); ttk.Label(btn_frame, image=icon_img).pack(side="left", padx=5))
            ttk.Button(btn_frame, text=text, command=cmd, style='Accent.TButton').pack(padx=10)
        # Back button
        ttk.Button(button_frame, text="← Back to Home", command=lambda: controller.show_frame(HomePage),
                   style='TButton').pack(pady=20)

class SolveCFDPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(padding=25)
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 10))
        # Placeholder for CFD icon
        # TODO: Add image 'cfd_simulation.png' (e.g., icon_img = tk.PhotoImage(file='cfd_simulation.png'); ttk.Label(header_frame, image=icon_img).pack())
        ttk.Label(header_frame, text="Solve CFD with Parameters", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Configure and run CFD simulations", style='Subheader.TLabel').pack(pady=5)

        # Parameters
        param_frame = ttk.LabelFrame(self, text="Input Parameters", padding=15)
        param_frame.pack(fill="x", padx=15, pady=10)
        params = [
            ("Back-pressure constant (comma separated):", "0.9", "bp_entry"),
            ("Mach values (comma separated):", "3", "mach_entry"),
            ("Ramp lengths (comma separated):", "0.2", "ramp_length_entry"),
            ("Theta angles (comma separated):", "12", "theta_entry"),
            ("Ramp numbers (comma separated):", "2,3,4,5", "ramp_nums_entry")
        ]
        for i, (label, default, attr) in enumerate(params):
            ttk.Label(param_frame, text=label).grid(row=i, column=0, sticky="w", padx=8, pady=8)
            entry = ttk.Entry(param_frame, font=('Arial', 11))
            entry.insert(0, default)
            entry.grid(row=i, column=1, sticky="ew", padx=8, pady=8)
            setattr(self, attr, entry)
        param_frame.columnconfigure(1, weight=1)

        # Progress
        progress_frame = ttk.LabelFrame(self, text="Simulation Progress", padding=15)
        progress_frame.pack(fill="x", padx=15, pady=10)
        progress_items = [
            ("CFG File Creation Progress:", "cfg_progress", "cfg_percent_label", "cfg_time_label"),
            ("CFD Simulation Progress:", "cfd_progress", "cfd_percent_label", "cfd_time_label")
        ]
        for i, (label, prog_attr, percent_attr, time_attr) in enumerate(progress_items):
            ttk.Label(progress_frame, text=label).grid(row=i, column=0, sticky="w", padx=8, pady=8)
            progress_bar = ttk.Progressbar(progress_frame, orient="horizontal", length=450, mode="determinate")
            progress_bar.grid(row=i, column=1, sticky="ew", padx=8, pady=8)
            percent_label = ttk.Label(progress_frame, text="0%")
            percent_label.grid(row=i, column=2, padx=12)
            time_label = ttk.Label(progress_frame, text="")
            time_label.grid(row=i, column=3, padx=12)
            setattr(self, prog_attr, progress_bar)
            setattr(self, percent_attr, percent_label)
            setattr(self, time_attr, time_label)
        progress_frame.columnconfigure(1, weight=1)

        # Controls
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=15, pady=10)
        self.start_button = ttk.Button(btn_frame, text="Start Simulation", command=self.start_process,
                                       style='Accent.TButton')
        self.start_button.pack(side="left", padx=8)
        self.hold_button = ttk.Button(btn_frame, text="Pause", command=self.toggle_pause, style='TButton')
        self.hold_button.pack(side="left", padx=8)
        self.cancel_button = ttk.Button(btn_frame, text="Cancel", command=self.cancel_process, style='TButton')
        self.cancel_button.pack(side="left", padx=8)
        self.erase_button = ttk.Button(btn_frame, text="Erase Files", command=self.erase_files, style='TButton')
        self.erase_button.pack(side="left", padx=8)
        ttk.Button(btn_frame, text="← Back", command=lambda: controller.show_frame(OperationPage),
                   style='TButton').pack(side="left", padx=8)

        # Log
        log_frame = ttk.LabelFrame(self, text="Simulation Log", padding=15)
        log_frame.pack(fill="both", expand=True, padx=15, pady=10)
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap="word", state="disabled", height=12,
                                                  font=('Courier', 11))
        self.log_text.pack(fill="both", expand=True)

        # Internal state
        self.cancelled = False
        self.paused = False
        self.stage_pause_duration = 0
        self.current_proc = None
        self.current_command = None

    def log(self, message):
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

    def erase_files(self):
        if messagebox.askyesno("Confirm Erase",
                               "Are you sure you want to delete all files in 'geo files' and 'cfg files'?"):
            for d in ["geo files", "cfg files"]:
                if os.path.exists(d):
                    for f in os.listdir(d):
                        p = os.path.join(d, f)
                        if os.path.isfile(p):
                            try:
                                os.remove(p)
                                self.log(f"Removed file: {p}")
                            except Exception as e:
                                self.log(f"Error removing {p}: {e}")
                else:
                    self.log(f"Directory '{d}' does not exist.")
        else:
            self.log("Erase files cancelled by user.")

    def update_progress(self, progress_bar, percent_label, time_label, current, total, start_t):
        pct = int((current / total) * 100)
        progress_bar["value"] = current
        percent_label.config(text=f"{pct}%")
        elapsed = time.time() - start_t - self.stage_pause_duration
        time_label.config(text=format_time(elapsed))

    def toggle_pause(self):
        if not self.paused:
            self.paused = True
            self.pause_start = time.time()
            self.hold_button.config(text="Resume")
            if self.current_proc and self.current_command and "SU2_CFD" in " ".join(self.current_command):
                try:
                    os.killpg(self.current_proc.pid, signal.SIGSTOP)
                except:
                    pass
            self.log("Process paused.")
        else:
            self.paused = False
            self.stage_pause_duration += time.time() - self.pause_start
            self.hold_button.config(text="Pause")
            if self.current_proc and self.current_command and "SU2_CFD" in " ".join(self.current_command):
                try:
                    os.killpg(self.current_proc.pid, signal.SIGCONT)
                except:
                    pass
            self.log("Process resumed.")

    def cancel_process(self):
        self.cancelled = True
        self.log("Cancellation requested.")
        if self.current_proc:
            try:
                self.current_proc.kill()
                self.log("Terminated running subprocess.")
            except Exception as e:
                self.log(f"Error terminating subprocess: {e}")

    def wait_if_paused(self):
        while self.paused:
            self.update()
            time.sleep(0.1)

    def start_process(self):
        # reset UI & state
        self.cancelled = False
        self.paused = False
        self.stage_pause_duration = 0
        self.current_proc = None
        self.current_command = None

        self.cfg_progress["value"] = 0
        self.cfd_progress["value"] = 0
        self.cfg_percent_label.config(text="0%")
        self.cfd_percent_label.config(text="0%")
        self.cfg_time_label.config(text="")
        self.cfd_time_label.config(text="")
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", tk.END)
        self.log_text.configure(state="disabled")

        self.current_cfg_iteration = 0
        self.current_cfd_iteration = 0

        threading.Thread(target=self.run_process, daemon=True).start()

    def run_process(self):
        # parse parameters
        try:
            bp_values = [float(x.strip()) for x in self.bp_entry.get().split(",")]
            mach_values = [float(x.strip()) for x in self.mach_entry.get().split(",")]
            ramp_lengths = [float(x.strip()) for x in self.ramp_length_entry.get().split(",")]
            theta_angles = [float(x.strip()) for x in self.theta_entry.get().split(",")]
            ramp_nums = [x.strip() for x in self.ramp_nums_entry.get().split(",")]
        except Exception as e:
            self.log("Error parsing parameters: " + str(e))
            return

        altitude = self.controller.altitude
        equal_ramps = "Y"
        ml_flag = "No"

        # CFG generation
        total_cfg = len(ramp_nums) * len(mach_values) * len(ramp_lengths) * len(theta_angles) * len(bp_values)
        self.cfg_progress["maximum"] = total_cfg
        cfg_start = time.time()

        for rn in ramp_nums:
            for mach in mach_values:
                for rl in ramp_lengths:
                    for th in theta_angles:
                        for bp in bp_values:
                            self.wait_if_paused()
                            if self.cancelled:
                                self.log("Process cancelled during CFG generation.")
                                return
                            input_str = f"{rn}\n{mach}\n{altitude}\n{equal_ramps}\n{rl}\n{th}\n{bp}\n{ml_flag}\n"
                            self.log("---------------------------------------------------")
                            self.log(
                                f"Running point calculator: Ramp={rn}, Mach={mach}, RampLen={rl}, Theta={th}, BP={bp}, Altitude={altitude}")
                            try:
                                self.current_proc = subprocess.Popen(
                                    ["python", "point calculator.py"],
                                    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, text=True
                                )
                                self.current_proc.stdin.write(input_str)
                                self.current_proc.stdin.flush()
                                while self.current_proc.poll() is None:
                                    self.wait_if_paused()
                                    if self.cancelled:
                                        self.current_proc.kill()
                                        self.log("Point calculator subprocess cancelled.")
                                        break
                                    time.sleep(0.1)
                                out, err = self.current_proc.communicate(timeout=1)
                            except Exception as e:
                                self.log(f"Subprocess error: {e}")
                            finally:
                                self.current_proc = None

                            # expected .cfg file
                            cfg_name = get_cfg_filename(rn, mach, rl, th, bp)
                            cfg_path = os.path.join("cfg files", cfg_name)
                            if os.path.exists(cfg_path):
                                self.log(f"Generated cfg file: {cfg_path}")
                            else:
                                self.log(f"WARNING: Expected .cfg file not found: {cfg_path}")

                            self.current_cfg_iteration += 1
                            self.update_progress(self.cfg_progress, self.cfg_percent_label,
                                                 self.cfg_time_label, self.current_cfg_iteration,
                                                 total_cfg, cfg_start)

        self.log("CFG file generation completed.")

        # CFD simulations
        cfg_files = sorted(glob.glob(os.path.join("cfg files", "*.cfg")))
        if not cfg_files:
            self.log("No .cfg files found for CFD simulations.")
            return

        self.total_cfd_iterations = len(cfg_files)
        self.cfd_progress["maximum"] = self.total_cfd_iterations
        cfd_start = time.time()
        self.stage_pause_duration = 0

        for cfg_file in cfg_files:
            self.wait_if_paused()
            if self.cancelled:
                self.log("Process cancelled during CFD simulations.")
                return
            fname = os.path.basename(cfg_file)
            self.log(f"Starting simulation for: {fname}")
            command = ["mpirun", "-n", "6", "SU2_CFD", fname]
            self.log("Executing command: " + " ".join(command))
            self.current_command = command
            try:
                self.current_proc = subprocess.Popen(
                    command,
                    cwd="cfg files",
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    preexec_fn=os.setsid
                )
                while True:
                    self.wait_if_paused()
                    if self.cancelled:
                        self.current_proc.kill()
                        self.log("CFD subprocess cancelled.")
                        break
                    line = self.current_proc.stdout.readline()
                    if line:
                        self.log(line.strip())
                    if line == "" and self.current_proc.poll() is not None:
                        break
                self.current_proc.wait()
            except Exception as e:
                self.log(f"Error running CFD for {fname}: {e}")
            finally:
                self.current_proc = None

            self.log(f"CFD completed for: {fname}")
            self.current_cfd_iteration += 1
            self.update_progress(self.cfd_progress, self.cfd_percent_label,
                                 self.cfd_time_label, self.current_cfd_iteration,
                                 self.total_cfd_iterations, cfd_start)

        self.log("All CFD simulations completed.")

class FilterPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.configure(padding=25)
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 10))
        # Placeholder for filter icon
        # TODO: Add image 'filter_data.png' (e.g., icon_img = tk.PhotoImage(file='filter_data.png'); ttk.Label(header_frame, image=icon_img).pack())
        ttk.Label(header_frame, text="Filter CFD Data", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Apply filters to refine CFD results", style='Subheader.TLabel').pack(pady=5)

        # Input frame
        input_frame = ttk.LabelFrame(self, text="Filter Thresholds", padding=15)
        input_frame.pack(fill="x", padx=15, pady=10)
        fields = [
            ("Min Mach:", "0.1", "min_mach"),
            ("Max Mach:", "0.8", "max_mach"),
            ("Min Massflow:", "0.1", "min_mass"),
            ("Max Massflow:", "1000", "max_mass")
        ]
        for i, (label, default, attr) in enumerate(fields):
            ttk.Label(input_frame, text=label).grid(row=i // 2, column=(i % 2) * 2, sticky="e", padx=8, pady=8)
            entry = ttk.Entry(input_frame, font=('Arial', 11))
            entry.insert(0, default)
            entry.grid(row=i // 2, column=(i % 2) * 2 + 1, sticky="w", padx=8, pady=8)
            setattr(self, attr, entry)
        input_frame.columnconfigure(1, weight=1)
        input_frame.columnconfigure(3, weight=1)

        # Buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=15, pady=10)
        self.filter_btn = ttk.Button(btn_frame, text="Apply Filters", command=self.start_filter, style='Accent.TButton')
        self.filter_btn.pack(side="left", padx=8)
        self.update_btn = ttk.Button(btn_frame, text="Update Data File With Checked Data", command=self.update_data_file, style='TButton')
        self.update_btn.pack(side="left", padx=8)
        ttk.Button(btn_frame, text="← Back", command=lambda: controller.show_frame(OperationPage),
                   style='TButton').pack(side="left", padx=8)

        # Log
        log_frame = ttk.LabelFrame(self, text="Filter Log", padding=15)
        log_frame.pack(fill="both", expand=True, padx=15, pady=10)
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap="word", state="disabled", height=12,
                                                  font=('Courier', 11))
        self.log_text.pack(fill="both", expand=True)

    def log(self, msg):
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, msg + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

    def start_filter(self):
        try:
            self.thresholds = {
                'min_mach': float(self.min_mach.get()),
                'max_mach': float(self.max_mach.get()),
                'min_mass': float(self.min_mass.get()),
                'max_mass': float(self.max_mass.get())
            }
        except ValueError:
            messagebox.showerror("Invalid input", "Please enter numeric thresholds.")
            return
        self.filter_btn.config(state="disabled")
        threading.Thread(target=self.run_filter_pipeline, daemon=True).start()

    def run_filter_pipeline(self):
        csv_folder = "csv files"
        os.makedirs(csv_folder, exist_ok=True)

        for suffix, apply_prc in (("single_type", True), ("many_type", False)):
            dst_data = os.path.join(csv_folder, f"data_{suffix}.csv")
            dst_div = os.path.join(csv_folder, f"diverged_{suffix}.csv")

            self.log(f"\n=== Running full pipeline (suffix='{suffix}') ===")
            self.log("• collect_results()")
            combined.collect_results()
            shutil.move(os.path.join(csv_folder, "data.csv"), dst_data)
            shutil.move(os.path.join(csv_folder, "diverged.csv"), dst_div)

            shutil.copy(dst_data, os.path.join(csv_folder, "data.csv"))
            self.log("• remove_mach_outlier_rows()")
            combined.remove_mach_outlier_rows()
            self.log("• remove_massflow_outlier_rows()")
            combined.remove_massflow_outlier_rows()
            if apply_prc:
                self.log("• filter_pressure_recovery_by_prefix()")
                combined.filter_pressure_recovery_by_prefix()

            shutil.copy(os.path.join(csv_folder, "data.csv"), dst_data)
            self.log(f"  → Filtered CSV saved: {dst_data}")

            self.log("• run_analysis()")
            combined.run_analysis()
            self.log("• visualize_analysis()")
            combined.visualize_analysis()
            for rpt in ("converged_analysis", "diverged_analysis",
                        "converged_visualization", "diverged_visualization"):
                src = os.path.join(csv_folder, f"{rpt}.xlsx")
                dst = os.path.join(csv_folder, f"{rpt}_{suffix}.xlsx")
                if os.path.exists(src):
                    shutil.move(src, dst)
            self.log(f"  → Excel reports for '{suffix}' generated.")

        self.filter_btn.config(state="normal")
        self.log("All filtering & reporting runs complete.")

    def update_data_file(self):
        self.update_btn.config(state="disabled")
        self.log("Updating data.csv according to checked_data.csv...")
        try:
            combined.filter_data_by_checked_ids()
            self.log("data.csv updated successfully.")
        except Exception as e:
            self.log(f"Error updating data: {e}")
        finally:
            self.update_btn.config(state="normal")

class MLPage(ttk.Frame):
    """Unified ML page that works in 'fresh' or 'existing' mode."""

    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.back_target = HomePage
        self.mode = 'fresh'
        self.base_dir = os.getcwd()
        self.configure(padding=25)
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 10))
        # Placeholder for ML icon
        # TODO: Add image 'ml_model.png' (e.g., icon_img = tk.PhotoImage(file='ml_model.png'); ttk.Label(header_frame, image=icon_img).pack())
        ttk.Label(header_frame, text="Machine Learning: Train & Predict", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Train models or run predictions", style='Subheader.TLabel').pack(pady=5)

        self.nb = ttk.Notebook(self)
        self.nb.pack(fill="both", expand=True, padx=15, pady=10)

        self.tab_train = ttk.Frame(self.nb)
        self.nb.add(self.tab_train, text="Train ML Model")
        self._build_train_tab()

        self.tab_pred = ttk.Frame(self.nb)
        self.nb.add(self.tab_pred, text="Run Predictions")
        self._build_pred_tab()

        ttk.Button(self, text="← Back", command=self._go_back, style='TButton').pack(pady=15)

    def set_mode(self, mode):
        self.mode = mode
        if mode == 'existing':
            self.base_dir = os.path.join(os.getcwd(), "already trained model")
        else:
            self.base_dir = os.getcwd()
        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(os.path.join(self.base_dir, "csv files"), exist_ok=True)
        os.makedirs(os.path.join(self.base_dir, "ml results"), exist_ok=True)

    def set_back_target(self, page):
        self.back_target = page

    def _go_back(self):
        self.controller.show_frame(self.back_target)

    def _build_train_tab(self):
        hp = ttk.LabelFrame(self.tab_train, text="Model Hyperparameters", padding=15)
        hp.pack(fill="x", padx=15, pady=10)
        params = [
            ("Folds (K):", "7", "k_entry"),
            ("Estimators (n):", "300", "n_entry"),
            ("Learning rate:", "0.026", "lr_entry"),
            ("Max depth:", "6", "md_entry")
        ]
        for i, (lbl, init, attr) in enumerate(params):
            ttk.Label(hp, text=lbl).grid(row=i, column=0, sticky="e", padx=8, pady=8)
            ent = ttk.Entry(hp, font=('Arial', 11))
            ent.insert(0, init)
            ent.grid(row=i, column=1, sticky="w", padx=8, pady=8)
            setattr(self, attr, ent)
        hp.columnconfigure(1, weight=1)
        ttk.Button(self.tab_train, text="Train Models", command=self.train_models, style='Accent.TButton').pack(pady=10)
        self.train_log = scrolledtext.ScrolledText(self.tab_train, wrap="word", height=10, font=('Courier', 11))
        self.train_log.pack(fill="both", expand=True, padx=15, pady=10)

    def train_models(self):
        self.train_log.delete("1.0", "end")
        try:
            k = int(self.k_entry.get())
            n = int(self.n_entry.get())
            lr = float(self.lr_entry.get())
            md = int(self.md_entry.get())
        except ValueError:
            return messagebox.showerror("Invalid", "Enter valid hyperparameters")
        csv_path = os.path.join(self.base_dir, "csv files", "data.csv")
        if not os.path.exists(csv_path):
            return messagebox.showerror("Missing", f"{csv_path} not found")
        df = load_data(csv_path)
        num = df.select_dtypes(include=[np.number])
        Q1 = num.quantile(0.25)
        Q3 = num.quantile(0.75)
        IQR = Q3 - Q1
        df = df[~((num < (Q1 - 1.5 * IQR)) | (num > (Q3 + 1.5 * IQR))).any(axis=1)]
        self.train_log.insert("end", f"Rows after outlier removal: {len(df)}\n\n")

        kf = KFold(n_splits=k, shuffle=True, random_state=42)
        # PRC model
        X1 = df[['Avg_Mach_outlet', 'Avg_Massflow_outlet', 'Cfg_MACH_NUMBER']]
        y1 = df['Pressure_Recovery_Coefficient']
        p1 = Pipeline([('s', StandardScaler()),
                       ('x', XGBRegressor(n_estimators=n, learning_rate=lr,
                                          max_depth=md, objective='reg:squarederror',
                                          random_state=42, n_jobs=-1))])
        s1 = cross_val_score(p1, X1, y1, cv=kf, scoring='r2', n_jobs=-1)
        self.train_log.insert("end",
                              f"PRC R² per fold: {np.round(s1, 4).tolist()}, mean {s1.mean():.4f}\n\n"
                              )

        # Design model
        X2 = df[['Pressure_Recovery_Coefficient', 'Avg_Mach_outlet',
                 'Avg_Massflow_outlet', 'Cfg_MACH_NUMBER']]
        y2 = df[['ramp_count', 'ramp_length', 'Theta', 'Backpressure_constant']]
        p2 = Pipeline([('s', StandardScaler()), ('m',
                                                 MultiOutputRegressor(
                                                     XGBRegressor(n_estimators=n, learning_rate=lr,
                                                                  max_depth=md, subsample=0.9,colsample_bytree=0.9, objective='reg:squarederror',
                                                                  random_state=42, n_jobs=-1)))])
        s2 = cross_val_score(p2, X2, y2, cv=kf, scoring='r2', n_jobs=-1)
        self.train_log.insert("end",
                              f"Design R² per fold: {np.round(s2, 4).tolist()}, mean {s2.mean():.4f}\n"
                              )

        p1.fit(X1, y1)
        p2.fit(X2, y2)
        prc_model_path = os.path.join(self.base_dir, "ml results", "model_prc_xgb.pkl")
        design_model_path = os.path.join(self.base_dir, "ml results", "model_design_xgb.pkl")
        joblib.dump(p1, prc_model_path)
        joblib.dump(p2, design_model_path)
        messagebox.showinfo("Training Complete",
                            f"PRC mean R² {s1.mean():.4f}\nDesign mean R² {s2.mean():.4f}"
                            )

    def _build_pred_tab(self):
        inp = ttk.LabelFrame(self.tab_pred, text="Prediction Inputs", padding=15)
        inp.pack(fill="x", padx=15, pady=10)
        fields = [
            ("Avg Mach Outlet:", "0.6559", "mo_entry"),
            ("Avg Massflow Outlet:", "18.02", "mf_entry"),
            ("Inlet Mach (Cfg):", "2.75", "im_entry")
        ]
        for i, (lbl, init, attr) in enumerate(fields):
            ttk.Label(inp, text=lbl).grid(row=i, column=0, sticky="e", padx=8, pady=8)
            ent = ttk.Entry(inp, font=('Arial', 11))
            ent.insert(0, init)
            ent.grid(row=i, column=1, sticky="w", padx=8, pady=8)
            setattr(self, attr, ent)
        inp.columnconfigure(1, weight=1)

        btn_frame = ttk.Frame(self.tab_pred)
        btn_frame.pack(fill="x", padx=15, pady=10)
        ttk.Button(btn_frame, text="Run Prediction", command=self.run_prediction, style='Accent.TButton').pack(
            side="left", padx=8)
        ttk.Button(btn_frame, text="Test Predictions with CFD", command=self.run_cfd_test, style='TButton').pack(side="left", padx=8)
        self.pred_log = scrolledtext.ScrolledText(self.tab_pred, wrap="word", height=10, font=('Courier', 11))
        self.pred_log.pack(fill="both", expand=True, padx=15, pady=10)

    def run_prediction(self):
        self.pred_log.delete("1.0", "end")
        prc_path = os.path.join(self.base_dir, "ml results", "model_prc_xgb.pkl")
        design_path = os.path.join(self.base_dir, "ml results", "model_design_xgb.pkl")
        if not os.path.exists(prc_path) or not os.path.exists(design_path):
            return messagebox.showerror("Missing", "Train models first")
        prc_m = joblib.load(prc_path)
        des_m = joblib.load(design_path)
        try:
            mout = float(self.mo_entry.get())
            mf = float(self.mf_entry.get())
            Min = float(self.im_entry.get())
        except ValueError:
            return messagebox.showerror("Invalid", "Enter numeric values")
        X1 = pd.DataFrame([[mout, mf, Min]],
                          columns=["Avg_Mach_outlet", "Avg_Massflow_outlet", "Cfg_MACH_NUMBER"])
        prc_pred = prc_m.predict(X1)[0]
        X2 = pd.DataFrame([[prc_pred, mout, mf, Min]],
                          columns=["Pressure_Recovery_Coefficient",
                                   "Avg_Mach_outlet", "Avg_Massflow_outlet", "Cfg_MACH_NUMBER"])
        cnt_f, L, θ, bc = des_m.predict(X2)[0]
        cnt = int(round(cnt_f))
        txt = (f"PRC: {prc_pred:.4f}\n"
               f"ramp_count: {cnt}\n"
               f"ramp_length: {L:.3f}\n"
               f"Theta: {θ:.3f}\n"
               f"Backpressure const: {bc:.4f}\n")
        self.pred_log.insert("end", txt)
        self._last_pred = {'Min': Min, 'L': L, 'θ': θ, 'rc': cnt, 'bc': bc,
                           'mout': mout, 'mf': mf, 'prc_pred': prc_pred}

    def run_cfd_test(self):
        if not hasattr(self, '_last_pred'):
            return messagebox.showerror("No Prediction", "Run prediction first")
        threading.Thread(target=self._cfd_thread, args=(self._last_pred,), daemon=True).start()

    def _cfd_thread(self, params):
        base_id = get_id(params['Min'], params['L'], params['θ'], params['rc'], params['bc'])
        self.pred_log.insert("end", f"\nRunning CFD for {base_id} at altitude {self.controller.altitude}\n")

        old_cwd = os.getcwd()
        os.chdir(self.base_dir)
        try:
            run_point_calculator(params['rc'], params['Min'], params['L'], params['θ'], params['bc'], alt=self.controller.altitude, ml="Yes")
            dst = move_result_files(base_id)
            run_cfd(dst)
        except Exception as e:
            os.chdir(old_cwd)
            self.after(0, lambda msg=str(e): messagebox.showerror("CFD Error", msg))
            return

        if not check_convergence(base_id):
            os.chdir(old_cwd)
            self.after(0, lambda: messagebox.showwarning("No Convergence",
                                                         f"{base_id} did NOT converge"))
            return

        am, af, em, ef = calc_errors(base_id, params['mout'], params['mf'])
        aprc, ep = calc_prc_error(base_id, params['prc_pred'])
        summ = (f"Actual Mach: {am:.4f}  err {em:.2f}%\n"
                f"Actual Massflow: {af:.4f}  err {ef:.2f}%\n")
        if aprc is not None:
            summ += f"Actual PRC: {aprc:.4f}  err {ep:.2f}%\n"
        self.pred_log.insert("end", summ + "\n")

        # Open the .vtu file
        try:
            open_vtu(base_id)
        except Exception as e:
            self.pred_log.insert("end", f"Error opening VTU file: {e}\n")

        # Draw the corresponding 3D shape from the .geo in the same folder
        try:
            geo_file = os.path.join(dst, f"{base_id}.geo")
            draw_3d_shape(geo_file)
        except Exception as e:
            self.pred_log.insert("end", f"Shape drawing error: {e}\n")

        os.chdir(old_cwd)
        self.after(0, lambda: self._post_add_dialog(base_id, params))

    def _post_add_dialog(self, base_id, params):
        ans = messagebox.askyesnocancel(
            "Add to data.csv?",
            "Yes = add & retrain ML, No = re-enter BP & rerun CFD, Cancel = skip"
        )
        if ans is True:
            old_cwd = os.getcwd()
            try:
                os.chdir(self.base_dir)
                add_current_analysis_to_training(base_id)
            finally:
                os.chdir(old_cwd)
            messagebox.showinfo("Success", f"'{base_id}' added to data.csv")
            threading.Thread(target=self._retrain_defaults, daemon=True).start()
        elif ans is False:
            new_bp = simpledialog.askfloat("New Backpressure", "Enter new back pressure constant:")
            if new_bp is not None:
                params2 = params.copy()
                params2['bc'] = new_bp
                self.pred_log.insert("end", f"\nRerunning CFD with BP={new_bp}\n")
                threading.Thread(target=self._cfd_thread, args=(params2,), daemon=True).start()

    def _retrain_defaults(self):
        for ent, val in zip(
                [self.k_entry, self.n_entry, self.lr_entry, self.md_entry],
                ["5", "200", "0.1", "6"]
        ):
            ent.delete(0, "end")
            ent.insert(0, val)
        self.train_models()

class SettingsPage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(padding=25)
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 10))
        # Placeholder for settings icon
        # TODO: Add image 'settings_icon.png' (e.g., icon_img = tk.PhotoImage(file='settings_icon.png'); ttk.Label(header_frame, image=icon_img).pack())
        ttk.Label(header_frame, text="Settings", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Configure mesh ratio multipliers", style='Subheader.TLabel').pack(pady=5)

        # Input frame
        input_frame = ttk.LabelFrame(self, text="Mesh Ratio Multipliers", padding=15)
        input_frame.pack(fill="x", padx=15, pady=10)
        fields = [
            ("ML Mesh Multiplier (applied to 2000):", "1.0", "ml_multiplier_entry"),
            ("Non-ML Mesh Multiplier (applied to 1000):", "1.0", "non_ml_multiplier_entry")
        ]
        for i, (label, default, attr) in enumerate(fields):
            ttk.Label(input_frame, text=label).grid(row=i, column=0, sticky="w", padx=8, pady=8)
            entry = ttk.Entry(input_frame, font=('Arial', 11))
            entry.insert(0, default)
            entry.grid(row=i, column=1, sticky="ew", padx=8, pady=8)
            setattr(self, attr, entry)
        input_frame.columnconfigure(1, weight=1)

        # Buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=15, pady=10)
        ttk.Button(btn_frame, text="Apply Settings", command=self.apply_settings, style='Accent.TButton').pack(side="left", padx=8)
        ttk.Button(btn_frame, text="← Back to Home", command=lambda: controller.show_frame(HomePage),
                   style='TButton').pack(side="left", padx=8)

        # Log
        log_frame = ttk.LabelFrame(self, text="Settings Log", padding=15)
        log_frame.pack(fill="both", expand=True, padx=15, pady=10)
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap="word", state="disabled", height=12,
                                                  font=('Courier', 11))
        self.log_text.pack(fill="both", expand=True)

    def log(self, message):
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

    def apply_settings(self):
        try:
            ml_multiplier = float(self.ml_multiplier_entry.get())
            non_ml_multiplier = float(self.non_ml_multiplier_entry.get())
            if ml_multiplier <= 0 or non_ml_multiplier <= 0:
                raise ValueError("Multipliers must be positive numbers.")
        except ValueError:
            self.log("Error: Please enter valid positive numeric multipliers.")
            messagebox.showerror("Invalid Input", "Please enter valid positive numeric multipliers.")
            return

        # Update geo file creater.py
        try:
            geo_file_path = "geo file creater.py"
            if not os.path.exists(geo_file_path):
                self.log("Error: 'geo file creater.py' not found.")
                messagebox.showerror("File Not Found", "'geo file creater.py' not found.")
                return

            with open(geo_file_path, 'r') as f:
                content = f.read()

            # Replace the mesh_ratio line with correct indentation (8 spaces)
            new_mesh_ratio_line = f"        mesh_ratio = {int(2000 * ml_multiplier)} if ml == \"Yes\" else {int(1000 * non_ml_multiplier)}"
            pattern = r"^\s*mesh_ratio = \d+ if ml == \"Yes\" else \d+\s*$"
            if re.search(pattern, content, re.MULTILINE):
                updated_content = re.sub(pattern, new_mesh_ratio_line, content, flags=re.MULTILINE)
            else:
                self.log("Error: Could not find mesh_ratio line in 'geo file creater.py'.")
                messagebox.showerror("Error", "Could not find mesh_ratio line to update.")
                return

            # Write the updated content back
            with open(geo_file_path, 'w') as f:
                f.write(updated_content)

            self.log(f"Updated 'geo file creater.py' with mesh_ratio = {int(2000 * ml_multiplier)} (ML) and {int(1000 * non_ml_multiplier)} (non-ML).")
            messagebox.showinfo("Success", "Settings applied successfully.")
        except Exception as e:
            self.log(f"Error updating 'geo file creater.py': {str(e)}")
            messagebox.showerror("Error", f"Failed to update 'geo file creater.py': {str(e)}")

class AltitudePage(ttk.Frame):
    def __init__(self, parent, controller):
        super().__init__(parent)
        self.controller = controller
        self.configure(padding=25)
        # Header
        header_frame = ttk.Frame(self)
        header_frame.pack(fill="x", pady=(0, 10))
        ttk.Label(header_frame, text="Set CFD Altitude", style='Header.TLabel').pack()
        ttk.Label(header_frame, text="Configure the altitude for CFD simulations", style='Subheader.TLabel').pack(pady=5)

        # Input frame
        input_frame = ttk.LabelFrame(self, text="Altitude Setting", padding=15)
        input_frame.pack(fill="x", padx=15, pady=10)
        ttk.Label(input_frame, text="Altitude (meters):").grid(row=0, column=0, sticky="w", padx=8, pady=8)
        self.altitude_entry = ttk.Entry(input_frame, font=('Arial', 11))
        self.altitude_entry.insert(0, str(self.controller.altitude))
        self.altitude_entry.grid(row=0, column=1, sticky="ew", padx=8, pady=8)
        input_frame.columnconfigure(1, weight=1)

        # Buttons
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=15, pady=10)
        ttk.Button(btn_frame, text="Apply Altitude", command=self.apply_altitude, style='Accent.TButton').pack(side="left", padx=8)
        ttk.Button(btn_frame, text="← Back to Home", command=lambda: controller.show_frame(HomePage),
                   style='TButton').pack(side="left", padx=8)

        # Log
        log_frame = ttk.LabelFrame(self, text="Altitude Log", padding=15)
        log_frame.pack(fill="both", expand=True, padx=15, pady=10)
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap="word", state="disabled", height=12,
                                                  font=('Courier', 11))
        self.log_text.pack(fill="both", expand=True)

    def log(self, message):
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

    def apply_altitude(self):
        try:
            new_altitude = float(self.altitude_entry.get())
            if new_altitude < 0:
                raise ValueError("Altitude must be a non-negative number.")
        except ValueError:
            self.log("Error: Please enter a valid non-negative numeric altitude.")
            messagebox.showerror("Invalid Input", "Please enter a valid non-negative numeric altitude.")
            return

        self.controller.altitude = new_altitude
        self.log(f"Altitude updated to {new_altitude} meters.")
        messagebox.showinfo("Success", f"CFD altitude set to {new_altitude} meters.")

if __name__ == "__main__":
    app = MainApp()
    app.mainloop()