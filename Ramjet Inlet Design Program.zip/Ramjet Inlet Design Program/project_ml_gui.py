#!/usr/bin/env python3
import os, sys, glob, shutil, subprocess, threading, logging
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, scrolledtext

import pandas as pd
import numpy as np
import joblib

from sklearn.model_selection import KFold, cross_val_score
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.multioutput import MultiOutputRegressor
from xgboost import XGBRegressor

import predict_new  # for add_current_analysis_to_training

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s - %(message)s")

os.makedirs("ml results", exist_ok=True)
os.makedirs("csv files", exist_ok=True)

# ── predict_new helper functions ─────────────────────────────────────────────

def fmt3(x): return f"{x:.3f}".rstrip('0').rstrip('.')
def fmt2(x):
    s = f"{x:.2f}"
    return s[:-1] if s.endswith(('0', '.00')) else s

def get_id(M, L, θ, rc, bc):
    m = fmt3(M) + ('.0' if '.' not in fmt3(M) else '')
    l = fmt3(L)
    t = fmt2(θ)
    b = fmt3(bc)
    return f"{m}_{'_'.join([l]*rc)}_{t}_{b}"

def run_point_calculator(rc, M, L, θ, bc, alt=10000, ml="Yes"):
    inp = (
        f"{rc}\n{fmt3(M)}\n{alt}\nY\n"
        f"{fmt3(L)}\n{fmt2(θ)}\n{fmt3(bc)}\n{ml}\n"
    )
    subprocess.run([sys.executable, "point calculator.py"],
                   input=inp, text=True, check=True)

def move_result_files(base_id):
    dst = os.path.join("ml results", base_id)
    os.makedirs(dst, exist_ok=True)
    for ext in (".geo", ".su2"):
        for src in glob.glob(f"geo files/{base_id}{ext}"):
            tgt = os.path.join(dst, os.path.basename(src))
            if os.path.exists(tgt): os.remove(tgt)
            shutil.move(src, tgt)
    for cfg in glob.glob(f"cfg files/{base_id}.cfg"):
        tgt = os.path.join(dst, os.path.basename(cfg))
        if os.path.exists(tgt): os.remove(tgt)
        shutil.move(cfg, tgt)
    stray = f"cfg files/{base_id}.su2"
    if os.path.exists(stray): os.remove(stray)
    return dst

def run_cfd(folder, procs=6, cmd="SU2_CFD"):
    for cfg in sorted(glob.glob(os.path.join(folder, "*.cfg"))):
        subprocess.run(
            ["mpirun", "-n", str(procs), cmd, os.path.basename(cfg)],
            cwd=folder, check=True
        )

def check_convergence(base_id):
    hist = os.path.join("ml results", base_id, f"{base_id}_history.csv")
    df = pd.read_csv(hist)
    col = next((c for c in df.columns if "rms[Rho]" in c), None)
    val = df[col].iloc[-1] if col else np.nan
    return isinstance(val, (int, float)) and not pd.isna(val) and val <= -5

def open_vtu(base_id):
    folder = os.path.join("ml results", base_id)
    vtus = [v for v in glob.glob(os.path.join(folder, "*.vtu"))
            if base_id in os.path.basename(v) and "surface_flow" not in v.lower()]
    for v in vtus:
        subprocess.Popen(["paraview", v])

def calc_errors(base_id, target_mach, target_mf):
    hist = os.path.join("ml results", base_id, f"{base_id}_history.csv")
    df = pd.read_csv(hist)
    last = df.iloc[-1]
    am = last["Avg_Mach(outlet)"]
    af = -last["Avg_Massflow(outlet)"]
    return am, af, (am - target_mach) / target_mach * 100, (af - target_mf) / target_mf * 100

def calc_prc_error(base_id, prc_pred):
    hist = os.path.join("ml results", base_id, f"{base_id}_history.csv")
    df = pd.read_csv(hist)
    tp = df.iloc[-1]["Avg_TotalPress(outlet)"]
    if pd.isna(tp): return None, None
    cfg_vals = {}
    with open(os.path.join("ml results", base_id, f"{base_id}.cfg")) as f:
        for line in f:
            l = line.split('%')[0].strip()
            if l.startswith("MACH_NUMBER="):
                cfg_vals['MACH_NUMBER'] = float(l.split("=", 1)[1])
            elif l.startswith("FREESTREAM_PRESSURE="):
                cfg_vals['FREESTREAM_PRESSURE'] = float(l.split("=", 1)[1])
    M = cfg_vals.get('MACH_NUMBER'); p = cfg_vals.get('FREESTREAM_PRESSURE')
    if M is None or p is None: return None, None
    γ = 1.4
    p0 = p * (1 + (γ - 1) / 2 * M**2)**(γ / (γ - 1))
    aprc = tp / p0
    return aprc, (aprc - prc_pred) / prc_pred * 100 if prc_pred else None

def add_current_analysis_to_training(base_id):
    predict_new.add_current_analysis_to_training(base_id)

# ── train_new helper functions ────────────────────────────────────────────

def parse_ramp_info(s: str):
    parts = s.split('_'); vals = [float(p) for p in parts]
    cnt = len(vals)
    length = vals[0] if all(abs(v - vals[0]) < 1e-6 for v in vals) else np.mean(vals)
    return cnt, length

def load_data(path):
    df = pd.read_csv(path)
    df.columns = df.columns.str.strip()
    df[['ramp_count', 'ramp_length']] = df['Ramp_Lengths']\
        .apply(lambda s: pd.Series(parse_ramp_info(s)))
    return df

# ── GUI ───────────────────────────────────────────────────────────────────

class MLGui(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ramjet ML & CFD Tester")
        self.geometry("750x650")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=10, pady=10)

        t1 = ttk.Frame(nb); nb.add(t1, text="Train ML")
        self._build_train_tab(t1)

        t2 = ttk.Frame(nb); nb.add(t2, text="Run Prediction & CFD Test")
        self._build_pred_tab(t2)

        self._last_pred = {}

    def _build_train_tab(self, f):
        hp = ttk.LabelFrame(f, text="Hyperparameters"); hp.pack(fill="x", padx=10, pady=10)
        for i, (lbl, init) in enumerate([("Folds (K):", "5"),
                                         ("Estimators (n):", "200"),
                                         ("Learning rate:", "0.1"),
                                         ("Max depth:", "6")]):
            ttk.Label(hp, text=lbl).grid(row=i, column=0, sticky="e", padx=5, pady=2)
            ent = ttk.Entry(hp); ent.insert(0, init); ent.grid(row=i, column=1, sticky="w", padx=5, pady=2)
            setattr(self, ["k_entry", "n_entry", "lr_entry", "md_entry"][i], ent)
        ttk.Button(f, text="Train Models", command=self.train_models).pack(pady=5)
        self.train_log = scrolledtext.ScrolledText(f, wrap="word", height=15)
        self.train_log.pack(fill="both", expand=True, padx=10, pady=5)

    def _build_pred_tab(self, f):
        inp = ttk.LabelFrame(f, text="Prediction Inputs"); inp.pack(fill="x", padx=10, pady=10)
        for i, (lbl, init) in enumerate([("Avg Mach Outlet:", "0.65"),
                                         ("Avg Massflow Outlet:", "18.0"),
                                         ("Inlet Mach :", "3.0")]):
            ttk.Label(inp, text=lbl).grid(row=i, column=0, sticky="e", padx=5, pady=2)
            ent = ttk.Entry(inp); ent.insert(0, init); ent.grid(row=i, column=1, sticky="w", padx=5, pady=2)
            setattr(self, ["mo_entry", "mf_entry", "im_entry"][i], ent)
        ttk.Button(f, text="Run Prediction", command=self.run_prediction).pack(pady=5)
        ttk.Button(f, text="Run CFD to Test Predictions", command=self.run_cfd_test).pack(pady=2)
        self.pred_log = scrolledtext.ScrolledText(f, wrap="word", height=12)
        self.pred_log.pack(fill="both", expand=True, padx=10, pady=5)

    def train_models(self):
        self.train_log.delete("1.0", "end")
        try:
            k, n = int(self.k_entry.get()), int(self.n_entry.get())
            lr, md = float(self.lr_entry.get()), int(self.md_entry.get())
        except ValueError:
            return messagebox.showerror("Invalid", "Enter valid hyperparameters")
        dp = os.path.join("csv files", "data.csv")
        if not os.path.exists(dp):
            return messagebox.showerror("Missing", f"{dp} missing")
        df = load_data(dp)
        num = df.select_dtypes(include=[np.number])
        Q1, Q3 = num.quantile(.25), num.quantile(.75)
        IQR = Q3 - Q1
        df = df[~((num < (Q1 - 1.5 * IQR)) | (num > (Q3 + 1.5 * IQR))).any(axis=1)].reset_index(drop=True)
        self.train_log.insert("end", f"Rows after outlier removal: {len(df)}\n\n")
        kf = KFold(n_splits=k, shuffle=True, random_state=42)

        X1 = df[['Avg_Mach_outlet', 'Avg_Massflow_outlet', 'Cfg_MACH_NUMBER']]
        y1 = df['Pressure_Recovery_Coefficient']
        p1 = Pipeline([('s', StandardScaler()),
                       ('x', XGBRegressor(n_estimators=n, learning_rate=lr,
                                         max_depth=md, objective='reg:squarederror',
                                         random_state=42, n_jobs=-1))])
        s1 = cross_val_score(p1, X1, y1, cv=kf, scoring='r2', n_jobs=-1)
        self.train_log.insert("end", f"PRC R²: {np.round(s1,4).tolist()}, mean {s1.mean():.4f}\n\n")

        X2 = df[['Pressure_Recovery_Coefficient', 'Avg_Mach_outlet', 'Avg_Massflow_outlet', 'Cfg_MACH_NUMBER']]
        y2 = df[['ramp_count', 'ramp_length', 'Theta', 'Backpressure_constant']]
        p2 = Pipeline([('s', StandardScaler()),
                       ('m', MultiOutputRegressor(
                           XGBRegressor(n_estimators=n, learning_rate=lr,
                                        max_depth=md, objective='reg:squarederror',
                                        random_state=42, n_jobs=-1)))])
        s2 = cross_val_score(p2, X2, y2, cv=kf, scoring='r2', n_jobs=-1)
        self.train_log.insert("end", f"Design R²: {np.round(s2,4).tolist()}, mean {s2.mean():.4f}\n")

        p1.fit(X1, y1); joblib.dump(p1, os.path.join("ml results", "model_prc_xgb.pkl"))
        p2.fit(X2, y2); joblib.dump(p2, os.path.join("ml results", "model_design_xgb.pkl"))
        messagebox.showinfo("Training Complete",
                            f"PRC mean R² {s1.mean():.4f}\nDesign mean R² {s2.mean():.4f}")

    def run_prediction(self):
        self.pred_log.delete("1.0", "end")
        m1 = "ml results/model_prc_xgb.pkl"; m2 = "ml results/model_design_xgb.pkl"
        if not os.path.exists(m1) or not os.path.exists(m2):
            return messagebox.showerror("Missing", "Train first")
        prc_m, des_m = joblib.load(m1), joblib.load(m2)
        try:
            mout = float(self.mo_entry.get())
            mf = float(self.mf_entry.get())
            Min = float(self.im_entry.get())
        except ValueError:
            return messagebox.showerror("Invalid", "Enter numeric")
        X1 = pd.DataFrame([[mout, mf, Min]],
                          columns=["Avg_Mach_outlet", "Avg_Massflow_outlet", "Cfg_MACH_NUMBER"])
        prc_pred = prc_m.predict(X1)[0]
        X2 = pd.DataFrame([[prc_pred, mout, mf, Min]],
                          columns=["Pressure_Recovery_Coefficient",
                                   "Avg_Mach_outlet", "Avg_Massflow_outlet", "Cfg_MACH_NUMBER"])
        cnt_f, L, θ, bc = des_m.predict(X2)[0]
        cnt = int(round(cnt_f))
        txt = (
            f"PRC: {prc_pred:.4f}\n"
            f"ramp_count: {cnt}\n"
            f"ramp_length: {L:.3f}\n"
            f"Theta: {θ:.3f}\n"
            f"Backpressure const: {bc:.4f}\n"
        )
        self.pred_log.insert("end", txt)
        self._last_pred = {'Min': Min, 'L': L, 'θ': θ, 'rc': cnt,
                           'bc': bc, 'mout': mout, 'mf': mf, 'prc_pred': prc_pred}

    def run_cfd_test(self):
        if not self._last_pred:
            return messagebox.showerror("No Prediction", "Run prediction first")
        threading.Thread(target=self._cfd_thread, args=(self._last_pred,), daemon=True).start()

    def _cfd_thread(self, params):
        base_id = get_id(params['Min'], params['L'], params['θ'], params['rc'], params['bc'])
        self.pred_log.insert("end", f"\nRunning CFD for {base_id}\n")
        try:
            run_point_calculator(params['rc'], params['Min'], params['L'], params['θ'], params['bc'], ml="Yes")
            dst = move_result_files(base_id)
            run_cfd(dst)
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("CFD Error", str(e)))
            return

        if not check_convergence(base_id):
            self.after(0, lambda: messagebox.showwarning("No Convergence",
                                                         f"{base_id} did NOT converge"))
            return

        am, af, em, ef = calc_errors(base_id, params['mout'], params['mf'])
        aprc, ep = calc_prc_error(base_id, params['prc_pred'])
        summ = (
            f"Actual Mach: {am:.4f}  err {em:.2f}%\n"
            f"Actual Massflow: {af:.4f}  err {ef:.2f}%\n"
        )
        if aprc is not None:
            summ += f"Actual PRC: {aprc:.4f}  err {ep:.2f}%\n"
        self.pred_log.insert("end", summ + "\n")
        open_vtu(base_id)

        # schedule the unified dialog
        self.after(0, lambda: self._post_add_dialog(base_id, params))

    def _post_add_dialog(self, base_id, params):
        ans = messagebox.askyesnocancel(
            "Add to data.csv?",
            "Yes = add and retrain ML, No = re-enter BP and rerun CFD, Cancel = skip"
        )
        if ans is True:
            add_current_analysis_to_training(base_id)
            messagebox.showinfo("Added", f"'{base_id}' added to data.csv")
            # now retrain ML with defaults in background
            threading.Thread(target=self._retrain_defaults, daemon=True).start()
        elif ans is False:
            new_bp = simpledialog.askfloat("New Backpressure",
                                           "Enter new back pressure constant:")
            if new_bp is not None:
                params2 = params.copy()
                params2['bc'] = new_bp
                self.pred_log.insert("end", f"\nRerunning CFD for new BP={new_bp}\n")
                threading.Thread(target=self._rerun_cfd_thread, args=(params2,), daemon=True).start()
        else:
            messagebox.showinfo("Skipped", f"Skipped adding '{base_id}'")

    def _rerun_cfd_thread(self, params):
        base_id = get_id(params['Min'], params['L'], params['θ'], params['rc'], params['bc'])
        try:
            run_point_calculator(params['rc'], params['Min'], params['L'], params['θ'], params['bc'], ml="Yes")
            dst = move_result_files(base_id)
            run_cfd(dst)
        except Exception as e:
            self.after(0, lambda: messagebox.showerror("CFD Error", str(e)))
            return

        if not check_convergence(base_id):
            self.after(0, lambda: messagebox.showwarning("No Convergence",
                                                         f"{base_id} did NOT converge"))
            return

        am, af, em, ef = calc_errors(base_id, params['mout'], params['mf'])
        aprc, ep = calc_prc_error(base_id, params['prc_pred'])
        summ = (
            f"Rerun Actual Mach: {am:.4f}  err {em:.2f}%\n"
            f"Rerun Actual MF:   {af:.4f}  err {ef:.2f}%\n"
        )
        if aprc is not None:
            summ += f"Rerun Actual PRC: {aprc:.4f}  err {ep:.2f}%\n"
        self.pred_log.insert("end", summ + "\n")
        open_vtu(base_id)
        # after rerun, call same dialog again
        self.after(0, lambda: self._post_add_dialog(base_id, params))

    def _retrain_defaults(self):
        # restore entries to defaults
        self.k_entry.delete(0, "end");  self.k_entry.insert(0, "5")
        self.n_entry.delete(0, "end");  self.n_entry.insert(0, "200")
        self.lr_entry.delete(0, "end"); self.lr_entry.insert(0, "0.1")
        self.md_entry.delete(0, "end"); self.md_entry.insert(0, "6")
        # run train
        self.train_models()

if __name__ == "__main__":
    app = MLGui()
    app.mainloop()
