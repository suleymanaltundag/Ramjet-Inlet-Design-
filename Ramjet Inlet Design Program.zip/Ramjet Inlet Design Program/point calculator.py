import importlib.util
import math
import os
#rom html.parser import endtagfind
#from symbol import return_stmt

from cfd_solver import determine_cfg_file
from interval import backpressure_constant

# Dynamically load the module from the file "ram jet cone oblique shock calculator.py"
spec = importlib.util.spec_from_file_location("cone", "ram jet cone oblique shock calculator.py")
cone = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cone)


# Dynamically load the module from the file "normal shock calculator.py"
spec = importlib.util.spec_from_file_location("normal", "normal shock calculator.py")
normal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(normal)

spec = importlib.util.spec_from_file_location("geo", "geo file creater.py")
geo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(geo)





ramp_num=input("Number of Ramp?").strip()



if ramp_num=="3":

    def main():
        print("Oblique Shock Cone Calculator with Ramp Lengths")
        print("-----------------------------------------------")

        # Ask for the upstream Mach number (M1)
        while True:
            try:
                M1 = float(input("Enter upstream Mach number (M1): "))
                break
            except ValueError:
                print("Invalid input. Please enter a numeric value for M1.")

        # Ask for gamma (with default = 1.4)
        gamma = "1.4"



        if gamma.strip() == "":
            gamma = 1.4
        else:
            try:
                gamma = float(gamma)
            except ValueError:
                print("Invalid gamma input. Using default value 1.4.")
                gamma = 1.4
        #
        altitude = float(input("Enter altitude "))




        # Ask the user if the lengths of the three ramps (in the x-axis) are equal.
        equal_ramps = input("Will the lengths of the three ramps be equal? (Y/N): ").strip().upper()
        if equal_ramps == "Y":
            while True:
                try:
                    ramp_length = float(input("Enter the ramp length (in x axis): "))
                    ramp1 = ramp2 = ramp3 = ramp_length
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for the ramp length.")
        elif equal_ramps == "N":
            while True:
                try:
                    ramp1 = float(input("Enter the length of the first ramp (in x axis): "))
                    ramp2 = float(input("Enter the length of the second ramp (in x axis): "))
                    ramp3 = float(input("Enter the length of the third ramp (in x axis): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter numeric values for all ramp lengths.")
        else:
            print("Invalid option for ramp equality. Exiting.")
            return



        # Ask the user whether theta or beta is known.
        option = "T"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_1 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=theta_deg_1, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_1 = float(input("Enter shock wave angle beta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=None, beta_deg=beta_deg_1)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return

        beta_deg_1=results['beta_deg']


        M2=results['Mc']

        point1_x=0
        point1_y=0

        point2_x = ramp1
        point2_y=ramp1 * math.tan(math.radians(theta_deg_1))

        point5_x=(ramp1+ramp2+ramp3)
        point5_y=(ramp1+ramp2+ramp3)*math.tan(math.radians(beta_deg_1))

        beta_deg_2= math.degrees(math.atan((point5_y-point2_y)/(ramp2+ramp3)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_2 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=theta_deg_2, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_2 = beta_deg_2
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=None, beta_deg=beta_deg_2)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return



        M3 = results['Mc']
        theta_deg_2=results['theta_deg']


        point3_x=(ramp1+ramp2)
        point3_y=(point2_y+(ramp2 * math.tan(math.radians(theta_deg_2))))

        beta_deg_3 = math.degrees(math.atan((point5_y - point3_y) / (ramp3)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_3 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M3, gamma, theta_deg=theta_deg_3, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_3 = beta_deg_3
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M3, gamma, theta_deg=None, beta_deg=beta_deg_3)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return
        M4 = results['Mc']
        theta_deg_3 = results['theta_deg']

        focal_3_length=ramp3 / math.cos(math.radians(beta_deg_3))


        perp_to_point_4=focal_3_length*(math.sin(math.radians(beta_deg_3-theta_deg_3)))

        perp_to_point_4_x=perp_to_point_4*(math.sin(math.radians(theta_deg_3)))
        perp_to_point_4_y = perp_to_point_4 * (math.cos(math.radians(theta_deg_3)))


        point4_x=(ramp1+ramp2+ramp3+perp_to_point_4_x)
        point4_y=(point5_y-perp_to_point_4_y)

        M_out = normal.normal_shock_calculator(gamma=gamma, M1_input=M4, M2_input=None, T2T1_input=None,p2p1_input=None,
                                rho2rho1_input=None, u2u1_input=None,
                                po2po1_input=None, po2p1_input=None)

        M5 = M_out['M2']
        print(f"  Mach Number 1: {M1:.4f}")
        print(f"  Mach Number 2: {M2:.4f}")
        print(f"  Mach Number 3: {M3:.4f}")
        print(f"  Mach Number 4: {M4:.4f}")
        print(f"  Mach Number 5: {M5:.4f}")
        print(f"  point1: {point1_x,point1_y}")
        print(f"  point2: {point2_x,point2_y}")
        print(f"  point3: {point3_x,point3_y}")
        print(f"  point4: {point4_x,point4_y}")
        print(f"  point5: {point5_x,point5_y}")



        # After computing all the point coordinates:
        point1 = (point1_x, point1_y)
        point2 = (point2_x, point2_y)
        point3 = (point3_x, point3_y)
        point4 = (point4_x, point4_y)
        point5 = (point5_x, point5_y)

        # Create file name identifiers.
        # Here, we're using M1 as the first identifier, the three ramp values joined as a string for the second, and theta_deg_1 for the third.
        name_1 = M1
        name_2 = f"{ramp1}_{ramp2}_{ramp3}"
        name_3 = theta_deg_1
        backpressure_constant=float(input("Back Pressure Constant"))
        name_4 = backpressure_constant

        ml=input("Does it ml test").strip()





        # Now call the function from your geo module to generate the .geo file
        create_geo_file = geo.is_ml(ml,ramp_num)

        create_geo_file(name_1, name_2, name_3, name_4,point1, point2, point3, point4, point5,ramp1,ramp2,ramp3)

        import cfd_solver
        solve_cfd=determine_cfg_file(ramp_num)

        solve_cfd(name_1, name_2, name_3,name_4, M1, M2, M3, M4, beta_deg_1, beta_deg_2,beta_deg_3, altitude, gamma,backpressure_constant)

if ramp_num=="2":

    def main():
        print("Oblique Shock Cone Calculator with Ramp Lengths")
        print("-----------------------------------------------")

        # Ask for the upstream Mach number (M1)
        while True:
            try:
                M1 = float(input("Enter upstream Mach number (M1): "))
                break
            except ValueError:
                print("Invalid input. Please enter a numeric value for M1.")

        # Ask for gamma (with default = 1.4)
        gamma = "1.4"

        if gamma.strip() == "":
            gamma = 1.4
        else:
            try:
                gamma = float(gamma)
            except ValueError:
                print("Invalid gamma input. Using default value 1.4.")
                gamma = 1.4
        #
        altitude = float(input("Enter altitude "))

        # Ask the user if the lengths of the three ramps (in the x-axis) are equal.
        equal_ramps = input("Will the lengths of the three ramps be equal? (Y/N): ").strip().upper()
        if equal_ramps == "Y":
            while True:
                try:
                    ramp_length = float(input("Enter the ramp length (in x axis): "))
                    ramp1 = ramp2 = ramp_length
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for the ramp length.")
        elif equal_ramps == "N":
            while True:
                try:
                    ramp1 = float(input("Enter the length of the first ramp (in x axis): "))
                    ramp2 = float(input("Enter the length of the second ramp (in x axis): "))

                    break
                except ValueError:
                    print("Invalid input. Please enter numeric values for all ramp lengths.")
        else:
            print("Invalid option for ramp equality. Exiting.")
            return

        # Ask the user whether theta or beta is known.
        option = "T"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_1 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=theta_deg_1, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_1 = float(input("Enter shock wave angle beta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=None, beta_deg=beta_deg_1)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return

        beta_deg_1 = results['beta_deg']

        M2 = results['Mc']

        point1_x = 0
        point1_y = 0

        point2_x = ramp1
        point2_y = ramp1 * math.tan(math.radians(theta_deg_1))

        point4_x = (ramp1 + ramp2)
        point4_y = (ramp1 + ramp2) * math.tan(math.radians(beta_deg_1))

        beta_deg_2 = math.degrees(math.atan((point4_y - point2_y) / (ramp2)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_2 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=theta_deg_2, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_2 = beta_deg_2
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=None, beta_deg=beta_deg_2)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return

        M3 = results['Mc']
        theta_deg_2 = results['theta_deg']

        focal_2_length = ramp2 / math.cos(math.radians(beta_deg_2))


        perp_to_point_3 = focal_2_length * (math.sin(math.radians(beta_deg_2 - theta_deg_2)))

        perp_to_point_3_x = perp_to_point_3 * (math.sin(math.radians(theta_deg_2)))
        perp_to_point_3_y = perp_to_point_3 * (math.cos(math.radians(theta_deg_2)))



        point3_x = (ramp1 + ramp2 + perp_to_point_3_x)
        point3_y = (point4_y - perp_to_point_3_y)

        M_out = normal.normal_shock_calculator(gamma=gamma, M1_input=M3, M2_input=None, T2T1_input=None,
                                               p2p1_input=None,
                                               rho2rho1_input=None, u2u1_input=None,
                                               po2po1_input=None, po2p1_input=None)

        M4 = M_out['M2']
        print(f"  Mach Number 1: {M1:.4f}")
        print(f"  Mach Number 2: {M2:.4f}")
        print(f"  Mach Number 3: {M3:.4f}")
        print(f"  Mach Number 4: {M4:.4f}")

        print(f"  point1: {point1_x, point1_y}")
        print(f"  point2: {point2_x, point2_y}")
        print(f"  point3: {point3_x, point3_y}")
        print(f"  point4: {point4_x, point4_y}")

        # After computing all the point coordinates:
        point1 = (point1_x, point1_y)
        point2 = (point2_x, point2_y)
        point3 = (point3_x, point3_y)
        point4 = (point4_x, point4_y)

        # Create file name identifiers.
        # Here, we're using M1 as the first identifier, the three ramp values joined as a string for the second, and theta_deg_1 for the third.
        name_1 = M1
        name_2 = f"{ramp1}_{ramp2}"
        name_3 = theta_deg_1
        backpressure_constant=float(input("Back Pressure Constant"))
        name_4 = backpressure_constant

        ml=input("Does it ml test").strip()
        # Now call the function from your geo module to generate the .geo file

        create_geo_file = geo.is_ml(ml,ramp_num)
        create_geo_file(name_1, name_2, name_3,name_4, point1, point2, point3, point4, ramp1, ramp2)

        import cfd_solver
        solve_cfd=determine_cfg_file(ramp_num)

        solve_cfd(name_1, name_2, name_3,name_4, M1, M2, M3, beta_deg_1, beta_deg_2, altitude, gamma,backpressure_constant)


if ramp_num=="4":
    def main():
        print("Oblique Shock Cone Calculator with Ramp Lengths")
        print("-----------------------------------------------")

        # Ask for the upstream Mach number (M1)
        while True:
            try:
                M1 = float(input("Enter upstream Mach number (M1): "))
                break
            except ValueError:
                print("Invalid input. Please enter a numeric value for M1.")

        # Ask for gamma (with default = 1.4)
        gamma = "1.4"



        if gamma.strip() == "":
            gamma = 1.4
        else:
            try:
                gamma = float(gamma)
            except ValueError:
                print("Invalid gamma input. Using default value 1.4.")
                gamma = 1.4
        #
        altitude = float(input("Enter altitude "))




        # Ask the user if the lengths of the three ramps (in the x-axis) are equal.
        equal_ramps = input("Will the lengths of the three ramps be equal? (Y/N): ").strip().upper()
        if equal_ramps == "Y":
            while True:
                try:
                    ramp_length = float(input("Enter the ramp length (in x axis): "))
                    ramp1 = ramp2 = ramp3= ramp4 = ramp_length
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for the ramp length.")
        elif equal_ramps == "N":
            while True:
                try:
                    ramp1 = float(input("Enter the length of the first ramp (in x axis): "))
                    ramp2 = float(input("Enter the length of the second ramp (in x axis): "))
                    ramp3 = float(input("Enter the length of the third ramp (in x axis): "))
                    ramp4 = float(input("Enter the length of the fourth ramp (in x axis): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter numeric values for all ramp lengths.")
        else:
            print("Invalid option for ramp equality. Exiting.")
            return



        # Ask the user whether theta or beta is known.
        option = "T"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_1 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=theta_deg_1, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_1 = float(input("Enter shock wave angle beta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=None, beta_deg=beta_deg_1)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return

        beta_deg_1=results['beta_deg']


        M2=results['Mc']

        point1_x=0
        point1_y=0

        point2_x = ramp1
        point2_y=ramp1 * math.tan(math.radians(theta_deg_1))

        point6_x=(ramp1+ramp2+ramp3+ramp4)
        point6_y=(ramp1+ramp2+ramp3+ramp4)*math.tan(math.radians(beta_deg_1))

        beta_deg_2= math.degrees(math.atan((point6_y-point2_y)/(ramp2+ramp3+ramp4)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_2 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=theta_deg_2, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_2 = beta_deg_2
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=None, beta_deg=beta_deg_2)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return



        M3 = results['Mc']
        theta_deg_2=results['theta_deg']


        point3_x=(ramp1+ramp2)
        point3_y=(point2_y+(ramp2 * math.tan(math.radians(theta_deg_2))))

        beta_deg_3 = math.degrees(math.atan((point6_y - point3_y) / (ramp3+ramp4)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_3 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M3, gamma, theta_deg=theta_deg_3, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_3 = beta_deg_3
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M3, gamma, theta_deg=None, beta_deg=beta_deg_3)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return
        M4 = results['Mc']
        theta_deg_3 = results['theta_deg']



        point4_x=(ramp1+ramp2+ramp3)
        point4_y=(point3_y+(ramp3 * math.tan(math.radians(theta_deg_3))))

        beta_deg_4 = math.degrees(math.atan((point6_y - point4_y) / (ramp4)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_4 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M4, gamma, theta_deg=theta_deg_4, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_4 = beta_deg_4
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M4, gamma, theta_deg=None, beta_deg=beta_deg_4)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return
        M5 = results['Mc']
        theta_deg_4 = results['theta_deg']


        focal_4_length=ramp4 / math.cos(math.radians(beta_deg_4))


        perp_to_point_5=focal_4_length*(math.sin(math.radians(beta_deg_4-theta_deg_4)))

        perp_to_point_5_x=perp_to_point_5*(math.sin(math.radians(theta_deg_4)))
        perp_to_point_5_y = perp_to_point_5 * (math.cos(math.radians(theta_deg_4)))


        point5_x=(ramp1+ramp2+ramp3+ramp4+perp_to_point_5_x)
        point5_y=(point6_y-perp_to_point_5_y)

        M_out = normal.normal_shock_calculator(gamma=gamma, M1_input=M5, M2_input=None, T2T1_input=None,p2p1_input=None,
                                rho2rho1_input=None, u2u1_input=None,
                                po2po1_input=None, po2p1_input=None)

        M6 = M_out['M2']
        print(f"  Mach Number 1: {M1:.4f}")
        print(f"  Mach Number 2: {M2:.4f}")
        print(f"  Mach Number 3: {M3:.4f}")
        print(f"  Mach Number 4: {M4:.4f}")
        print(f"  Mach Number 5: {M5:.4f}")
        print(f"  Mach Number 6: {M6:.4f}")
        print(f"  point1: {point1_x,point1_y}")
        print(f"  point2: {point2_x,point2_y}")
        print(f"  point3: {point3_x,point3_y}")
        print(f"  point4: {point4_x,point4_y}")
        print(f"  point5: {point5_x,point5_y}")
        print(f"  point6: {point6_x,point6_y}")



        # After computing all the point coordinates:
        point1 = (point1_x, point1_y)
        point2 = (point2_x, point2_y)
        point3 = (point3_x, point3_y)
        point4 = (point4_x, point4_y)
        point5 = (point5_x, point5_y)
        point6 = (point6_x, point6_y)

        # Create file name identifiers.
        # Here, we're using M1 as the first identifier, the three ramp values joined as a string for the second, and theta_deg_1 for the third.
        name_1 = M1
        name_2 = f"{ramp1}_{ramp2}_{ramp3}_{ramp4}"
        name_3 = theta_deg_1
        backpressure_constant=float(input("Back Pressure Constant"))
        name_4 = backpressure_constant


        ml=input("Does it ml test").strip()

        # Now call the function from your geo module to generate the .geo file
        create_geo_file = geo.is_ml(ml,ramp_num)
        create_geo_file(name_1, name_2, name_3,name_4, point1, point2, point3, point4, point5,point6,ramp1,ramp2,ramp3,ramp4)

        import cfd_solver
        solve_cfd=determine_cfg_file(ramp_num)

        solve_cfd(name_1, name_2, name_3,name_4, M1, M2, M3, M4,M5, beta_deg_1, beta_deg_2,beta_deg_3,beta_deg_4, altitude, gamma,backpressure_constant)


if ramp_num=="5":
    def main():
        print("Oblique Shock Cone Calculator with Ramp Lengths")
        print("-----------------------------------------------")

        # Ask for the upstream Mach number (M1)
        while True:
            try:
                M1 = float(input("Enter upstream Mach number (M1): "))
                break
            except ValueError:
                print("Invalid input. Please enter a numeric value for M1.")

        # Ask for gamma (with default = 1.4)
        gamma = "1.4"



        if gamma.strip() == "":
            gamma = 1.4
        else:
            try:
                gamma = float(gamma)
            except ValueError:
                print("Invalid gamma input. Using default value 1.4.")
                gamma = 1.4
        #
        altitude = float(input("Enter altitude "))




        # Ask the user if the lengths of the three ramps (in the x-axis) are equal.
        equal_ramps = input("Will the lengths of the three ramps be equal? (Y/N): ").strip().upper()
        if equal_ramps == "Y":
            while True:
                try:
                    ramp_length = float(input("Enter the ramp length (in x axis): "))
                    ramp1 = ramp2 = ramp3= ramp4 =ramp5= ramp_length
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for the ramp length.")
        elif equal_ramps == "N":
            while True:
                try:
                    ramp1 = float(input("Enter the length of the first ramp (in x axis): "))
                    ramp2 = float(input("Enter the length of the second ramp (in x axis): "))
                    ramp3 = float(input("Enter the length of the third ramp (in x axis): "))
                    ramp4 = float(input("Enter the length of the fourth ramp (in x axis): "))
                    ramp5 = float(input("Enter the length of the fifth ramp (in x axis): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter numeric values for all ramp lengths.")
        else:
            print("Invalid option for ramp equality. Exiting.")
            return



        # Ask the user whether theta or beta is known.
        option = "T"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_1 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=theta_deg_1, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_1 = float(input("Enter shock wave angle beta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M1, gamma, theta_deg=None, beta_deg=beta_deg_1)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return

        beta_deg_1=results['beta_deg']


        M2=results['Mc']

        point1_x=0
        point1_y=0

        point2_x = ramp1
        point2_y=ramp1 * math.tan(math.radians(theta_deg_1))

        point7_x=(ramp1+ramp2+ramp3+ramp4+ramp5)
        point7_y=(ramp1+ramp2+ramp3+ramp4+ramp5)*math.tan(math.radians(beta_deg_1))

        beta_deg_2= math.degrees(math.atan((point7_y-point2_y)/(ramp2+ramp3+ramp4+ramp5)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_2 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=theta_deg_2, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_2 = beta_deg_2
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M2, gamma, theta_deg=None, beta_deg=beta_deg_2)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return



        M3 = results['Mc']
        theta_deg_2=results['theta_deg']


        point3_x=(ramp1+ramp2)
        point3_y=(point2_y+(ramp2 * math.tan(math.radians(theta_deg_2))))

        beta_deg_3 = math.degrees(math.atan((point7_y - point3_y) / (ramp3+ramp4+ramp5)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_3 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M3, gamma, theta_deg=theta_deg_3, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_3 = beta_deg_3
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M3, gamma, theta_deg=None, beta_deg=beta_deg_3)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return
        M4 = results['Mc']
        theta_deg_3 = results['theta_deg']



        point4_x=(ramp1+ramp2+ramp3)
        point4_y=(point3_y+(ramp3 * math.tan(math.radians(theta_deg_3))))

        beta_deg_4 = math.degrees(math.atan((point7_y - point4_y) / (ramp4+ramp5)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_4 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M4, gamma, theta_deg=theta_deg_4, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_4 = beta_deg_4
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M4, gamma, theta_deg=None, beta_deg=beta_deg_4)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return
        M5 = results['Mc']
        theta_deg_4 = results['theta_deg']


        point5_x=(ramp1+ramp2+ramp3+ramp4)
        point5_y=(point4_y+(ramp4 * math.tan(math.radians(theta_deg_4))))

        beta_deg_5 = math.degrees(math.atan((point7_y - point5_y) / (ramp5)))

        # Ask the user whether theta or beta is known.
        option = "B"

        if option == "T":
            # Ask for theta in degrees.
            while True:
                try:
                    theta_deg_5 = float(input("Enter cone half-angle theta (in degrees): "))
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for theta.")
            # When theta is known, beta is unknown.
            results = cone.oblique_cone_calculator(M5, gamma, theta_deg=theta_deg_5, beta_deg=None)
        elif option == "B":
            # Ask for beta in degrees.
            while True:
                try:
                    beta_deg_5 = beta_deg_5
                    break
                except ValueError:
                    print("Invalid input. Please enter a numeric value for beta.")
            # When beta is known, theta is unknown.
            results = cone.oblique_cone_calculator(M5, gamma, theta_deg=None, beta_deg=beta_deg_5)
        else:
            print("Invalid option. Please run the program again and choose T or B.")
            return
        M6 = results['Mc']
        theta_deg_5 = results['theta_deg']



        focal_5_length=ramp5 / math.cos(math.radians(beta_deg_5))


        perp_to_point_6=focal_5_length*(math.sin(math.radians(beta_deg_5-theta_deg_5)))

        perp_to_point_6_x=perp_to_point_6*(math.sin(math.radians(theta_deg_5)))
        perp_to_point_6_y = perp_to_point_6 * (math.cos(math.radians(theta_deg_5)))


        point6_x=(ramp1+ramp2+ramp3+ramp4+ramp5+perp_to_point_6_x)
        point6_y=(point7_y-perp_to_point_6_y)

        M_out = normal.normal_shock_calculator(gamma=gamma, M1_input=M6, M2_input=None, T2T1_input=None,p2p1_input=None,
                                rho2rho1_input=None, u2u1_input=None,
                                po2po1_input=None, po2p1_input=None)

        M7 = M_out['M2']
        print(f"  Mach Number 1: {M1:.4f}")
        print(f"  Mach Number 2: {M2:.4f}")
        print(f"  Mach Number 3: {M3:.4f}")
        print(f"  Mach Number 4: {M4:.4f}")
        print(f"  Mach Number 5: {M5:.4f}")
        print(f"  Mach Number 6: {M6:.4f}")
        print(f"  Mach Number 7: {M7:.4f}")
        print(f"  point1: {point1_x,point1_y}")
        print(f"  point2: {point2_x,point2_y}")
        print(f"  point3: {point3_x,point3_y}")
        print(f"  point4: {point4_x,point4_y}")
        print(f"  point5: {point5_x,point5_y}")
        print(f"  point6: {point6_x,point6_y}")
        print(f"  point7: {point7_x,point7_y}")



        # After computing all the point coordinates:
        point1 = (point1_x, point1_y)
        point2 = (point2_x, point2_y)
        point3 = (point3_x, point3_y)
        point4 = (point4_x, point4_y)
        point5 = (point5_x, point5_y)
        point6 = (point6_x, point6_y)
        point7 = (point7_x, point7_y)

        # Create file name identifiers.
        # Here, we're using M1 as the first identifier, the three ramp values joined as a string for the second, and theta_deg_1 for the third.
        name_1 = M1
        name_2 = f"{ramp1}_{ramp2}_{ramp3}_{ramp4}_{ramp5}"
        name_3 = theta_deg_1
        backpressure_constant=float(input("Back Pressure Constant"))
        name_4 = backpressure_constant


        ml=input("Does it ml test").strip()

        # Now call the function from your geo module to generate the .geo file
        create_geo_file = geo.is_ml(ml,ramp_num)
        create_geo_file(name_1, name_2, name_3, name_4,point1, point2, point3, point4, point5,point6,point7,ramp1,ramp2,ramp3,ramp4,ramp5)

        import cfd_solver
        solve_cfd=determine_cfg_file(ramp_num)

        solve_cfd(name_1, name_2, name_3, name_4,M1, M2, M3, M4,M5,M6, beta_deg_1, beta_deg_2,beta_deg_3,beta_deg_4,beta_deg_5, altitude, gamma,backpressure_constant)


if __name__ == "__main__":
    main()


