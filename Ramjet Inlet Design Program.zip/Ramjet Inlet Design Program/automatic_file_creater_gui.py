import os
import glob
import subprocess
import threading
import tkinter as tk
from tkinter import ttk, scrolledtext, messagebox
import time
import signal
import csv
import re

def format_time(seconds):
    """Format seconds into a string; if over 60 minutes, include hours."""
    if seconds < 0:
        seconds = 0
    minutes = int(seconds // 60)
    sec = int(seconds % 60)
    if minutes < 60:
        return f"{minutes} min {sec} sec"
    else:
        hours = minutes // 60
        minutes = minutes % 60
        return f"{hours} hr {minutes} min {sec} sec"

def round_if_float(val, decimals=6):
    try:
        num = float(val)
        return f"{num:.{decimals}f}"
    except Exception:
        return val

class Application(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Ramjet Calculator GUI")
        self.geometry("1000x750")
        # Process control flags and timing variables
        self.cancelled = False
        self.paused = False
        self.pause_start = None
        self.stage_pause_duration = 0  # stage-specific pause duration
        self.current_proc = None  # Running subprocess reference
        self.current_command = None  # Store current command (for CFD stage)

        # For CFG and CFD progress counters
        self.total_cfg_iterations = 0
        self.total_cfd_iterations = 0
        self.current_cfg_iteration = 0
        self.current_cfd_iteration = 0

        self.create_widgets()

    def create_widgets(self):
        # Parameters Frame
        param_frame = ttk.LabelFrame(self, text="Parameters")
        param_frame.pack(fill="x", padx=10, pady=5)

        ttk.Label(param_frame, text="Back-pressure constant (comma separated):").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        self.bp_entry = ttk.Entry(param_frame)
        self.bp_entry.insert(0, "0.9")
        self.bp_entry.grid(row=0, column=1, sticky="ew", padx=5, pady=2)

        ttk.Label(param_frame, text="Mach values (comma separated):").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        self.mach_entry = ttk.Entry(param_frame)
        self.mach_entry.insert(0, "3")
        self.mach_entry.grid(row=1, column=1, sticky="ew", padx=5, pady=2)

        ttk.Label(param_frame, text="Ramp lengths (comma separated):").grid(row=2, column=0, sticky="w", padx=5, pady=2)
        self.ramp_length_entry = ttk.Entry(param_frame)
        self.ramp_length_entry.insert(0, "0.2")
        self.ramp_length_entry.grid(row=2, column=1, sticky="ew", padx=5, pady=2)

        ttk.Label(param_frame, text="Theta angles (comma separated):").grid(row=3, column=0, sticky="w", padx=5, pady=2)
        self.theta_entry = ttk.Entry(param_frame)
        self.theta_entry.insert(0, "12")
        self.theta_entry.grid(row=3, column=1, sticky="ew", padx=5, pady=2)

        ttk.Label(param_frame, text="Ramp numbers (comma separated):").grid(row=4, column=0, sticky="w", padx=5, pady=2)
        self.ramp_nums_entry = ttk.Entry(param_frame)
        self.ramp_nums_entry.insert(0, "2,3,4,5")
        self.ramp_nums_entry.grid(row=4, column=1, sticky="ew", padx=5, pady=2)

        param_frame.columnconfigure(1, weight=1)

        # Progress Frame (CFG and CFD progress rows)
        progress_frame = ttk.LabelFrame(self, text="Progress")
        progress_frame.pack(fill="x", padx=10, pady=5)

        # CFG progress row
        ttk.Label(progress_frame, text="CFG File Creation Progress:").grid(row=0, column=0, sticky="w", padx=5, pady=2)
        self.cfg_progress = ttk.Progressbar(progress_frame, orient="horizontal", length=400, mode="determinate")
        self.cfg_progress.grid(row=0, column=1, sticky="ew", padx=5, pady=2)
        self.cfg_percent_label = ttk.Label(progress_frame, text="0%")
        self.cfg_percent_label.grid(row=0, column=2, padx=5, pady=2)
        self.cfg_time_label = ttk.Label(progress_frame, text="")
        self.cfg_time_label.grid(row=0, column=3, padx=5, pady=2)

        # CFD progress row
        ttk.Label(progress_frame, text="CFD Simulation Progress:").grid(row=1, column=0, sticky="w", padx=5, pady=2)
        self.cfd_progress = ttk.Progressbar(progress_frame, orient="horizontal", length=400, mode="determinate")
        self.cfd_progress.grid(row=1, column=1, sticky="ew", padx=5, pady=2)
        self.cfd_percent_label = ttk.Label(progress_frame, text="0%")
        self.cfd_percent_label.grid(row=1, column=2, padx=5, pady=2)
        self.cfd_time_label = ttk.Label(progress_frame, text="")
        self.cfd_time_label.grid(row=1, column=3, padx=5, pady=2)

        # Buttons Frame
        btn_frame = ttk.Frame(self)
        btn_frame.pack(fill="x", padx=10, pady=5)
        self.start_button = ttk.Button(btn_frame, text="Start Process", command=self.start_process)
        self.start_button.pack(side="left", padx=5)
        self.hold_button = ttk.Button(btn_frame, text="Hold", command=self.toggle_pause)
        self.hold_button.pack(side="left", padx=5)
        self.cancel_button = ttk.Button(btn_frame, text="Cancel", command=self.cancel_process)
        self.cancel_button.pack(side="left", padx=5)
        self.erase_button = ttk.Button(btn_frame, text="Erase Files", command=self.erase_files)
        self.erase_button.pack(side="left", padx=5)

        # Log Frame
        log_frame = ttk.LabelFrame(self, text="Log")
        log_frame.pack(fill="both", expand=True, padx=10, pady=5)
        self.log_text = scrolledtext.ScrolledText(log_frame, wrap="word", state="disabled", height=20)
        self.log_text.pack(fill="both", expand=True)

    def log(self, message):
        print(message)
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

    def erase_files(self):
        if messagebox.askyesno("Confirm Erase", "Are you sure you want to delete all files in 'geo files' and 'cfg files'?"):
            for directory in ["geo files", "cfg files"]:
                if os.path.exists(directory):
                    for filename in os.listdir(directory):
                        file_path = os.path.join(directory, filename)
                        try:
                            if os.path.isfile(file_path):
                                os.remove(file_path)
                                self.log(f"Removed file: {file_path}")
                        except Exception as e:
                            self.log(f"Error removing {file_path}: {e}")
                else:
                    self.log(f"Directory '{directory}' does not exist.")
        else:
            self.log("Erase files cancelled by user.")

    def update_progress(self, progress_bar, percent_label, time_label, current, total, stage_start_time):
        percent = int((current / total) * 100)
        progress_bar["value"] = current
        percent_label.config(text=f"{percent}%")
        elapsed = time.time() - stage_start_time - self.stage_pause_duration
        if current > 0:
            estimated_total = elapsed / current * total
            time_left = estimated_total - elapsed
            time_label.config(text=f"Est. remaining: {format_time(time_left)}")
        else:
            time_label.config(text="Est. remaining: calculating...")

    def toggle_pause(self):
        if not self.paused:
            self.paused = True
            self.pause_start = time.time()
            self.hold_button.config(text="Resume")
            if self.current_proc is not None and self.current_command and "SU2_CFD" in self.current_command:
                try:
                    os.killpg(self.current_proc.pid, signal.SIGSTOP)
                    self.log("CFD subprocess group paused (SIGSTOP sent).")
                except Exception as e:
                    self.log("Error pausing subprocess group: " + str(e))
            self.log("Process paused.")
        else:
            self.paused = False
            paused_duration = time.time() - self.pause_start
            self.stage_pause_duration += paused_duration
            self.hold_button.config(text="Hold")
            if self.current_proc is not None and self.current_command and "SU2_CFD" in self.current_command:
                try:
                    os.killpg(self.current_proc.pid, signal.SIGCONT)
                    self.log("CFD subprocess group resumed (SIGCONT sent).")
                except Exception as e:
                    self.log("Error resuming subprocess group: " + str(e))
            self.log("Process resumed.")

    def cancel_process(self):
        self.cancelled = True
        self.log("Cancellation requested.")
        if self.current_proc:
            try:
                self.current_proc.kill()
                self.log("Terminated running subprocess.")
            except Exception as e:
                self.log("Error terminating subprocess: " + str(e))

    def wait_if_paused(self):
        while self.paused:
            self.update()
            time.sleep(0.1)

    def start_process(self):
        self.cancelled = False
        self.paused = False
        self.stage_pause_duration = 0
        self.hold_button.config(text="Hold")
        self.current_proc = None
        self.current_command = None
        self.cfg_progress["value"] = 0
        self.cfd_progress["value"] = 0
        self.cfg_percent_label.config(text="0%")
        self.cfd_percent_label.config(text="0%")
        self.cfg_time_label.config(text="")
        self.cfd_time_label.config(text="")
        self.log_text.configure(state="normal")
        self.log_text.delete("1.0", tk.END)
        self.log_text.configure(state="disabled")

        self.current_cfg_iteration = 0
        self.current_cfd_iteration = 0
        self.stage_pause_duration = 0
        self.cfg_start_time = time.time()

        threading.Thread(target=self.run_process, daemon=True).start()

    def run_process(self):
        try:
            bp_values = [float(x.strip()) for x in self.bp_entry.get().split(",")]
            mach_values = [float(x.strip()) for x in self.mach_entry.get().split(",")]
            ramp_lengths = [float(x.strip()) for x in self.ramp_length_entry.get().split(",")]
            theta_angles = [float(x.strip()) for x in self.theta_entry.get().split(",")]
            ramp_nums = [x.strip() for x in self.ramp_nums_entry.get().split(",")]
        except Exception as e:
            self.log("Error parsing parameters: " + str(e))
            return

        altitude = 10000
        equal_ramps = "Y"

        self.total_cfg_iterations = len(ramp_nums) * len(mach_values) * len(ramp_lengths) * len(theta_angles) * len(bp_values)
        self.cfg_progress["maximum"] = self.total_cfg_iterations
        self.stage_pause_duration = 0
        cfg_start_time = time.time()

        def get_cfg_filename(rn, M, ramp_len, angle, bp):
            M_str = str(M)
            angle_str = str(angle)
            back_p = str(bp)
            if rn == "2":
                name_2 = f"{ramp_len}_{ramp_len}"
            elif rn == "3":
                name_2 = f"{ramp_len}_{ramp_len}_{ramp_len}"
            elif rn == "4":
                name_2 = f"{ramp_len}_{ramp_len}_{ramp_len}_{ramp_len}"
            elif rn == "5":
                name_2 = f"{ramp_len}_{ramp_len}_{ramp_len}_{ramp_len}_{ramp_len}"
            else:
                raise ValueError("Unsupported ramp number in get_cfg_filename.")
            return f"{M_str}_{name_2}_{angle_str}_{back_p}.cfg"

        # Step 1: Generate .cfg Files
        for rn in ramp_nums:
            for mach in mach_values:
                for rl in ramp_lengths:
                    for th in theta_angles:
                        for bp in bp_values:
                            self.wait_if_paused()
                            if self.cancelled:
                                self.log("Process cancelled during CFG generation.")
                                return
                            ml = "No"
                            input_str = (f"{rn}\n{mach}\n{altitude}\n{equal_ramps}\n{rl}\n{th}\n{bp}\n{ml}\n")
                            self.log("---------------------------------------------------")
                            self.log(f"Running point calculator for: Ramp={rn}, Mach={mach}, RampLen={rl}, Theta={th}, BP={bp}")
                            try:
                                self.current_proc = subprocess.Popen(
                                    ["python", "point calculator.py"],
                                    stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE,
                                    text=True
                                )
                                self.current_proc.stdin.write(input_str)
                                self.current_proc.stdin.flush()
                                while self.current_proc.poll() is None:
                                    self.wait_if_paused()
                                    if self.cancelled:
                                        self.current_proc.kill()
                                        self.log("Point calculator subprocess cancelled.")
                                        break
                                    time.sleep(0.1)
                                out, err = self.current_proc.communicate(timeout=1)
                            except Exception as e:
                                self.log(f"Subprocess error for Ramp={rn}, Mach={mach}, RampLen={rl}, Theta={th}, BP={bp}: {e}")
                                continue
                            finally:
                                self.current_proc = None

                            base_cfg = get_cfg_filename(rn, mach, rl, th, bp)
                            cfg_path = os.path.join("cfg files", base_cfg)
                            if not os.path.exists(cfg_path):
                                self.log(f"WARNING: Expected .cfg file {cfg_path} not found.")
                            else:
                                self.log(f"Generated cfg file: {cfg_path}")
                            self.current_cfg_iteration += 1
                            self.update_progress(self.cfg_progress, self.cfg_percent_label, self.cfg_time_label,
                                                 self.current_cfg_iteration, self.total_cfg_iterations, cfg_start_time)

        self.log("CFG file generation completed.")

        # Step 2: Run CFD Simulations
        cfg_files = sorted(glob.glob(os.path.join("cfg files", "*.cfg")))
        if not cfg_files:
            self.log("No .cfg files found for CFD simulations.")
            return

        self.total_cfd_iterations = len(cfg_files)
        self.cfd_progress["maximum"] = self.total_cfd_iterations
        self.stage_pause_duration = 0
        cfd_start_time = time.time()

        for cfg_file in cfg_files:
            self.wait_if_paused()
            if self.cancelled:
                self.log("Process cancelled during CFD simulations.")
                return
            config_filename = os.path.basename(cfg_file)
            self.log(f"Starting simulation for: {config_filename}")
            command = ["mpirun", "-n", "6", "SU2_CFD", config_filename]
            self.log("Executing command: " + " ".join(command))
            self.current_command = command
            try:
                self.current_proc = subprocess.Popen(
                    command,
                    cwd="cfg files",
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    preexec_fn=os.setsid
                )
                while True:
                    self.wait_if_paused()
                    if self.cancelled:
                        self.current_proc.kill()
                        self.log("CFD subprocess cancelled.")
                        break
                    output_line = self.current_proc.stdout.readline()
                    if output_line:
                        print(output_line.strip())
                    if output_line == "" and self.current_proc.poll() is not None:
                        break
                self.current_proc.wait()
            except Exception as e:
                self.log("Error running CFD simulation for: " + config_filename)
                self.log("Error: " + str(e))
            finally:
                self.current_proc = None

            self.log("CFD simulation completed for: " + config_filename)
            self.current_cfd_iteration += 1
            self.update_progress(self.cfd_progress, self.cfd_percent_label, self.cfd_time_label,
                                 self.current_cfd_iteration, self.total_cfd_iterations, cfd_start_time)

        self.log("CFD simulations completed.")


    def log(self, message):
        print(message)
        self.log_text.configure(state="normal")
        self.log_text.insert(tk.END, message + "\n")
        self.log_text.see(tk.END)
        self.log_text.configure(state="disabled")

if __name__ == "__main__":
    app = Application()
    app.mainloop()