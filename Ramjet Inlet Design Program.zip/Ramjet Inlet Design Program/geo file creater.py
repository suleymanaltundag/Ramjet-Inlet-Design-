import os
import subprocess
from datetime import datetime
import textwrap

def convert_geo_to_su2(geo_filepath, dimension=2):
    """
    Mesh a .geo file with Gmsh and create a .su2 file.
    This function replicates the default behavior of the Gmsh 2D Mesh button.
    If you later get partitioning errors in SU2, consider adding
      MESH_PARTITIONING=NO
    to your SU2 configuration file or running SU2 in serial.
    """
    gmsh_flag = "-2" if dimension == 2 else "-3"
    su2_filepath = geo_filepath.rsplit(".", 1)[0] + ".su2"

    command = [
        "gmsh", gmsh_flag, geo_filepath,
        "-o", su2_filepath, "-format", "su2"
    ]
    print("Executing command:", " ".join(command))

    result = subprocess.run(
        command,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    if result.stdout:
        print("Gmsh Output:\n", result.stdout)
    if result.stderr:
        print("Gmsh Errors:\n", result.stderr)

    if result.returncode != 0:
        # If SU2 file exists despite nonzero exit, warn; otherwise fail.
        if os.path.exists(su2_filepath) and os.path.getsize(su2_filepath) > 0:
            print(f"SU2 file created with warnings: {su2_filepath}")
        else:
            raise RuntimeError(
                f"Meshing failed! Gmsh exited with code {result.returncode}."
            )
    else:
        print(f"SU2 file successfully created: {su2_filepath}")


def is_ml(ml, ramp_num):
    """
    Returns a create_geo_file function for the given ML flag ("Yes" or "No")
    and ramp number (e.g. "2", "3", "4", "5"). That returned function
    will read the matching template from the 'geo file template' folder,
    substitute all placeholders, write the .geo file to 'geo files/',
    and then mesh it to produce the corresponding .su2 file.
    """
    # Validate inputs
    if ml not in ("Yes", "No"):
        raise ValueError("Unsupported ml value. Use 'Yes' or 'No'.")

    try:
        rn = int(ramp_num)
    except ValueError:
        raise ValueError("ramp_num must be a string like '2', '3', '4', or '5'.")

    template_dir = "geo file template"
    template_filename = f"ramp{rn}_{ml}.txt"
    template_path = os.path.join(template_dir, template_filename)
    if not os.path.exists(template_path):
        raise FileNotFoundError(f"Geo template not found: {template_path}")

    def create_geo_file(name_1, name_2, name_3, name_4,
                        *args,
                        directory="geo files"):
        """
        name_1..4: arbitrary name components used for the .geo filename
        *args: first (rn+2) items are point tuples (x,y);
               next rn items are ramp lengths;
               e.g. for rn=3: args = (pt1,pt2,pt3,pt4,pt5, ramp1,ramp2,ramp3)
        directory: output directory for the .geo and .su2 files
        """
        # Prepare output path
        os.makedirs(directory, exist_ok=True)
        geo_filename = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
        full_path = os.path.join(directory, geo_filename)

        now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")
        # mesh_ratio depends on ML flag
        mesh_ratio = 2000 if ml == "Yes" else 1000
        # Split args into points and ramps
        num_points = rn + 2
        points = args[:num_points]
        ramps = args[num_points:num_points + rn]

        # Build context for f-string evaluation
        context = {
            "now_str": now_str,
            "mesh_ratio": mesh_ratio
        }
        # Inject point coordinates
        for i, (px, py) in enumerate(points, start=1):
            context[f"point{i}_x"] = px
            context[f"point{i}_y"] = py
        # Inject ramp values
        for j, rv in enumerate(ramps, start=1):
            context[f"ramp{j}"] = rv

        # Compute size_ratio as in original templates
        context["size_ratio"] = (
            context[f"point{num_points}_x"] - context["point1_x"]
        ) / 0.6

        # Read the template and substitute placeholders
        with open(template_path, "r") as tf:
            template = tf.read()
        geo_content = eval(f"f'''{template}'''", context)

        # Append any common meshing directives
        meshing_commands = textwrap.dedent("""\
            // --- Additional meshing directives ---
            Physical Surface("domain") = {1};
        """)
        geo_content += "\n" + meshing_commands

        # Write out the .geo file
        with open(full_path, "w") as f:
            f.write(geo_content)
        print(f".geo file created: {full_path}")

        # Run Gmsh → SU2 conversion
        convert_geo_to_su2(full_path, dimension=2)

    return create_geo_file
