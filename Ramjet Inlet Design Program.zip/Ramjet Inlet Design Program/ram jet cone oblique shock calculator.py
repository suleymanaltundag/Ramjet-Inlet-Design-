import math


def fTMydotcone(theta, y1, y2, gamma):
    """
    Computes the derivatives for the Taylor–Maccoll ODE system.

    The ODEs are:
        dy1/dtheta = y2
        dy2/dtheta = [ y2² * y1 - ((gamma-1)/2) * (1 - y1² - y2²) * (2*y1 + y2/tan(theta)) ]
                     / [ ((gamma-1)/2) * (1 - y1² - y2²) - y2² ]

    Parameters:
        theta (float): Current polar angle (radians).
        y1 (float): Radial velocity component (normalized).
        y2 (float): Tangential velocity component (normalized).
        gamma (float): Specific heat ratio.

    Returns:
        tuple: (dy1/dtheta, dy2/dtheta).
    """
    dydt1 = y2
    numerator = y2 ** 2 * y1 - ((gamma - 1) / 2.0) * (1 - y1 ** 2 - y2 ** 2) * (2 * y1 + y2 / math.tan(theta))
    denominator = ((gamma - 1) / 2.0) * (1 - y1 ** 2 - y2 ** 2) - y2 ** 2
    dydt2 = numerator / denominator
    return dydt1, dydt2


def oblique_cone_calculator(M1, gamma, theta_deg=None, beta_deg=None):
    """
    Calculates the oblique shock cone parameters.

    Depending on which angle is provided:

      - If theta_deg (cone half-angle, in degrees) is given, this function computes
        the shock wave angle beta (in degrees) and the cone Mach number Mc using a bisection
        method with RK4 integration.

      - If beta_deg (shock wave angle, in degrees) is given, the function computes the
        cone half-angle theta (in degrees) and Mc using RK4 integration.

    Parameters:
        M1 (float): Upstream Mach number.
        gamma (float): Specific heat ratio (default 1.4).
        theta_deg (float, optional): Cone half-angle in degrees.
        beta_deg (float, optional): Shock wave angle in degrees.

    Returns:
        dict: A dictionary with keys 'gamma', 'M1', 'Mc', 'theta_deg', and 'beta_deg'.
    """

    computed_beta = None
    computed_theta = None
    Mc = None

    # --- Branch 1: Compute beta from M1 and theta ---
    if theta_deg is not None:
        theta = math.radians(theta_deg)  # convert cone angle to radians
        beta_max = math.pi / 2.0
        beta_min = math.asin(1.0 / M1)  # minimum shock angle
        tolinner = 1.0e-8
        tolouter = 1.0e-8
        thetacm = 50.0  # an arbitrarily large initial value
        ii = 0

        while abs(thetacm - theta) > tolouter and ii < 200:
            beta_mean = (beta_min + beta_max) / 2.0

            # Calculate delta from the shock relations
            delta = math.atan(
                (2.0 / math.tan(beta_mean)) * (M1 ** 2 * math.sin(beta_mean) ** 2 - 1.0) /
                (M1 ** 2 * (gamma + math.cos(2.0 * beta_mean)) + 2.0)
            )
            # Compute downstream Mach number M2
            M2 = (1.0 / math.sin(beta_mean - delta)) * math.sqrt(
                ((gamma - 1.0) * M1 ** 2 * math.sin(beta_mean) ** 2 + 2.0) /
                (2.0 * gamma * M1 ** 2 * math.sin(beta_mean) ** 2 - (gamma - 1.0))
            )
            # Compute normalized velocity magnitude v2
            v2 = 1.0 / math.sqrt(1.0 + 2.0 / ((gamma - 1.0) * M2 ** 2))
            # Initial velocity components immediately behind the shock
            vr0 = v2 * math.cos(beta_mean - delta)
            vtheta0 = -v2 * math.sin(beta_mean - delta)

            # Set up integration starting at the shock (angle = beta_mean)
            t_angle = beta_mean
            y1 = vr0
            y2 = vtheta0
            i = 0

            # Integrate the Taylor–Maccoll ODE using RK4 until |y2| is below inner tolerance.
            while abs(y2) > tolinner and i < 500000:
                h = -abs(y2) * 0.0001  # step size (integration is performed "backward" in theta)
                k11, k12 = fTMydotcone(t_angle, y1, y2, gamma)
                k21, k22 = fTMydotcone(t_angle + h / 2.0, y1 + h * k11 / 2.0, y2 + h * k12 / 2.0, gamma)
                k31, k32 = fTMydotcone(t_angle + h / 2.0, y1 + h * k21 / 2.0, y2 + h * k22 / 2.0, gamma)
                k41, k42 = fTMydotcone(t_angle + h, y1 + h * k31, y2 + h * k32, gamma)
                y1 += h * (k11 + 2 * k21 + 2 * k31 + k41) / 6.0
                y2 += h * (k12 + 2 * k22 + 2 * k32 + k42) / 6.0
                t_angle += h
                i += 1

            # Compute cone Mach number Mc from the state at the cone surface
            Mc = math.sqrt(2.0 / (((1.0 / (y1 ** 2)) - 1.0) * (gamma - 1.0)))
            thetacm = t_angle  # integrated cone surface angle

            # Update the bisection bounds based on whether integrated theta is less than or greater than target theta.
            if thetacm < theta:
                beta_min = beta_mean
            else:
                beta_max = beta_mean
            ii += 1

        computed_beta = beta_mean  # final shock wave angle (in radians)

    # --- Branch 2: Compute theta from M1 and beta ---
    if beta_deg is not None:
        beta = math.radians(beta_deg)  # convert shock angle to radians
        tolinner = 1.0e-8
        # Calculate delta from the shock relations
        delta = math.atan(
            (2.0 / math.tan(beta)) * (M1 ** 2 * math.sin(beta) ** 2 - 1.0) /
            (M1 ** 2 * (gamma + math.cos(2.0 * beta)) + 2.0)
        )
        # Compute downstream Mach number M2
        M2 = (1.0 / math.sin(beta - delta)) * math.sqrt(
            ((gamma - 1.0) * M1 ** 2 * math.sin(beta) ** 2 + 2.0) /
            (2.0 * gamma * M1 ** 2 * math.sin(beta) ** 2 - (gamma - 1.0))
        )
        # Normalized velocity magnitude v2
        v2 = 1.0 / math.sqrt(1.0 + 2.0 / ((gamma - 1.0) * M2 ** 2))
        # Initial velocity components immediately behind the shock
        vr0 = v2 * math.cos(beta - delta)
        vtheta0 = -v2 * math.sin(beta - delta)

        # Start integration at the shock (angle = beta)
        t_angle = beta
        y1 = vr0
        y2 = vtheta0

        errornew = 99.0
        errorold = 100.0
        h = -0.000001  # fixed integration step

        # Integrate until the error (|y2|) stops decreasing
        while True:
            k11, k12 = fTMydotcone(t_angle, y1, y2, gamma)
            k21, k22 = fTMydotcone(t_angle + h / 2.0, y1 + h * k11 / 2.0, y2 + h * k12 / 2.0, gamma)
            k31, k32 = fTMydotcone(t_angle + h / 2.0, y1 + h * k21 / 2.0, y2 + h * k22 / 2.0, gamma)
            k41, k42 = fTMydotcone(t_angle + h, y1 + h * k31, y2 + h * k32, gamma)
            y1_new = y1 + h * (k11 + 2 * k21 + 2 * k31 + k41) / 6.0
            y2_new = y2 + h * (k12 + 2 * k22 + 2 * k32 + k42) / 6.0
            t_angle_new = t_angle + h
            errorold, errornew = errornew, abs(y2_new)
            y1, y2, t_angle = y1_new, y2_new, t_angle_new
            if errornew > errorold:
                break

        Mc = math.sqrt(2.0 / (((1.0 / (y1 ** 2)) - 1.0) * (gamma - 1.0)))
        computed_theta = t_angle  # final cone half-angle (in radians)

    # Prepare the results. If a branch was not executed, we return the input value.
    result = {
        "gamma": gamma,
        "M1": M1,
        "Mc": Mc,
        "theta_deg": math.degrees(computed_theta) if computed_theta is not None else theta_deg,
        "beta_deg": math.degrees(computed_beta) if computed_beta is not None else beta_deg
    }
    return result


def main():
    print("Oblique Shock Cone Calculator")
    print("-------------------------------")

    # Get upstream Mach number (required)
    while True:
        try:
            M1_input = input("Enter upstream Mach number (M1): ")
            M1 = float(M1_input)
            break
        except ValueError:
            print("Invalid input. Please enter a numeric value for M1.")

    # Get gamma (optional, default 1.4)
    gamma_input = input("Enter gamma (specific heat ratio) [default = 1.4]: ")
    if gamma_input.strip() == "":
        gamma = 1.4
    else:
        try:
            gamma = float(gamma_input)
        except ValueError:
            print("Invalid input. Using default gamma = 1.4.")
            gamma = 1.4

    # Ask user for either theta or beta (or both)
    theta_input = input("Enter cone half-angle theta in degrees (or leave blank if unknown): ")
    beta_input = input("Enter shock wave angle beta in degrees (or leave blank if unknown): ")

    theta_deg = None
    beta_deg = None

    if theta_input.strip() != "":
        try:
            theta_deg = float(theta_input)
        except ValueError:
            print("Invalid theta input. Ignoring theta.")
    if beta_input.strip() != "":
        try:
            beta_deg = float(beta_input)
        except ValueError:
            print("Invalid beta input. Ignoring beta.")

    # Check that at least one of theta or beta was provided.
    if theta_deg is None and beta_deg is None:
        print("Error: You must provide either theta or beta.")
        return

    # Perform the calculation
    results = oblique_cone_calculator(M1, gamma, theta_deg, beta_deg)

    # Display the results
    print("\nComputed Parameters:")
    print(f"  Gamma         = {results['gamma']}")
    print(f"  M1            = {results['M1']}")
    print(f"  Cone Mach (Mc)= {results['Mc']}")
    print(f"  Theta (cone half-angle) = {results['theta_deg']}°")
    print(f"  Beta (shock wave angle) = {results['beta_deg']}°")


if __name__ == "__main__":
    main()
