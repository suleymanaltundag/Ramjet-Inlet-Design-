#!/usr/bin/env python
import os
import glob
import subprocess
import csv
import re
import pandas as pd
import xlsxwriter

# ---------------------------
# Parameter Ranges and Inputs
# ---------------------------
backpressure_constant = [1]  # Back-pressure constant values.
mach_values = [3]                # Upstream Mach numbers.
ramp_lengths = [0.2]             # Ramp lengths.
theta_angles = [11]        # Cone half-angles (degrees).
ramp_nums = ["3"]                # Ramp number options (as strings).

# Fixed inputs for point calculator.py
altitude = 10000
equal_ramps = "Y"
ml="No"


# ---------------------------
# Helper Function for Naming .cfg Files
# ---------------------------
def get_cfg_filename(rn, M, ramp_len, angle, bp):
    M_str = str(M)
    angle_str = str(angle)
    back_p = str(bp)
    if rn == "2":
        name_2 = f"{ramp_len}_{ramp_len}"
    elif rn == "3":
        name_2 = f"{ramp_len}_{ramp_len}_{ramp_len}"
    elif rn == "4":
        name_2 = f"{ramp_len}_{ramp_len}_{ramp_len}_{ramp_len}"
    elif rn == "5":
        name_2 = f"{ramp_len}_{ramp_len}_{ramp_len}_{ramp_len}_{ramp_len}"
    else:
        raise ValueError("Unsupported ramp number in get_cfg_filename.")
    return f"{M_str}_{name_2}_{angle_str}_{back_p}.cfg"


# ---------------------------
# Step 1: Generate .cfg Files
# ---------------------------
def generate_cfg_files():
    for rn in ramp_nums:
        for mach in mach_values:
            for rl in ramp_lengths:
                for th in theta_angles:
                    for bp in backpressure_constant:
                        input_str = (
                            f"{rn}\n"
                            f"{mach}\n"
                            f"{altitude}\n"
                            f"{equal_ramps}\n"
                            f"{rl}\n"
                            f"{th}\n"
                            f"{bp}\n"
                            f"{ml}\n"
                        )
                        print("---------------------------------------------------")
                        print(
                            f"Running point calculator for: "
                            f"Ramp={rn}, Mach={mach}, RampLen={rl}, Theta={th}, BP={bp}"
                        )
                        print("---------------------------------------------------")
                        try:
                            subprocess.run(
                                ["python", "point calculator.py"],
                                input=input_str,
                                text=True,
                                check=True
                            )
                        except subprocess.CalledProcessError as e:
                            print(
                                f"Subprocess failed for Ramp={rn}, Mach={mach}, "
                                f"RampLen={rl}, Theta={th}, BP={bp}: {e}"
                            )
                            continue

                        base_cfg = get_cfg_filename(rn, mach, rl, th, bp)
                        cfg_path = os.path.join("cfg files", base_cfg)
                        if not os.path.exists(cfg_path):
                            print(f"WARNING: Expected .cfg file {cfg_path} not found.")
                        else:
                            print(f"Generated cfg file: {cfg_path}")


# ---------------------------
# Step 2: Run CFD Simulations
# ---------------------------
def run_cfd_simulations(cfg_dir="cfg files",
                        num_procs=6,
                        simulation_command="SU2_CFD"):
    cfg_files = sorted(glob.glob(os.path.join(cfg_dir, "*.cfg")))
    if not cfg_files:
        print(f"No .cfg files found in '{cfg_dir}'.")
        return

    for cfg_file in cfg_files:
        config_filename = os.path.basename(cfg_file)
        print(f"\nStarting simulation for: {config_filename}")
        command = ["mpirun", "-n", str(num_procs), simulation_command, config_filename]
        print("Executing command:", " ".join(command))
        try:
            subprocess.run(command, check=True, cwd=cfg_dir)
            print("CFD simulation completed successfully for:", config_filename)
        except subprocess.CalledProcessError as e:
            print("Error running CFD simulation for:", config_filename)
            print("Error:", e)


# ---------------------------
# Step 3: Write Fixed-Width CSV
# ---------------------------
def write_fixed_width_csv(header, rows, output_csv, col_width=20):
    with open(output_csv, "w") as f:
        header_line = ", ".join(f"{h:>{col_width}}" for h in header)
        f.write(header_line + "\n")
        for row in rows:
            line = ", ".join(f"{row.get(h, ''):>{col_width}}" for h in header)
            f.write(line + "\n")
    print(f"Data successfully written in fixed-width format to {output_csv}")


# ---------------------------
# Step 4: Collect Results (no Critical_Points)
# ---------------------------
def collect_results():
    csv_folder = "csv files"
    os.makedirs(csv_folder, exist_ok=True)
    output_csv   = os.path.join(csv_folder, "data.csv")
    diverged_csv = os.path.join(csv_folder, "diverged.csv")

    def round_if_float(val, decimals=6):
        try:
            return f"{float(val):.{decimals}f}"
        except:
            return val

    base_header = [
        "BaseName",
        "Cfg_MACH_NUMBER",
        "Cfg_FREESTREAM_PRESSURE",
        "Cfg_FREESTREAM_TEMPERATURE",
        "Cfg_MARKER_OUTLET",
        "Ramp_Lengths",
        "Theta",
        "Backpressure_constant",
        "Pressure_Recovery_Coefficient",
        "Avg_Massflow_outlet",
        "Avg_Mach_outlet",
        "Avg_TotalTemp_outlet",
        "Avg_TotalPress(outlet)"
    ]

    rows = []
    diverged_ids = []

    for cfg_path in glob.glob(os.path.join("cfg files", "*.cfg")):
        base_name    = os.path.splitext(os.path.basename(cfg_path))[0]
        history_path = os.path.join("cfg files", base_name + "_history.csv")

        if not os.path.exists(history_path):
            print(f"Warning: history file for {base_name} not found. Skipping.")
            diverged_ids.append([base_name])
            continue

        # Read history.csv
        with open(history_path, newline="") as f:
            reader    = csv.DictReader(f)
            hist_rows = list(reader)
        if not hist_rows:
            print(f"No history data in {history_path}. Skipping.")
            diverged_ids.append([base_name])
            continue

        last = hist_rows[-1]

        # Robust divergence check via any header containing 'rms' and 'rho'
        rms_value = None
        for key, val in last.items():
            cleaned = re.sub(r'[^a-z0-9]', '', key.lower())
            if 'rms' in cleaned and 'rho' in cleaned:
                rms_value = val.strip()
                break

        if rms_value is None:
            print(f"No RMS[Rho] field found in {base_name} → marking diverged")
            diverged_ids.append([base_name])
            continue

        try:
            parts = rms_value.replace(" ", "").split("+")
            val = sum(float(p) for p in parts)
            if val > -5:
                print(f"Diverged {base_name} (rms[Rho]={val})")
                diverged_ids.append([base_name])
                continue
        except Exception as e:
            print(f"Error parsing rms[Rho]='{rms_value}' in {base_name}: {e} → marking diverged")
            diverged_ids.append([base_name])
            continue

        # Read cfg params
        cfg_data = {}
        with open(cfg_path) as cf:
            for line in cf:
                line = line.split("%")[0].strip()
                if line.startswith("MACH_NUMBER="):
                    cfg_data["MACH_NUMBER"] = line.split("=", 1)[1].strip()
                elif line.startswith("FREESTREAM_PRESSURE="):
                    cfg_data["FREESTREAM_PRESSURE"] = line.split("=", 1)[1].strip()
                elif line.startswith("FREESTREAM_TEMPERATURE="):
                    cfg_data["FREESTREAM_TEMPERATURE"] = line.split("=", 1)[1].strip()
                elif line.startswith("MARKER_OUTLET="):
                    m = re.search(r"MARKER_OUTLET=\s*\(\s*outlet\s*,\s*([-\d\.eE+]+)", line)
                    if m:
                        cfg_data["MARKER_OUTLET"] = m.group(1)

        # Parse filename metadata
        parts = base_name.split("_")
        if len(parts) < 4:
            print(f"Filename {base_name} not conforming → skipping")
            diverged_ids.append([base_name])
            continue
        ramp_lengths_str   = "_".join(parts[1:-2])
        theta              = parts[-2]
        backpressure_const = parts[-1]

        # Outlet stats from history
        mf = last.get("Avg_Massflow(outlet)", "")
        mm = last.get("Avg_Mach(outlet)", "")
        tt = last.get("Avg_TotalTemp(outlet)", "")
        tp = last.get("Avg_TotalPress(outlet)", "")

        # Compute pressure recovery
        try:
            p_in   = float(cfg_data.get("FREESTREAM_PRESSURE", 0))
            M_in   = float(cfg_data.get("MACH_NUMBER", 0))
            γ      = 1.4
            p0_in  = p_in * (1 + (γ - 1)/2 * M_in**2) ** (γ/(γ-1))
            p0_out = float(tp or 0)
            pr     = p0_out / p0_in if p0_in else ""
        except:
            pr = ""

        # Negate massflow if numeric
        try:
            mf = -1 * float(mf)
        except:
            pass

        row = {
            "BaseName":                      base_name,
            "Cfg_MACH_NUMBER":               round_if_float(cfg_data.get("MACH_NUMBER","")),
            "Cfg_FREESTREAM_PRESSURE":       round_if_float(cfg_data.get("FREESTREAM_PRESSURE","")),
            "Cfg_FREESTREAM_TEMPERATURE":    round_if_float(cfg_data.get("FREESTREAM_TEMPERATURE","")),
            "Cfg_MARKER_OUTLET":             round_if_float(cfg_data.get("MARKER_OUTLET","")),
            "Ramp_Lengths":                  ramp_lengths_str,
            "Theta":                         theta,
            "Backpressure_constant":         backpressure_const,
            "Pressure_Recovery_Coefficient": round_if_float(pr),
            "Avg_Massflow_outlet":           round_if_float(mf),
            "Avg_Mach_outlet":               round_if_float(mm),
            "Avg_TotalTemp_outlet":          round_if_float(tt),
            "Avg_TotalPress(outlet)":        round_if_float(tp)
        }
        rows.append(row)

    # Write out data.csv
    write_fixed_width_csv(base_header, rows, output_csv, col_width=20)

    # Write diverged.csv
    with open(diverged_csv, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["Skipped_BaseName"])
        writer.writerows(diverged_ids)
    print(f"Diverged file created: {diverged_csv}")


# ---------------------------
# New Function to Remove Rows Based on Avg_Mach_outlet
# ---------------------------
def remove_mach_outlier_rows():
    data_csv = os.path.join("csv files", "data.csv")
    if not os.path.exists(data_csv):
        print(f"{data_csv} not found.")
        return

    df = pd.read_csv(data_csv, skipinitialspace=True)
    df.columns = df.columns.str.strip()

    if "Avg_Mach_outlet" not in df.columns:
        print("Column 'Avg_Mach_outlet' not found. Available columns:", df.columns.tolist())
        return

    df["Avg_Mach_outlet"] = pd.to_numeric(df["Avg_Mach_outlet"], errors="coerce")
    df_cleaned = df[(df["Avg_Mach_outlet"] >= 0.1) & (df["Avg_Mach_outlet"] <= 0.81)]
    df_cleaned.to_csv(data_csv, index=False)
    print(f"Removed rows with 'Avg_Mach_outlet' > 0.8 or < 0.1 from {data_csv}.")


# ---------------------------
# New Function to Remove Rows Based on Avg_Massflow_outlet
# ---------------------------
def remove_massflow_outlier_rows():
    data_csv = os.path.join("csv files", "data.csv")
    if not os.path.exists(data_csv):
        print(f"{data_csv} not found.")
        return

    df = pd.read_csv(data_csv, skipinitialspace=True)
    df.columns = df.columns.str.strip()

    if "Avg_Massflow_outlet" not in df.columns:
        print("Column 'Avg_Massflow_outlet' not found. Available columns:", df.columns.tolist())
        return

    df["Avg_Massflow_outlet"] = pd.to_numeric(df["Avg_Massflow_outlet"], errors="coerce")
    df_cleaned = df[(df["Avg_Massflow_outlet"] >= 0.1) & (df["Avg_Massflow_outlet"] <= 1000)]
    df_cleaned.to_csv(data_csv, index=False)
    print(f"Removed rows with 'Avg_Massflow_outlet' > 1000 or < 1 from {data_csv}.")


# ---------------------------
# New Function to Keep Only Highest Pressure Recovery per ID Group
# ---------------------------
def filter_pressure_recovery_by_prefix():
    data_csv = os.path.join("csv files", "data.csv")
    if not os.path.exists(data_csv):
        print(f"{data_csv} not found.")
        return

    df = pd.read_csv(data_csv, skipinitialspace=True)
    df.columns = df.columns.str.strip()

    if "BaseName" not in df.columns or "Pressure_Recovery_Coefficient" not in df.columns:
        print("Required columns not found. Available columns:", df.columns.tolist())
        return

    # Convert to numeric for comparison
    df["Pressure_Recovery_Coefficient"] = pd.to_numeric(df["Pressure_Recovery_Coefficient"], errors="coerce")

    # Extract ID prefix by removing the last underscore segment (the back-pressure ratio)
    df["ID_prefix"] = df["BaseName"].astype(str).apply(lambda x: "_".join(x.split("_")[:-1]))

    # For each group of same prefix, keep only the row with the maximum pressure recovery
    idx = df.groupby("ID_prefix")["Pressure_Recovery_Coefficient"].idxmax()
    df_filtered = df.loc[idx].drop(columns=["ID_prefix"])

    # Overwrite data.csv with filtered results
    df_filtered.to_csv(data_csv, index=False)
    print(f"Filtered rows by highest Pressure_Recovery_Coefficient for duplicate IDs in {data_csv}.")


# ---------------------------
# Analysis Functions for ID Files
# ---------------------------
def analyze_ids(input_csv, output_file, id_column):
    """
    Reads the given CSV (IDs in id_column),
    parses each ID "MACH_R1_R2_..._Theta_BP"
    and writes summary tables to an XLSX.
    """
    try:
        df_ids = pd.read_csv(input_csv)
    except Exception as e:
        print(f"Error reading {input_csv}: {e}")
        return

    df_ids.columns = df_ids.columns.str.strip()
    if id_column not in df_ids.columns:
        df_ids = pd.read_csv(input_csv, header=None, names=[id_column])

    if df_ids.empty:
        print(f"No entries found in {input_csv}, skipping analysis.")
        return

    def parse_id(x):
        parts = str(x).strip().split('_')
        try:
            mach = float(parts[0])
        except:
            mach = None
        try:
            theta = float(parts[-2])
        except:
            theta = None
        try:
            bp = float(parts[-1])
        except:
            bp = None
        try:
            ramps = list(map(float, parts[1:-2]))
            rc = len(ramps)
        except:
            ramps = []
            rc = 0
        return {'Mach': mach,
                'RampCount': rc,
                'RampLengths': ramps,
                'Theta': theta,
                'BackPressure': bp}

    parsed = df_ids[id_column].apply(parse_id).tolist()
    dfp = pd.DataFrame(parsed)

    if 'Mach' not in dfp.columns:
        print(f"No valid IDs parsed from {input_csv}, skipping analysis.")
        return

    # Single-variable summaries
    sections = [
        ("Mach Summary",        dfp['Mach'].value_counts().sort_index().reset_index()
                                 .rename(columns={'index':'Mach','Mach':'Count'})),
        ("Ramp Count Summary",  dfp['RampCount'].value_counts().sort_index().reset_index()
                                 .rename(columns={'index':'RampCount','RampCount':'Count'})),
        ("Theta Summary",       dfp['Theta'].value_counts().sort_index().reset_index()
                                 .rename(columns={'index':'Theta','Theta':'Count'})),
        ("Back Pressure Summary", dfp['BackPressure'].value_counts().sort_index().reset_index()
                                  .rename(columns={'index':'BackPressure','BackPressure':'Count'})),
        ("Ramp Lengths Summary",  dfp['RampLengths'].apply(tuple).value_counts().sort_index().reset_index()
                                  .rename(columns={'index':'RampLengths','RampLengths':'Count'}))
    ]

    # Multi-variable summaries
    combos = [
        (['RampCount','Theta'],             "Ramp Count + Theta Summary"),
        (['RampCount','BackPressure'],      "Ramp Count + Back Pressure Summary"),
        (['Theta','BackPressure'],          "Theta + Back Pressure Summary"),
        (['Mach','RampCount'],              "Mach + Ramp Count Summary"),
        (['Mach','Theta'],                  "Mach + Theta Summary"),
        (['Mach','BackPressure'],           "Mach + Back Pressure Summary"),
        (['RampCount','Theta','BackPressure'],      "Ramp Count + Theta + Back Pressure Summary"),
        (['Mach','RampCount','Theta'],               "Mach + Ramp Count + Theta Summary"),
        (['Mach','RampCount','BackPressure'],        "Mach + Ramp Count + Back Pressure Summary"),
        (['Mach','Theta','BackPressure'],           "Mach + Theta + Back Pressure Summary"),
        (['Mach','RampCount','Theta','BackPressure'], "Mach + Ramp Count + Theta + Back Pressure Summary")
    ]
    for cols, title in combos:
        tbl = dfp.groupby(cols).size().reset_index(name='Count')
        sections.append((title, tbl))

    # Write to Excel
    wb = xlsxwriter.Workbook(output_file)
    ws = wb.add_worksheet("Analysis")
    title_fmt     = wb.add_format({'bg_color':'#ADD8E6','bold':True,'align':'center'})
    separator_fmt = wb.add_format({'bg_color':'#FF0000'})
    default_fmt   = wb.add_format()
    row = 0
    for title, df_sec in sections:
        ws.merge_range(row, 0, row, len(df_sec.columns)-1, title, title_fmt)
        row += 1
        for c, name in enumerate(df_sec.columns):
            ws.write(row, c, name, default_fmt)
        row += 1
        for _, rec in df_sec.iterrows():
            for c, val in enumerate(rec):
                if isinstance(val, tuple):
                    val = ','.join(map(str, val))
                ws.write(row, c, val, default_fmt)
            row += 1
        for c in range(len(df_sec.columns)):
            ws.write(row, c, "", separator_fmt)
        row += 1
    wb.close()
    print(f"Analysis saved to {output_file}")


def visualize_analysis():
    """
    Generate visualization Excel files with charts for both diverged and converged datasets,
    including axis titles on every chart, and a point‐only scatter on the converged file.
    """
    import os
    import pandas as pd
    import xlsxwriter

    csv_folder = "csv files"
    datasets = [
        ("diverged.csv", "diverged_visualization.xlsx", False),
        ("data.csv",      "converged_visualization.xlsx", True)
    ]

    for csv_file, out_xlsx, include_scatter in datasets:
        path_csv = os.path.join(csv_folder, csv_file)
        if not os.path.exists(path_csv):
            print(f"File {path_csv} not found for visualization, skipping.")
            continue

        df = pd.read_csv(path_csv)
        df.columns = df.columns.str.strip()

        # Determine ID series
        if include_scatter:
            ids = df["BaseName"]
        else:
            ids = df.get("Skipped_BaseName", df.iloc[:, 0])

        # Parse ID into metadata
        parsed = ids.astype(str).str.split("_")
        meta = pd.DataFrame({
            "Mach":           parsed.apply(lambda p: float(p[0]) if p else None),
            "RampCount":      parsed.apply(lambda p: len(p[1:-2]) if len(p) > 2 else 0),
            "Theta":          parsed.apply(lambda p: float(p[-2]) if len(p) > 2 else None),
            "BackPressure":   parsed.apply(lambda p: float(p[-1]) if p else None),
            "RampLengths":    parsed.apply(lambda p: "_".join(p[1:-2]) if len(p) > 3 else "")
        })

        # Create workbook
        wb = xlsxwriter.Workbook(os.path.join(csv_folder, out_xlsx))
        ws = wb.add_worksheet("Charts")
        title_fmt = wb.add_format({"bg_color":"#ADD8E6","bold":True,"align":"center"})
        row = 0

        # Five summaries
        summaries = [
            ("Mach Summary",          meta["Mach"]),
            ("Ramp Count Summary",    meta["RampCount"]),
            ("Theta Summary",         meta["Theta"]),
            ("Back Pressure Summary", meta["BackPressure"]),
            ("Ramp Lengths Summary",  meta["RampLengths"])
        ]

        for title, series in summaries:
            tbl = series.value_counts().sort_index().reset_index(name="Count")
            ws.merge_range(row, 0, row, 1, title, title_fmt)
            ws.write_row(row+1, 0, tbl.columns.tolist())
            for i, rec in enumerate(tbl.itertuples(index=False), start=2):
                ws.write_row(row+i, 0, list(rec))

            chart = wb.add_chart({"type":"column"})
            chart.add_series({
                "name":       title,
                "categories": ["Charts", row+2, 0, row+1+len(tbl), 0],
                "values":     ["Charts", row+2, 1, row+1+len(tbl), 1],
            })
            chart.set_title({"name": title})
            chart.set_x_axis({"name": tbl.columns[0]})
            chart.set_y_axis({"name": "Count"})
            ws.insert_chart(row, 3, chart)

            row += len(tbl) + 4

        # Point‐only Scatter for converged only
        if include_scatter:
            wss = wb.add_worksheet("Scatter")
            cols = ["Avg_Mach_outlet", "Avg_Massflow_outlet", "Pressure_Recovery_Coefficient"]
            wss.write_row(0, 0, cols)
            for i, vals in enumerate(df[cols].itertuples(index=False), start=1):
                wss.write_row(i, 0, vals)

            ch = wb.add_chart({"type": "scatter", "subtype": "marker"})
            ch.add_series({
                "name":       "Mach vs Massflow",
                "categories": ["Scatter", 1, 0, len(df), 0],
                "values":     ["Scatter", 1, 1, len(df), 1],
                "marker":     {"type": "automatic"},
                "line":       {"none": True}
            })
            ch.set_title({"name": "Mach vs Massflow"})
            ch.set_x_axis({"name": "Average Mach Outlet"})
            ch.set_y_axis({"name": "Average Massflow Outlet"})
            wss.insert_chart("E2", ch)

        wb.close()
        print(f"Visualization saved to {out_xlsx}")


def run_analysis():
    csv_folder = "csv files"
    os.makedirs(csv_folder, exist_ok=True)
    diverged_input  = os.path.join(csv_folder, "diverged.csv")
    diverged_output = os.path.join(csv_folder, "diverged_analysis.xlsx")
    analyze_ids(diverged_input, diverged_output, "Skipped_BaseName")

    converged_input  = os.path.join(csv_folder, "data.csv")
    converged_output = os.path.join(csv_folder, "converged_analysis.xlsx")
    analyze_ids(converged_input, converged_output, "BaseName")


# ---------------------------
# New Function to Keep Only Rows Whose IDs Are in checked_data.csv
# ---------------------------
def filter_data_by_checked_ids():
    data_csv    = os.path.join("csv files", "data.csv")
    checked_csv = os.path.join("csv files", "checked_data.csv")

    # Check existence
    if not os.path.exists(data_csv):
        print(f"{data_csv} not found.")
        return
    if not os.path.exists(checked_csv):
        print(f"{checked_csv} not found.")
        return

    # Read both files
    df_data    = pd.read_csv(data_csv, skipinitialspace=True)
    df_checked = pd.read_csv(checked_csv, skipinitialspace=True)

    # Ensure BaseName column is present
    if "BaseName" not in df_data.columns or "BaseName" not in df_checked.columns:
        print("Column 'BaseName' not found in one of the files. Available columns:")
        print(" data.csv:", df_data.columns.tolist())
        print(" checked_data.csv:", df_checked.columns.tolist())
        return

    # Filter data.csv to only those BaseNames present in checked_data.csv
    df_filtered = df_data[df_data["BaseName"].isin(df_checked["BaseName"])]

    # Overwrite data.csv
    df_filtered.to_csv(data_csv, index=False)
    print(f"Filtered {data_csv}: kept {len(df_filtered)} rows matching checked_data.csv IDs.")


if __name__ == "__main__":
    # To regenerate cfg files and rerun CFD, uncomment:
    #generate_cfg_files()
    #run_cfd_simulations()
    collect_results()
    remove_mach_outlier_rows()       # Remove Avg_Mach_outlet outliers
    remove_massflow_outlier_rows()   # Remove Avg_Massflow_outlet outliers
    filter_pressure_recovery_by_prefix()  # Keep only highest Pressure_Recovery_Coefficient per ID prefix
    #filter_data_by_checked_ids()
    run_analysis()
    visualize_analysis()

