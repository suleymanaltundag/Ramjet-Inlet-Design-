import os
import subprocess
import shutil
import math
import textwrap

def determine_cfg_file(ramp_num):
    if ramp_num == "3":
        def solve_cfd(name_1, name_2, name_3,name_4 ,M1, M2, M3, M4,
                      beta_deg_1, beta_deg_2, beta_deg_3,
                      altitude, gamma,backpressure_constant, directory="geo files", num_procs=6):
            """
            Create a SU2 configuration file with freestream conditions computed from inlet Mach and altitude,
            and then run the CFD simulation via MPI.

            Parameters:
              name_1, name_2, name_3: Identifiers for file naming.
              M1, M2, M3, M4: Mach numbers at successive shock stages.
              beta_deg_1, beta_deg_2, beta_deg_3: Shock angle degrees.
              altitude (float): Altitude in meters.
              gamma (float): Specific heat ratio.
              directory (str): Directory where the mesh file (.su2) is located.
              num_procs (int): Number of processors for MPI.
            """
            # Compute freestream temperature (T) and pressure (p) using a simple tropospheric model.
            altitude = float(altitude)
            gamma_val = float(gamma)
            T = 288.15 - 0.0065 * altitude               # Temperature in Kelvin
            p = 101325 * (T / 288.15) ** 5.2561            # Pressure in Pascals
            R = 287.058                                  # Specific gas constant for air (J/(kg·K))
            # Compute speed of sound.
            a = math.sqrt(gamma_val * R * T)
            # Compute the inlet velocity.
            velocity = M1 * a

            def oblique_shock_pressure_ratio(M, beta_deg, gamma):
                # Calculate the normal component of Mach number
                M_n = M * math.sin(math.radians(beta_deg))
                return 1 + (2 * gamma / (gamma + 1)) * (M_n ** 2 - 1)

            def normal_shock_pressure_ratio(M, gamma):
                return 1 + (2 * gamma / (gamma + 1)) * (M ** 2 - 1)

            # === Back Pressure Calculation ===
            R1 = oblique_shock_pressure_ratio(M1, beta_deg_1, gamma)
            R2 = oblique_shock_pressure_ratio(M2, beta_deg_2, gamma)
            R3 = oblique_shock_pressure_ratio(M3, beta_deg_3, gamma)
            Rn = normal_shock_pressure_ratio(M4, gamma)
            back_pressure = p * R1 * R2 * R3 * Rn

            # --- Automatic CFL Calculator ---
            h = 0.01      # characteristic cell size in meters
            dt = 1e-5     # time step in seconds
            cfl = (abs(velocity) + a) * dt / h

            # --- Reynolds Number Calculator ---
            mu_ref = 1.716e-5
            T_ref = 273.15
            S = 110.4
            mu = mu_ref * (T / T_ref)**(3/2) * ((T_ref + S) / (T + S))
            rho = p / (R * T)
            L = 1.0
            Re = (rho * velocity * L) / mu

            base_name = f"{name_1}_{name_2}_{name_3}_{name_4}"
            mesh_filepath = os.path.join(directory, base_name + ".su2")

            # Create the destination folder for saving files
            destination_folder = os.path.join(os.getcwd(), "cfg files")
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)

            # Define the destination file paths
            mesh_destination = os.path.join(destination_folder, base_name + ".su2")
            config_filename = base_name + ".cfg"
            config_filepath = os.path.join(destination_folder, config_filename)

            if os.path.exists(mesh_filepath):
                shutil.copy(mesh_filepath, destination_folder)
                print(f"Mesh file copied to {destination_folder}: {base_name + '.su2'}")
            else:
                print(f"Mesh file not found: {mesh_filepath}")
                return

            mesh_filename = base_name + ".su2"

            config_content = f"""%-------------------- SU2 CFD Configuration --------------------
MESH_FILENAME= {mesh_filename}

%------------- DIRECT, ADJOINT, AND LINEARIZED PROBLEM DEFINITION ------------%
SOLVER= RANS
FLUID_MODEL= STANDARD_AIR
KIND_TURB_MODEL= SST
MATH_PROBLEM= DIRECT
RESTART_SOL= NO
SYSTEM_MEASUREMENTS= SI

%----------- COMPRESSIBLE FREE-STREAM DEFINITION (10 km, Mach=2.5) ----------%
MACH_NUMBER= {M1}
REYNOLDS_NUMBER= {Re:.0f}     %% Approx. for 10 km altitude & L = 1 m
REYNOLDS_LENGTH= 1

AOA= 0.0
SIDESLIP_ANGLE= 0.0

%% Standard Atmosphere at {altitude:.0f} m
FREESTREAM_PRESSURE= {p:.0f}      %% Pa
FREESTREAM_TEMPERATURE= {T:.1f}   %% K

INIT_OPTION= REYNOLDS
FREESTREAM_OPTION= TEMPERATURE_FS

%% ---------------------- REFERENCE VALUE DEFINITION ---------------------------%%
REF_ORIGIN_MOMENT_X = 0.00
REF_ORIGIN_MOMENT_Y = 0.00
REF_ORIGIN_MOMENT_Z = 0.00
REF_LENGTH= 1
REF_AREA= 0

%% -------------------- BOUNDARY CONDITION DEFINITION --------------------------%%
MARKER_HEATFLUX= ( wall,0 )
MARKER_FAR= ( far_field,{p:.0f})

%% Updated supersonic inlet conditions:
%%   Velocity = {velocity:.1f} m/s
MARKER_SUPERSONIC_INLET= ( inlet, {T:.1f}, {p:.0f}, {velocity:.1f}, 0.0, 0.0 )

%% Example outlet boundary (static back-pressure):
%% Adjust as needed if you require a normal shock inside the inlet.
MARKER_OUTLET= ( outlet, {back_pressure*backpressure_constant:.3f} )

MARKER_SUPERSONIC_OUTLET= ( far_field )

AXISYMMETRIC= YES
MARKER_SYM= (axis)

%% --------------------------- VISCOSITY MODEL ---------------------------------%%
VISCOSITY_MODEL= SUTHERLAND
MU_REF= 1.716E-5
MU_T_REF= 273.15
SUTHERLAND_CONSTANT= 110.4

%% ------------- COMMON PARAMETERS DEFINING THE NUMERICAL METHOD ---------------%%
NUM_METHOD_GRAD= WEIGHTED_LEAST_SQUARES
CFL_NUMBER= {cfl:.4f}
CFL_ADAPT= YES
CFL_ADAPT_PARAM= ( 0.1, 2.0, 5.0, 10 )
RK_ALPHA_COEFF= ( 0.66667, 0.66667, 1.000000 )
ITER= 10000

LINEAR_SOLVER= FGMRES
LINEAR_SOLVER_PREC= ILU
LINEAR_SOLVER_ERROR= 1E-6
LINEAR_SOLVER_ITER= 20

%% -------------------------- MULTIGRID PARAMETERS -----------------------------%%
MGLEVEL= 0
MGCYCLE= W_CYCLE
MG_PRE_SMOOTH= ( 1, 2, 3, 3 )
MG_POST_SMOOTH= ( 0, 0, 0, 0 )
MG_CORRECTION_SMOOTH= ( 0, 0, 0, 0 )
MG_DAMP_RESTRICTION= 0.8
MG_DAMP_PROLONGATION= 0.8

%% -------------------- FLOW NUMERICAL METHOD DEFINITION -----------------------%%
CONV_NUM_METHOD_FLOW= ROE
MUSCL_FLOW= NO
SLOPE_LIMITER_FLOW= VENKATAKRISHNAN
LAX_SENSOR_COEFF= 0.15
JST_SENSOR_COEFF= ( 0.5, 0.02 )
TIME_DISCRE_FLOW= EULER_IMPLICIT

%% --------------------------- CONVERGENCE PARAMETERS --------------------------%%
CONV_FIELD= RMS_DENSITY
CONV_RESIDUAL_MINVAL= -5
CONV_STARTITER= 100
CONV_CAUCHY_ELEMS= 100
CONV_CAUCHY_EPS= 1E-7

%% -------------------- TURBULENT NUMERICAL METHOD DEFINITION ------------------%%
CONV_NUM_METHOD_TURB= SCALAR_UPWIND
TIME_DISCRE_TURB= EULER_IMPLICIT
CFL_REDUCTION_TURB= 1.0

%% ------------------------- INPUT/OUTPUT INFORMATION --------------------------%%
MARKER_PLOTTING= ( outlet)
MARKER_MONITORING= ( outlet )
MARKER_ANALYZE= ( outlet )
SCREEN_OUTPUT=(ITER, WALL_TIME, SURFACE_MASSFLOW)

MESH_FORMAT= SU2
MESH_OUT_FILENAME= mesh_out_{base_name}_.su2
SOLUTION_FILENAME= solution_flow_{base_name}_.dat
SOLUTION_ADJ_FILENAME= solution_adj_{base_name}_.dat

TABULAR_FORMAT= CSV
OUTPUT_FILES= (CSV,SURFACE_CSV, PARAVIEW, SURFACE_PARAVIEW)

HISTORY_OUTPUT= (ITER, RMS_RES, SURFACE_MASSFLOW,SURFACE_TOTAL_PRESSURE,SURFACE_TOTAL_TEMPERATURE,SURFACE_MACH)
CONV_FILENAME= {base_name}_history.csv


RESTART_FILENAME= restart_flow_{base_name}.dat
RESTART_ADJ_FILENAME= restart_adj_{base_name}.dat
VOLUME_FILENAME= {base_name}.vtu
VOLUME_ADJ_FILENAME= adjoint_{base_name}.vtu
GRAD_OBJFUNC_FILENAME= of_grad_{base_name}.dat
SURFACE_FILENAME= surface_flow_{base_name}.csv
SURFACE_ADJ_FILENAME= surface_adjoint_{base_name}.csv

SCREEN_WRT_FREQ_INNER= 100
SCREEN_WRT_FREQ_OUTER= 100
SCREEN_WRT_FREQ_TIME= 100
HISTORY_WRT_FREQ_INNER= 5
HISTORY_WRT_FREQ_OUTER= 5
HISTORY_WRT_FREQ_TIME= 5

%% ----------------------- DESIGN VARIABLE PARAMETERS --------------------------%%
DV_KIND= SCALE_GRID
DV_PARAM= ( 1.0 )
DV_VALUE= 10.0
"""
            config_content = textwrap.dedent(config_content)
            with open(config_filepath, "w") as f:
                f.write(config_content)
            print(f"Configuration file created: {config_filepath}")

            '''command = ["mpirun", "-n", str(num_procs), "SU2_CFD", config_filename]
            print("Executing command:", " ".join(command))
            try:
                subprocess.run(command, check=True)
                print("CFD simulation completed successfully.")
            except subprocess.CalledProcessError as e:
                print("Error running CFD simulation:", e)'''
        return solve_cfd

    if ramp_num == "2":
        def solve_cfd(name_1, name_2, name_3,name_4, M1, M2, M3,
                      beta_deg_1, beta_deg_2,
                      altitude, gamma,backpressure_constant, directory="geo files", num_procs=6):
            """
            Create a SU2 configuration file with freestream conditions computed from inlet Mach and altitude,
            and then run the CFD simulation via MPI.

            Parameters:
              name_1, name_2, name_3: Identifiers for file naming.
              M1, M2, M3: Mach numbers.
              beta_deg_1, beta_deg_2: Shock angle degrees.
              altitude (float): Altitude in meters.
              gamma (float): Specific heat ratio.
              directory (str): Directory where the mesh file (.su2) is located.
              num_procs (int): Number of processors for MPI.
            """
            altitude = float(altitude)
            gamma_val = float(gamma)
            T = 288.15 - 0.0065 * altitude
            p = 101325 * (T / 288.15) ** 5.2561
            R = 287.058
            a = math.sqrt(gamma_val * R * T)
            velocity = M1 * a

            def oblique_shock_pressure_ratio(M, beta_deg, gamma):
                M_n = M * math.sin(math.radians(beta_deg))
                return 1 + (2 * gamma / (gamma + 1)) * (M_n ** 2 - 1)

            def normal_shock_pressure_ratio(M, gamma):
                return 1 + (2 * gamma / (gamma + 1)) * (M ** 2 - 1)

            R1 = oblique_shock_pressure_ratio(M1, beta_deg_1, gamma)
            R2 = oblique_shock_pressure_ratio(M2, beta_deg_2, gamma)
            Rn = normal_shock_pressure_ratio(M3, gamma)
            back_pressure = p * R1 * R2 * Rn

            h = 0.01
            dt = 1e-5
            cfl = (abs(velocity) + a) * dt / h

            mu_ref = 1.716e-5
            T_ref = 273.15
            S = 110.4
            mu = mu_ref * (T / T_ref) ** (3 / 2) * ((T_ref + S) / (T + S))
            rho = p / (R * T)
            L = 1.0
            Re = (rho * velocity * L) / mu

            base_name = f"{name_1}_{name_2}_{name_3}_{name_4}"
            mesh_filepath = os.path.join(directory, base_name + ".su2")

            # Create the destination folder for saving files
            destination_folder = os.path.join(os.getcwd(), "cfg files")
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)

            # Define the destination file paths
            mesh_destination = os.path.join(destination_folder, base_name + ".su2")
            config_filename = base_name + ".cfg"
            config_filepath = os.path.join(destination_folder, config_filename)

            if os.path.exists(mesh_filepath):
                shutil.copy(mesh_filepath, destination_folder)
                print(f"Mesh file copied to {destination_folder}: {base_name + '.su2'}")
            else:
                print(f"Mesh file not found: {mesh_filepath}")
                return
            mesh_filename = base_name + ".su2"

            config_content = f"""%-------------------- SU2 CFD Configuration --------------------
MESH_FILENAME= {mesh_filename}

%------------- DIRECT, ADJOINT, AND LINEARIZED PROBLEM DEFINITION ------------%
SOLVER= RANS
FLUID_MODEL= STANDARD_AIR
KIND_TURB_MODEL= SST
MATH_PROBLEM= DIRECT
RESTART_SOL= NO
SYSTEM_MEASUREMENTS= SI

%----------- COMPRESSIBLE FREE-STREAM DEFINITION (10 km, Mach=2.5) ----------%
MACH_NUMBER= {M1}
REYNOLDS_NUMBER= {Re:.0f}     %% Approx. for 10 km altitude & L = 1 m
REYNOLDS_LENGTH= 1

AOA= 0.0
SIDESLIP_ANGLE= 0.0

%% Standard Atmosphere at {altitude:.0f} m
FREESTREAM_PRESSURE= {p:.0f}      %% Pa
FREESTREAM_TEMPERATURE= {T:.1f}   %% K

INIT_OPTION= REYNOLDS
FREESTREAM_OPTION= TEMPERATURE_FS

%% ---------------------- REFERENCE VALUE DEFINITION ---------------------------%%
REF_ORIGIN_MOMENT_X = 0.00
REF_ORIGIN_MOMENT_Y = 0.00
REF_ORIGIN_MOMENT_Z = 0.00
REF_LENGTH= 1
REF_AREA= 0

%% -------------------- BOUNDARY CONDITION DEFINITION --------------------------%%
MARKER_HEATFLUX= ( wall,0 )
MARKER_FAR= ( far_field,{p:.0f})

%% Updated supersonic inlet conditions:
%%   Velocity = {velocity:.1f} m/s
MARKER_SUPERSONIC_INLET= ( inlet, {T:.1f}, {p:.0f}, {velocity:.1f}, 0.0, 0.0 )

%% Example outlet boundary (static back-pressure):
%% Adjust as needed if you require a normal shock inside the inlet.
MARKER_OUTLET= ( outlet, {back_pressure*backpressure_constant:.3f} )

MARKER_SUPERSONIC_OUTLET= ( far_field )

AXISYMMETRIC= YES
MARKER_SYM= (axis)

%% --------------------------- VISCOSITY MODEL ---------------------------------%%
VISCOSITY_MODEL= SUTHERLAND
MU_REF= 1.716E-5
MU_T_REF= 273.15
SUTHERLAND_CONSTANT= 110.4

%% ------------- COMMON PARAMETERS DEFINING THE NUMERICAL METHOD ---------------%%
NUM_METHOD_GRAD= WEIGHTED_LEAST_SQUARES
CFL_NUMBER= {cfl:.4f}
CFL_ADAPT= YES
CFL_ADAPT_PARAM= ( 0.1, 2.0, 5.0, 10 )
RK_ALPHA_COEFF= ( 0.66667, 0.66667, 1.000000 )
ITER= 10000

LINEAR_SOLVER= FGMRES
LINEAR_SOLVER_PREC= ILU
LINEAR_SOLVER_ERROR= 1E-6
LINEAR_SOLVER_ITER= 20

%% -------------------------- MULTIGRID PARAMETERS -----------------------------%%
MGLEVEL= 0
MGCYCLE= W_CYCLE
MG_PRE_SMOOTH= ( 1, 2, 3, 3 )
MG_POST_SMOOTH= ( 0, 0, 0, 0 )
MG_CORRECTION_SMOOTH= ( 0, 0, 0, 0 )
MG_DAMP_RESTRICTION= 0.8
MG_DAMP_PROLONGATION= 0.8

%% -------------------- FLOW NUMERICAL METHOD DEFINITION -----------------------%%
CONV_NUM_METHOD_FLOW= ROE
MUSCL_FLOW= NO
SLOPE_LIMITER_FLOW= VENKATAKRISHNAN
LAX_SENSOR_COEFF= 0.15
JST_SENSOR_COEFF= ( 0.5, 0.02 )
TIME_DISCRE_FLOW= EULER_IMPLICIT

%% --------------------------- CONVERGENCE PARAMETERS --------------------------%%
CONV_FIELD= RMS_DENSITY
CONV_RESIDUAL_MINVAL= -5
CONV_STARTITER= 100
CONV_CAUCHY_ELEMS= 100
CONV_CAUCHY_EPS= 1E-7

%% -------------------- TURBULENT NUMERICAL METHOD DEFINITION ------------------%%
CONV_NUM_METHOD_TURB= SCALAR_UPWIND
TIME_DISCRE_TURB= EULER_IMPLICIT
CFL_REDUCTION_TURB= 1.0

%% ------------------------- INPUT/OUTPUT INFORMATION --------------------------%%
MARKER_PLOTTING= ( outlet)
MARKER_MONITORING= ( outlet )
MARKER_ANALYZE= ( outlet )
SCREEN_OUTPUT=(ITER, WALL_TIME, SURFACE_MASSFLOW)

MESH_FORMAT= SU2
MESH_OUT_FILENAME= mesh_out_{base_name}_.su2
SOLUTION_FILENAME= solution_flow_{base_name}_.dat
SOLUTION_ADJ_FILENAME= solution_adj_{base_name}_.dat

TABULAR_FORMAT= CSV
OUTPUT_FILES= (CSV,SURFACE_CSV, PARAVIEW, SURFACE_PARAVIEW)

HISTORY_OUTPUT= (ITER, RMS_RES, SURFACE_MASSFLOW,SURFACE_TOTAL_PRESSURE,SURFACE_TOTAL_TEMPERATURE,SURFACE_MACH)
CONV_FILENAME= {base_name}_history.csv


RESTART_FILENAME= restart_flow_{base_name}.dat
RESTART_ADJ_FILENAME= restart_adj_{base_name}.dat
VOLUME_FILENAME= {base_name}.vtu
VOLUME_ADJ_FILENAME= adjoint_{base_name}.vtu
GRAD_OBJFUNC_FILENAME= of_grad_{base_name}.dat
SURFACE_FILENAME= surface_flow_{base_name}.csv
SURFACE_ADJ_FILENAME= surface_adjoint_{base_name}.csv

SCREEN_WRT_FREQ_INNER= 100
SCREEN_WRT_FREQ_OUTER= 100
SCREEN_WRT_FREQ_TIME= 100
HISTORY_WRT_FREQ_INNER= 5
HISTORY_WRT_FREQ_OUTER= 5
HISTORY_WRT_FREQ_TIME= 5

%% ----------------------- DESIGN VARIABLE PARAMETERS --------------------------%%
DV_KIND= SCALE_GRID
DV_PARAM= ( 1.0 )
DV_VALUE= 10.0
"""
            config_content = textwrap.dedent(config_content)
            with open(config_filepath, "w") as f:
                f.write(config_content)
            print(f"Configuration file created: {config_filename}")

            '''command = ["mpirun", "-n", str(num_procs), "SU2_CFD", config_filename]
            print("Executing command:", " ".join(command))
            try:
                subprocess.run(command, check=True)
                print("CFD simulation completed successfully.")
            except subprocess.CalledProcessError as e:
                print("Error running CFD simulation:", e)'''
        return solve_cfd
    if ramp_num == "4":
        def solve_cfd(name_1, name_2, name_3,name_4, M1, M2, M3, M4,M5,
                      beta_deg_1, beta_deg_2, beta_deg_3,beta_deg_4,
                      altitude, gamma,backpressure_constant, directory="geo files", num_procs=6):
            """
            Create a SU2 configuration file with freestream conditions computed from inlet Mach and altitude,
            and then run the CFD simulation via MPI.

            Parameters:
              name_1, name_2, name_3: Identifiers for file naming.
              M1, M2, M3, M4: Mach numbers at successive shock stages.
              beta_deg_1, beta_deg_2, beta_deg_3: Shock angle degrees.
              altitude (float): Altitude in meters.
              gamma (float): Specific heat ratio.
              directory (str): Directory where the mesh file (.su2) is located.
              num_procs (int): Number of processors for MPI.
            """
            # Compute freestream temperature (T) and pressure (p) using a simple tropospheric model.
            altitude = float(altitude)
            gamma_val = float(gamma)
            T = 288.15 - 0.0065 * altitude               # Temperature in Kelvin
            p = 101325 * (T / 288.15) ** 5.2561            # Pressure in Pascals
            R = 287.058                                  # Specific gas constant for air (J/(kg·K))
            # Compute speed of sound.
            a = math.sqrt(gamma_val * R * T)
            # Compute the inlet velocity.
            velocity = M1 * a

            def oblique_shock_pressure_ratio(M, beta_deg, gamma):
                # Calculate the normal component of Mach number
                M_n = M * math.sin(math.radians(beta_deg))
                return 1 + (2 * gamma / (gamma + 1)) * (M_n ** 2 - 1)

            def normal_shock_pressure_ratio(M, gamma):
                return 1 + (2 * gamma / (gamma + 1)) * (M ** 2 - 1)

            # === Back Pressure Calculation ===
            R1 = oblique_shock_pressure_ratio(M1, beta_deg_1, gamma)
            R2 = oblique_shock_pressure_ratio(M2, beta_deg_2, gamma)
            R3 = oblique_shock_pressure_ratio(M3, beta_deg_3, gamma)
            R4 = oblique_shock_pressure_ratio(M4, beta_deg_4, gamma)
            Rn = normal_shock_pressure_ratio(M5, gamma)
            back_pressure = p * R1 * R2 * R3 *R4* Rn

            # --- Automatic CFL Calculator ---
            h = 0.01      # characteristic cell size in meters
            dt = 1e-5     # time step in seconds
            cfl = (abs(velocity) + a) * dt / h

            # --- Reynolds Number Calculator ---
            mu_ref = 1.716e-5
            T_ref = 273.15
            S = 110.4
            mu = mu_ref * (T / T_ref)**(3/2) * ((T_ref + S) / (T + S))
            rho = p / (R * T)
            L = 1.0
            Re = (rho * velocity * L) / mu

            base_name = f"{name_1}_{name_2}_{name_3}_{name_4}"
            mesh_filepath = os.path.join(directory, base_name + ".su2")

            # Create the destination folder for saving files
            destination_folder = os.path.join(os.getcwd(), "cfg files")
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)

            # Define the destination file paths
            mesh_destination = os.path.join(destination_folder, base_name + ".su2")
            config_filename = base_name + ".cfg"
            config_filepath = os.path.join(destination_folder, config_filename)

            if os.path.exists(mesh_filepath):
                shutil.copy(mesh_filepath, destination_folder)
                print(f"Mesh file copied to {destination_folder}: {base_name + '.su2'}")
            else:
                print(f"Mesh file not found: {mesh_filepath}")
                return
            mesh_filename = base_name + ".su2"

            config_content = f"""%-------------------- SU2 CFD Configuration --------------------
MESH_FILENAME= {mesh_filename}

%------------- DIRECT, ADJOINT, AND LINEARIZED PROBLEM DEFINITION ------------%
SOLVER= RANS
FLUID_MODEL= STANDARD_AIR
KIND_TURB_MODEL= SST
MATH_PROBLEM= DIRECT
RESTART_SOL= NO
SYSTEM_MEASUREMENTS= SI

%----------- COMPRESSIBLE FREE-STREAM DEFINITION (10 km, Mach=2.5) ----------%
MACH_NUMBER= {M1}
REYNOLDS_NUMBER= {Re:.0f}     %% Approx. for 10 km altitude & L = 1 m
REYNOLDS_LENGTH= 1

AOA= 0.0
SIDESLIP_ANGLE= 0.0

%% Standard Atmosphere at {altitude:.0f} m
FREESTREAM_PRESSURE= {p:.0f}      %% Pa
FREESTREAM_TEMPERATURE= {T:.1f}   %% K

INIT_OPTION= REYNOLDS
FREESTREAM_OPTION= TEMPERATURE_FS

%% ---------------------- REFERENCE VALUE DEFINITION ---------------------------%%
REF_ORIGIN_MOMENT_X = 0.00
REF_ORIGIN_MOMENT_Y = 0.00
REF_ORIGIN_MOMENT_Z = 0.00
REF_LENGTH= 1
REF_AREA= 0

%% -------------------- BOUNDARY CONDITION DEFINITION --------------------------%%
MARKER_HEATFLUX= ( wall,0 )
MARKER_FAR= ( far_field,{p:.0f})

%% Updated supersonic inlet conditions:
%%   Velocity = {velocity:.1f} m/s
MARKER_SUPERSONIC_INLET= ( inlet, {T:.1f}, {p:.0f}, {velocity:.1f}, 0.0, 0.0 )

%% Example outlet boundary (static back-pressure):
%% Adjust as needed if you require a normal shock inside the inlet.
MARKER_OUTLET= ( outlet, {back_pressure*backpressure_constant:.3f} )

MARKER_SUPERSONIC_OUTLET= ( far_field )

AXISYMMETRIC= YES
MARKER_SYM= (axis)

%% --------------------------- VISCOSITY MODEL ---------------------------------%%
VISCOSITY_MODEL= SUTHERLAND
MU_REF= 1.716E-5
MU_T_REF= 273.15
SUTHERLAND_CONSTANT= 110.4

%% ------------- COMMON PARAMETERS DEFINING THE NUMERICAL METHOD ---------------%%
NUM_METHOD_GRAD= WEIGHTED_LEAST_SQUARES
CFL_NUMBER= {cfl:.4f}
CFL_ADAPT= YES
CFL_ADAPT_PARAM= ( 0.1, 2.0, 5.0, 10 )
RK_ALPHA_COEFF= ( 0.66667, 0.66667, 1.000000 )
ITER= 10000

LINEAR_SOLVER= FGMRES
LINEAR_SOLVER_PREC= ILU
LINEAR_SOLVER_ERROR= 1E-6
LINEAR_SOLVER_ITER= 20

%% -------------------------- MULTIGRID PARAMETERS -----------------------------%%
MGLEVEL= 0
MGCYCLE= W_CYCLE
MG_PRE_SMOOTH= ( 1, 2, 3, 3 )
MG_POST_SMOOTH= ( 0, 0, 0, 0 )
MG_CORRECTION_SMOOTH= ( 0, 0, 0, 0 )
MG_DAMP_RESTRICTION= 0.8
MG_DAMP_PROLONGATION= 0.8

%% -------------------- FLOW NUMERICAL METHOD DEFINITION -----------------------%%
CONV_NUM_METHOD_FLOW= ROE
MUSCL_FLOW= NO
SLOPE_LIMITER_FLOW= VENKATAKRISHNAN
LAX_SENSOR_COEFF= 0.15
JST_SENSOR_COEFF= ( 0.5, 0.02 )
TIME_DISCRE_FLOW= EULER_IMPLICIT

%% --------------------------- CONVERGENCE PARAMETERS --------------------------%%
CONV_FIELD= RMS_DENSITY
CONV_RESIDUAL_MINVAL= -5
CONV_STARTITER= 100
CONV_CAUCHY_ELEMS= 100
CONV_CAUCHY_EPS= 1E-7

%% -------------------- TURBULENT NUMERICAL METHOD DEFINITION ------------------%%
CONV_NUM_METHOD_TURB= SCALAR_UPWIND
TIME_DISCRE_TURB= EULER_IMPLICIT
CFL_REDUCTION_TURB= 1.0

%% ------------------------- INPUT/OUTPUT INFORMATION --------------------------%%
MARKER_PLOTTING= ( outlet)
MARKER_MONITORING= ( outlet )
MARKER_ANALYZE= ( outlet )
SCREEN_OUTPUT=(ITER, WALL_TIME, SURFACE_MASSFLOW)

MESH_FORMAT= SU2
MESH_OUT_FILENAME= mesh_out_{base_name}_.su2
SOLUTION_FILENAME= solution_flow_{base_name}_.dat
SOLUTION_ADJ_FILENAME= solution_adj_{base_name}_.dat

TABULAR_FORMAT= CSV
OUTPUT_FILES= (CSV,SURFACE_CSV, PARAVIEW, SURFACE_PARAVIEW)

HISTORY_OUTPUT= (ITER, RMS_RES, SURFACE_MASSFLOW,SURFACE_TOTAL_PRESSURE,SURFACE_TOTAL_TEMPERATURE,SURFACE_MACH)
CONV_FILENAME= {base_name}_history.csv


RESTART_FILENAME= restart_flow_{base_name}.dat
RESTART_ADJ_FILENAME= restart_adj_{base_name}.dat
VOLUME_FILENAME= {base_name}.vtu
VOLUME_ADJ_FILENAME= adjoint_{base_name}.vtu
GRAD_OBJFUNC_FILENAME= of_grad_{base_name}.dat
SURFACE_FILENAME= surface_flow_{base_name}.csv
SURFACE_ADJ_FILENAME= surface_adjoint_{base_name}.csv

SCREEN_WRT_FREQ_INNER= 100
SCREEN_WRT_FREQ_OUTER= 100
SCREEN_WRT_FREQ_TIME= 100
HISTORY_WRT_FREQ_INNER= 5
HISTORY_WRT_FREQ_OUTER= 5
HISTORY_WRT_FREQ_TIME= 5

%% ----------------------- DESIGN VARIABLE PARAMETERS --------------------------%%
DV_KIND= SCALE_GRID
DV_PARAM= ( 1.0 )
DV_VALUE= 10.0
"""
            config_content = textwrap.dedent(config_content)
            with open(config_filepath, "w") as f:
                f.write(config_content)
            print(f"Configuration file created: {config_filename}")

            '''command = ["mpirun", "-n", str(num_procs), "SU2_CFD", config_filename]
            print("Executing command:", " ".join(command))
            try:
                subprocess.run(command, check=True)
                print("CFD simulation completed successfully.")
            except subprocess.CalledProcessError as e:
                print("Error running CFD simulation:", e)'''
        return solve_cfd



    if ramp_num == "5":
        def solve_cfd(name_1, name_2, name_3,name_4, M1, M2, M3, M4,M5,M6,
                      beta_deg_1, beta_deg_2, beta_deg_3,beta_deg_4,beta_deg_5,
                      altitude, gamma,backpressure_constant, directory="geo files", num_procs=6):
            """
            Create a SU2 configuration file with freestream conditions computed from inlet Mach and altitude,
            and then run the CFD simulation via MPI.

            Parameters:
              name_1, name_2, name_3: Identifiers for file naming.
              M1, M2, M3, M4: Mach numbers at successive shock stages.
              beta_deg_1, beta_deg_2, beta_deg_3: Shock angle degrees.
              altitude (float): Altitude in meters.
              gamma (float): Specific heat ratio.
              directory (str): Directory where the mesh file (.su2) is located.
              num_procs (int): Number of processors for MPI.
            """
            # Compute freestream temperature (T) and pressure (p) using a simple tropospheric model.
            altitude = float(altitude)
            gamma_val = float(gamma)
            T = 288.15 - 0.0065 * altitude               # Temperature in Kelvin
            p = 101325 * (T / 288.15) ** 5.2561            # Pressure in Pascals
            R = 287.058                                  # Specific gas constant for air (J/(kg·K))
            # Compute speed of sound.
            a = math.sqrt(gamma_val * R * T)
            # Compute the inlet velocity.
            velocity = M1 * a

            def oblique_shock_pressure_ratio(M, beta_deg, gamma):
                # Calculate the normal component of Mach number
                M_n = M * math.sin(math.radians(beta_deg))
                return 1 + (2 * gamma / (gamma + 1)) * (M_n ** 2 - 1)

            def normal_shock_pressure_ratio(M, gamma):
                return 1 + (2 * gamma / (gamma + 1)) * (M ** 2 - 1)

            # === Back Pressure Calculation ===
            R1 = oblique_shock_pressure_ratio(M1, beta_deg_1, gamma)
            R2 = oblique_shock_pressure_ratio(M2, beta_deg_2, gamma)
            R3 = oblique_shock_pressure_ratio(M3, beta_deg_3, gamma)
            R4 = oblique_shock_pressure_ratio(M4, beta_deg_4, gamma)
            R5 = oblique_shock_pressure_ratio(M5, beta_deg_5, gamma)
            Rn = normal_shock_pressure_ratio(M6, gamma)
            back_pressure = p * R1 * R2 * R3 *R4*R5* Rn

            # --- Automatic CFL Calculator ---
            h = 0.01      # characteristic cell size in meters
            dt = 1e-5     # time step in seconds
            cfl = (abs(velocity) + a) * dt / h

            # --- Reynolds Number Calculator ---
            mu_ref = 1.716e-5
            T_ref = 273.15
            S = 110.4
            mu = mu_ref * (T / T_ref)**(3/2) * ((T_ref + S) / (T + S))
            rho = p / (R * T)
            L = 1.0
            Re = (rho * velocity * L) / mu

            base_name = f"{name_1}_{name_2}_{name_3}_{name_4}"
            mesh_filepath = os.path.join(directory, base_name + ".su2")

            # Create the destination folder for saving files
            destination_folder = os.path.join(os.getcwd(), "cfg files")
            if not os.path.exists(destination_folder):
                os.makedirs(destination_folder)

            # Define the destination file paths
            mesh_destination = os.path.join(destination_folder, base_name + ".su2")
            config_filename = base_name + ".cfg"
            config_filepath = os.path.join(destination_folder, config_filename)

            if os.path.exists(mesh_filepath):
                shutil.copy(mesh_filepath, destination_folder)
                print(f"Mesh file copied to {destination_folder}: {base_name + '.su2'}")
            else:
                print(f"Mesh file not found: {mesh_filepath}")
                return

            mesh_filename = base_name + ".su2"

            config_content = f"""%-------------------- SU2 CFD Configuration --------------------
MESH_FILENAME= {mesh_filename}

%------------- DIRECT, ADJOINT, AND LINEARIZED PROBLEM DEFINITION ------------%
SOLVER= RANS
FLUID_MODEL= STANDARD_AIR
KIND_TURB_MODEL= SST
MATH_PROBLEM= DIRECT
RESTART_SOL= NO
SYSTEM_MEASUREMENTS= SI

%----------- COMPRESSIBLE FREE-STREAM DEFINITION (10 km, Mach=2.5) ----------%
MACH_NUMBER= {M1}
REYNOLDS_NUMBER= {Re:.0f}     %% Approx. for 10 km altitude & L = 1 m
REYNOLDS_LENGTH= 1

AOA= 0.0
SIDESLIP_ANGLE= 0.0

%% Standard Atmosphere at {altitude:.0f} m
FREESTREAM_PRESSURE= {p:.0f}      %% Pa
FREESTREAM_TEMPERATURE= {T:.1f}   %% K

INIT_OPTION= REYNOLDS
FREESTREAM_OPTION= TEMPERATURE_FS

%% ---------------------- REFERENCE VALUE DEFINITION ---------------------------%%
REF_ORIGIN_MOMENT_X = 0.00
REF_ORIGIN_MOMENT_Y = 0.00
REF_ORIGIN_MOMENT_Z = 0.00
REF_LENGTH= 1
REF_AREA= 0

%% -------------------- BOUNDARY CONDITION DEFINITION --------------------------%%
MARKER_HEATFLUX= ( wall,0 )
MARKER_FAR= ( far_field,{p:.0f})

%% Updated supersonic inlet conditions:
%%   Velocity = {velocity:.1f} m/s
MARKER_SUPERSONIC_INLET= ( inlet, {T:.1f}, {p:.0f}, {velocity:.1f}, 0.0, 0.0 )

%% Example outlet boundary (static back-pressure):
%% Adjust as needed if you require a normal shock inside the inlet.
MARKER_OUTLET= ( outlet, {back_pressure*backpressure_constant:.3f} )

MARKER_SUPERSONIC_OUTLET= ( far_field )

AXISYMMETRIC= YES
MARKER_SYM= (axis)

%% --------------------------- VISCOSITY MODEL ---------------------------------%%
VISCOSITY_MODEL= SUTHERLAND
MU_REF= 1.716E-5
MU_T_REF= 273.15
SUTHERLAND_CONSTANT= 110.4

%% ------------- COMMON PARAMETERS DEFINING THE NUMERICAL METHOD ---------------%%
NUM_METHOD_GRAD= WEIGHTED_LEAST_SQUARES
CFL_NUMBER= {cfl:.4f}
CFL_ADAPT= YES
CFL_ADAPT_PARAM= ( 0.1, 2.0, 5.0, 10 )
RK_ALPHA_COEFF= ( 0.66667, 0.66667, 1.000000 )
ITER= 10000

LINEAR_SOLVER= FGMRES
LINEAR_SOLVER_PREC= ILU
LINEAR_SOLVER_ERROR= 1E-6
LINEAR_SOLVER_ITER= 20

%% -------------------------- MULTIGRID PARAMETERS -----------------------------%%
MGLEVEL= 0
MGCYCLE= W_CYCLE
MG_PRE_SMOOTH= ( 1, 2, 3, 3 )
MG_POST_SMOOTH= ( 0, 0, 0, 0 )
MG_CORRECTION_SMOOTH= ( 0, 0, 0, 0 )
MG_DAMP_RESTRICTION= 0.8
MG_DAMP_PROLONGATION= 0.8

%% -------------------- FLOW NUMERICAL METHOD DEFINITION -----------------------%%
CONV_NUM_METHOD_FLOW= ROE
MUSCL_FLOW= NO
SLOPE_LIMITER_FLOW= VENKATAKRISHNAN
LAX_SENSOR_COEFF= 0.15
JST_SENSOR_COEFF= ( 0.5, 0.02 )
TIME_DISCRE_FLOW= EULER_IMPLICIT

%% --------------------------- CONVERGENCE PARAMETERS --------------------------%%
CONV_FIELD= RMS_DENSITY
CONV_RESIDUAL_MINVAL= -5
CONV_STARTITER= 100
CONV_CAUCHY_ELEMS= 100
CONV_CAUCHY_EPS= 1E-7

%% -------------------- TURBULENT NUMERICAL METHOD DEFINITION ------------------%%
CONV_NUM_METHOD_TURB= SCALAR_UPWIND
TIME_DISCRE_TURB= EULER_IMPLICIT
CFL_REDUCTION_TURB= 1.0

%% ------------------------- INPUT/OUTPUT INFORMATION --------------------------%%
MARKER_PLOTTING= ( outlet)
MARKER_MONITORING= ( outlet )
MARKER_ANALYZE= ( outlet )
SCREEN_OUTPUT=(ITER, WALL_TIME, SURFACE_MASSFLOW)

MESH_FORMAT= SU2
MESH_OUT_FILENAME= mesh_out_{base_name}_.su2
SOLUTION_FILENAME= solution_flow_{base_name}_.dat
SOLUTION_ADJ_FILENAME= solution_adj_{base_name}_.dat

TABULAR_FORMAT= CSV
OUTPUT_FILES= (CSV,SURFACE_CSV, PARAVIEW, SURFACE_PARAVIEW)

HISTORY_OUTPUT= (ITER, RMS_RES, SURFACE_MASSFLOW,SURFACE_TOTAL_PRESSURE,SURFACE_TOTAL_TEMPERATURE,SURFACE_MACH)
CONV_FILENAME= {base_name}_history.csv


RESTART_FILENAME= restart_flow_{base_name}.dat
RESTART_ADJ_FILENAME= restart_adj_{base_name}.dat
VOLUME_FILENAME= {base_name}.vtu
VOLUME_ADJ_FILENAME= adjoint_{base_name}.vtu
GRAD_OBJFUNC_FILENAME= of_grad_{base_name}.dat
SURFACE_FILENAME= surface_flow_{base_name}.csv
SURFACE_ADJ_FILENAME= surface_adjoint_{base_name}.csv

SCREEN_WRT_FREQ_INNER= 100
SCREEN_WRT_FREQ_OUTER= 100
SCREEN_WRT_FREQ_TIME= 100
HISTORY_WRT_FREQ_INNER= 5
HISTORY_WRT_FREQ_OUTER= 5
HISTORY_WRT_FREQ_TIME= 5

%% ----------------------- DESIGN VARIABLE PARAMETERS --------------------------%%
DV_KIND= SCALE_GRID
DV_PARAM= ( 1.0 )
DV_VALUE= 10.0
"""
            config_content = textwrap.dedent(config_content)
            with open(config_filepath, "w") as f:
                f.write(config_content)
            print(f"Configuration file created: {config_filename}")

            '''command = ["mpirun", "-n", str(num_procs), "SU2_CFD", config_filename]
            print("Executing command:", " ".join(command))
            try:
                subprocess.run(command, check=True)
                print("CFD simulation completed successfully.")
            except subprocess.CalledProcessError as e:
                print("Error running CFD simulation:", e)'''
        return solve_cfd

