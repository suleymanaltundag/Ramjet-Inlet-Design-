import os
import subprocess
from datetime import datetime
import textwrap  # Added import for dedenting strings


def convert_geo_to_su2(geo_filepath, dimension=2):
    """
    Mesh a .geo file with Gmsh and create a .su2 file.
    This function replicates the default behavior of the Gmsh 2D Mesh button.
    If you later get partitioning errors in SU2, consider adding
      MESH_PARTITIONING=NO
    to your SU2 configuration file or running SU2 in serial.
    """
    gmsh_flag = "-2" if dimension == 2 else "-3"
    su2_filepath = geo_filepath.rsplit(".", 1)[0] + ".su2"

    # Replicate the default 2D meshing behavior of Gmsh:
    command = [
        "gmsh", gmsh_flag, geo_filepath, "-o", su2_filepath, "-format", "su2"
    ]
    print("Executing command:", " ".join(command))

    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if result.stdout:
        print("Gmsh Output:\n", result.stdout)
    if result.stderr:
        print("Gmsh Errors:\n", result.stderr)

    if result.returncode != 0:
        if os.path.exists(su2_filepath) and os.path.getsize(su2_filepath) > 0:
            print(f"SU2 file created with warnings: {su2_filepath}")
        else:
            raise RuntimeError(f"Meshing failed! Gmsh exited with code {result.returncode}.")
    else:
        print(f"SU2 file successfully created: {su2_filepath}")


def is_ml(ml, ramp_num):
    if ml == "No":

        def determine_geo_file(ramp_num):
            if ramp_num == "3":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4, point5,
                                    ramp1, ramp2, ramp3,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4
                    point5_x, point5_y = point5

                    mesh_ratio = 1000
                    size_ratio = (point5_x - point1_x) / 0.6

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        point5_x = {point5_x + 0.2:.4f};
                        point5_y = {point5_y:.4f};

                        size_ratio={(point5_x - point1_x) / 0.6:.4f};


                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};
                        //+
                        Point(3) = {{point2_x, point2_y, 0, 1.0}};
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};
                        //+
                        Point(5) = {{point4_x, point4_y, 0, 1.0}};
                        //+
                        Point(6) = {{point4_x+0.085*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(7) = {{point4_x+0.20533*size_ratio, point4_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(8) = {{point4_x+0.275*size_ratio, point4_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(9) = {{point5_x+0.6*size_ratio, point5_y-(((point5_y-point4_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(10) = {{point5_x+0.6*size_ratio, point5_y-(((point5_y-point4_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(11) = {{point5_x+0.2*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(12) = {{point5_x+0.1*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(13) = {{point5_x+0.05*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(14) = {{point5_x, point5_y, 0, 1.0}};

                        Point(15) = {{point5_x+0.005*size_ratio, point5_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(16) = {{point5_x+0.02*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(17) = {{point5_x+0.05*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point5_x+0.1*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point5_x+0.2*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{point5_x+0.2*size_ratio, point5_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(21) = {{0, point5_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) = {{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 21}};
                        //+
                        Line(21) = {{21, 1}};
                        //+
                        Physical Curve("inlet") = {{21}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18}};
                        //+
                        Physical Curve("outlet") = {{9}};
                        //+
                        Physical Curve("far_field") = {{19, 20}};
                        //+
                        Transfinite Curve {{21}} = {(point5_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {ramp3 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{12}} = {((point5_x + 0.1 * size_ratio) - (point5_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{13}} = {((point5_x + 0.05 * size_ratio) - (point5_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{10}} = {((point5_x + 0.6 * size_ratio) - (point5_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{8}} = {((point5_x + 0.6 * size_ratio) - (point5_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{16}} = {((point5_x + 0.05 * size_ratio) - (point5_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point5_x + 0.1 * size_ratio) - (point5_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{18}} = {((point5_x + 0.2 * size_ratio) - (point5_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{14}} = {((point5_x + 0.005 * size_ratio) - (point5_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{15}} = {((point5_x + 0.02 * size_ratio) - (point5_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{9}} = {((point5_y - 0.05 * size_ratio) - (point4_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{19}} = {((point5_y + 0.05 * size_ratio) - (point5_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {((point4_x + 0.075 * size_ratio) - (point4_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {((point4_x + 0.20533 * size_ratio) - (point4_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{20}} = {((point5_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point4_x + 0.275 * size_ratio) - (point4_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{11}} = {((point5_x + 0.2 * size_ratio) - (point5_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{20, 21, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization

                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;

                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features          
                        Field[3].DistMin = {(point5_y - point4_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point5_y - point4_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field
                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file

            if ramp_num == "2":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4,
                                    ramp1, ramp2,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4

                    mesh_ratio = 1000
                    size_ratio = (point4_x - point1_x) / 0.4

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        size_ratio={(point4_x - point1_x) / 0.4:.4f};

                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};
                        //+
                        Point(3) = {{point2_x, point2_y, 0, 1.0}};
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};
                        //+
                        Point(5) = {{point3_x+0.085*size_ratio, point3_y, 0, 1.0}};
                        //+
                        Point(6) = {{point3_x+0.20533*size_ratio, point3_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(7) = {{point3_x+0.275*size_ratio, point3_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(8) = {{point4_x+0.6*size_ratio, point4_y-(((point4_y-point3_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(9) = {{point4_x+0.6*size_ratio, point4_y-(((point4_y-point3_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(10) = {{point4_x+0.2*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(11) = {{point4_x+0.1*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(12) = {{point4_x+0.05*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(13) = {{point4_x, point4_y, 0, 1.0}};

                        Point(14) = {{point4_x+0.005*size_ratio, point4_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(15) = {{point4_x+0.02*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(16) = {{point4_x+0.05*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(17) = {{point4_x+0.1*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point4_x+0.2*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point4_x+0.2*size_ratio, point4_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{0, point4_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) ={{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 1}};
                        //+
                        Physical Curve("inlet") = {{20}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2,3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 17}};
                        //+
                        Physical Curve("outlet") = {{8}};
                        //+
                        Physical Curve("far_field") = {{18, 19}};
                        //+
                        Transfinite Curve {{20}} = {(point4_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{11}} = {((point4_x + 0.1 * size_ratio) - (point4_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{12}} = {((point4_x + 0.05 * size_ratio) - (point4_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{9}} = {((point4_x + 0.6 * size_ratio) - (point4_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point4_x + 0.6 * size_ratio) - (point4_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{15}} = {((point4_x + 0.05 * size_ratio) - (point4_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{16}} = {((point4_x + 0.1 * size_ratio) - (point4_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point4_x + 0.2 * size_ratio) - (point4_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{13}} = {((point4_x + 0.005 * size_ratio) - (point4_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{14}} = {((point4_x + 0.02 * size_ratio) - (point4_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{8}} = {((point4_y - 0.05 * size_ratio) - (point3_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{18}} = {((point4_y + 0.05 * size_ratio) - (point4_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {((point3_x + 0.075 * size_ratio) - (point3_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {((point3_x + 0.20533 * size_ratio) - (point3_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{19}} = {((point4_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {((point3_x + 0.275 * size_ratio) - (point3_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{10}} = {((point4_x + 0.2 * size_ratio) - (point4_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization

                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;
                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features
                        Field[3].DistMin = {(point4_y - point3_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point4_y - point3_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field
                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file

            if ramp_num == "4":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4, point5, point6,
                                    ramp1, ramp2, ramp3, ramp4,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4
                    point5_x, point5_y = point5
                    point6_x, point6_y = point6

                    mesh_ratio = 1000
                    size_ratio = (point6_x - point1_x) / 0.8

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        point5_x = {point5_x + 0.2:.4f};
                        point5_y = {point5_y:.4f};

                        point6_x = {point6_x + 0.2:.4f};
                        point6_y = {point6_y:.4f};                

                        size_ratio={(point6_x - point1_x) / 0.8:.4f};


                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};

                        Point(3) = {{point2_x, point2_y, 0, 1.0}};                
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};

                        Point(5) = {{point4_x, point4_y, 0, 1.0}};
                        //+
                        Point(6) = {{point5_x, point5_y, 0, 1.0}};

                        //+
                        Point(7) = {{point5_x+0.085*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(8) = {{point5_x+0.20533*size_ratio, point5_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(9) = {{point5_x+0.275*size_ratio, point5_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(10) = {{point6_x+0.6*size_ratio, point6_y-(((point6_y-point5_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(11) = {{point6_x+0.6*size_ratio, point6_y-(((point6_y-point5_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(12) = {{point6_x+0.2*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(13) = {{point6_x+0.1*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(14) = {{point6_x+0.05*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(15) = {{point6_x, point6_y, 0, 1.0}};

                        Point(16) = {{point6_x+0.005*size_ratio, point6_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(17) = {{point6_x+0.02*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point6_x+0.05*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point6_x+0.1*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{point6_x+0.2*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(21) = {{point6_x+0.2*size_ratio, point6_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(22) = {{0, point6_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) = {{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 21}};
                        //+
                        Line(21) = {{21, 22}};

                        Line(22) = {{22, 1}};               

                        //+
                        Physical Curve("inlet") = {{22}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18,19}};
                        //+
                        Physical Curve("outlet") = {{10}};
                        //+
                        Physical Curve("far_field") = {{20, 21}};
                        //+
                        Transfinite Curve {{22}} = {(point6_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {ramp3 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {ramp4 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{13}} = {((point6_x + 0.1 * size_ratio) - (point6_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{14}} = {((point6_x + 0.05 * size_ratio) - (point6_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{11}} = {((point6_x + 0.6 * size_ratio) - (point6_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{9}} = {((point6_x + 0.6 * size_ratio) - (point6_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point6_x + 0.05 * size_ratio) - (point6_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{18}} = {((point6_x + 0.1 * size_ratio) - (point6_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{19}} = {((point6_x + 0.2 * size_ratio) - (point6_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{15}} = {((point6_x + 0.005 * size_ratio) - (point6_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{16}} = {((point6_x + 0.02 * size_ratio) - (point6_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{10}} = {((point6_y - 0.05 * size_ratio) - (point5_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{20}} = {((point6_y + 0.05 * size_ratio) - (point6_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {((point5_x + 0.075 * size_ratio) - (point5_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point5_x + 0.20533 * size_ratio) - (point5_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{21}} = {((point6_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{8}} = {((point5_x + 0.275 * size_ratio) - (point5_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{12}} = {((point6_x + 0.2 * size_ratio) - (point6_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20, 21,22}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization

                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18,19}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;

                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18,19}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features
                        Field[3].DistMin = {(point6_y - point5_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point6_y - point5_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field


                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file

            if ramp_num == "5":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4, point5, point6, point7,
                                    ramp1, ramp2, ramp3, ramp4, ramp5,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4
                    point5_x, point5_y = point5
                    point6_x, point6_y = point6
                    point7_x, point7_y = point7

                    mesh_ratio = 1000
                    size_ratio = (point7_x - point1_x) / 1

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        point5_x = {point5_x + 0.2:.4f};
                        point5_y = {point5_y:.4f};

                        point6_x = {point6_x + 0.2:.4f};
                        point6_y = {point6_y:.4f};       

                        point7_x = {point7_x + 0.2:.4f};
                        point7_y = {point7_y:.4f};            

                        size_ratio={(point7_x - point1_x) / 1:.4f};


                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};

                        Point(3) = {{point2_x, point2_y, 0, 1.0}};                
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};

                        Point(5) = {{point4_x, point4_y, 0, 1.0}};
                        //+
                        Point(6) = {{point5_x, point5_y, 0, 1.0}};

                        Point(7) = {{point6_x, point6_y, 0, 1.0}};

                        //+
                        Point(8) = {{point6_x+0.085*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(9) = {{point6_x+0.20533*size_ratio, point6_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(10) = {{point6_x+0.275*size_ratio, point6_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(11) = {{point7_x+0.6*size_ratio, point7_y-(((point7_y-point6_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(12) = {{point7_x+0.6*size_ratio, point7_y-(((point7_y-point6_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(13) = {{point7_x+0.2*size_ratio, point7_y, 0, 1.0}};
                        //+
                        Point(14) = {{point7_x+0.1*size_ratio, point7_y, 0, 1.0}};
                        //+
                        Point(15) = {{point7_x+0.05*size_ratio, point7_y, 0, 1.0}};
                        //+
                        Point(16) = {{point7_x, point7_y, 0, 1.0}};

                        Point(17) = {{point7_x+0.005*size_ratio, point7_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point7_x+0.02*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point7_x+0.05*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{point7_x+0.1*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(21) = {{point7_x+0.2*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(22) = {{point7_x+0.2*size_ratio, point7_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(23) = {{0, point7_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) = {{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 21}};
                        //+
                        Line(21) = {{21, 22}};

                        Line(22) = {{22, 23}};  

                        Line(23) = {{23, 1}};               

                        //+
                        Physical Curve("inlet") = {{23}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18,19,20}};
                        //+
                        Physical Curve("outlet") = {{11}};
                        //+
                        Physical Curve("far_field") = {{21, 22}};
                        //+
                        Transfinite Curve {{23}} = {(point7_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {ramp3 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {ramp4 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {ramp5 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{14}} = {((point7_x + 0.1 * size_ratio) - (point7_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{15}} = {((point7_x + 0.05 * size_ratio) - (point7_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{12}} = {((point7_x + 0.6 * size_ratio) - (point7_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{10}} = {((point7_x + 0.6 * size_ratio) - (point7_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{18}} = {((point7_x + 0.05 * size_ratio) - (point7_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{19}} = {((point7_x + 0.1 * size_ratio) - (point7_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{20}} = {((point7_x + 0.2 * size_ratio) - (point7_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{16}} = {((point7_x + 0.005 * size_ratio) - (point7_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point7_x + 0.02 * size_ratio) - (point7_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{11}} = {((point7_y - 0.05 * size_ratio) - (point6_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{21}} = {((point7_y + 0.05 * size_ratio) - (point7_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point6_x + 0.075 * size_ratio) - (point6_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{8}} = {((point6_x + 0.20533 * size_ratio) - (point6_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{22}} = {((point7_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{9}} = {((point6_x + 0.275 * size_ratio) - (point6_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{13}} = {((point7_x + 0.2 * size_ratio) - (point7_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20, 21,22,23}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization


                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18,19,20}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;

                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18,19,20}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features
                        Field[3].DistMin = {(point7_y - point6_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point7_y - point6_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field

                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file



            else:
                raise ValueError("Unsupported ramp_num value. ")

        return determine_geo_file(ramp_num)

    if ml == "Yes":
        def determine_geo_file(ramp_num):
            if ramp_num == "3":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4, point5,
                                    ramp1, ramp2, ramp3,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4
                    point5_x, point5_y = point5

                    mesh_ratio = 1000
                    size_ratio = (point5_x - point1_x) / 0.6

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        point5_x = {point5_x + 0.2:.4f};
                        point5_y = {point5_y:.4f};

                        size_ratio={(point5_x - point1_x) / 0.6:.4f};


                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};
                        //+
                        Point(3) = {{point2_x, point2_y, 0, 1.0}};
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};
                        //+
                        Point(5) = {{point4_x, point4_y, 0, 1.0}};
                        //+
                        Point(6) = {{point4_x+0.085*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(7) = {{point4_x+0.20533*size_ratio, point4_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(8) = {{point4_x+0.275*size_ratio, point4_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(9) = {{point5_x+0.6*size_ratio, point5_y-(((point5_y-point4_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(10) = {{point5_x+0.6*size_ratio, point5_y-(((point5_y-point4_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(11) = {{point5_x+0.2*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(12) = {{point5_x+0.1*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(13) = {{point5_x+0.05*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(14) = {{point5_x+0.005, point5_y, 0, 1.0}};

                        Point(15) = {{(point5_x+0.005*size_ratio)+0.005, point5_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(16) = {{(point5_x+0.02*size_ratio)+0.005, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(17) = {{point5_x+0.05*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point5_x+0.1*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point5_x+0.2*size_ratio, point5_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{point5_x+0.2*size_ratio, point5_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(21) = {{0, point5_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) = {{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 21}};
                        //+
                        Line(21) = {{21, 1}};
                        //+
                        Physical Curve("inlet") = {{21}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18}};
                        //+
                        Physical Curve("outlet") = {{9}};
                        //+
                        Physical Curve("far_field") = {{19, 20}};
                        //+
                        Transfinite Curve {{21}} = {(point5_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {ramp3 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{12}} = {((point5_x + 0.1 * size_ratio) - (point5_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{13}} = {((point5_x + 0.05 * size_ratio) - (point5_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{10}} = {((point5_x + 0.6 * size_ratio) - (point5_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{8}} = {((point5_x + 0.6 * size_ratio) - (point5_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{16}} = {((point5_x + 0.05 * size_ratio) - (point5_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point5_x + 0.1 * size_ratio) - (point5_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{18}} = {((point5_x + 0.2 * size_ratio) - (point5_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{14}} = {((point5_x + 0.005 * size_ratio) - (point5_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{15}} = {((point5_x + 0.02 * size_ratio) - (point5_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{9}} = {((point5_y - 0.05 * size_ratio) - (point4_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{19}} = {((point5_y + 0.05 * size_ratio) - (point5_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {((point4_x + 0.075 * size_ratio) - (point4_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {((point4_x + 0.20533 * size_ratio) - (point4_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{20}} = {((point5_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point4_x + 0.275 * size_ratio) - (point4_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{11}} = {((point5_x + 0.2 * size_ratio) - (point5_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{20, 21, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization

                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;

                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14, 15, 16, 17, 18}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features          
                        Field[3].DistMin = {(point5_y - point4_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point5_y - point4_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field
                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file

            if ramp_num == "2":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4,
                                    ramp1, ramp2,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4

                    mesh_ratio = 1000
                    size_ratio = (point4_x - point1_x) / 0.4

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        size_ratio={(point4_x - point1_x) / 0.4:.4f};

                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};
                        //+
                        Point(3) = {{point2_x, point2_y, 0, 1.0}};
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};
                        //+
                        Point(5) = {{point3_x+0.085*size_ratio, point3_y, 0, 1.0}};
                        //+
                        Point(6) = {{point3_x+0.20533*size_ratio, point3_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(7) = {{point3_x+0.275*size_ratio, point3_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(8) = {{point4_x+0.6*size_ratio, point4_y-(((point4_y-point3_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(9) = {{point4_x+0.6*size_ratio, point4_y-(((point4_y-point3_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(10) = {{point4_x+0.2*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(11) = {{point4_x+0.1*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(12) = {{point4_x+0.05*size_ratio, point4_y, 0, 1.0}};
                        //+
                        Point(13) = {{point4_x+0.005, point4_y, 0, 1.0}};

                        Point(14) = {{(point4_x+0.005*size_ratio)+0.005, point4_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(15) = {{(point4_x+0.02*size_ratio)+0.005, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(16) = {{point4_x+0.05*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(17) = {{point4_x+0.1*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point4_x+0.2*size_ratio, point4_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point4_x+0.2*size_ratio, point4_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{0, point4_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) ={{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 1}};
                        //+
                        Physical Curve("inlet") = {{20}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2,3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 17}};
                        //+
                        Physical Curve("outlet") = {{8}};
                        //+
                        Physical Curve("far_field") = {{18, 19}};
                        //+
                        Transfinite Curve {{20}} = {(point4_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{11}} = {((point4_x + 0.1 * size_ratio) - (point4_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{12}} = {((point4_x + 0.05 * size_ratio) - (point4_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{9}} = {((point4_x + 0.6 * size_ratio) - (point4_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point4_x + 0.6 * size_ratio) - (point4_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{15}} = {((point4_x + 0.05 * size_ratio) - (point4_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{16}} = {((point4_x + 0.1 * size_ratio) - (point4_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point4_x + 0.2 * size_ratio) - (point4_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{13}} = {((point4_x + 0.005 * size_ratio) - (point4_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{14}} = {((point4_x + 0.02 * size_ratio) - (point4_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{8}} = {((point4_y - 0.05 * size_ratio) - (point3_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{18}} = {((point4_y + 0.05 * size_ratio) - (point4_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {((point3_x + 0.075 * size_ratio) - (point3_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {((point3_x + 0.20533 * size_ratio) - (point3_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{19}} = {((point4_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {((point3_x + 0.275 * size_ratio) - (point3_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{10}} = {((point4_x + 0.2 * size_ratio) - (point4_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization

                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;
                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features
                        Field[3].DistMin = {(point4_y - point3_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point4_y - point3_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field
                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file

            if ramp_num == "4":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4, point5, point6,
                                    ramp1, ramp2, ramp3, ramp4,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4
                    point5_x, point5_y = point5
                    point6_x, point6_y = point6

                    mesh_ratio = 1000
                    size_ratio = (point6_x - point1_x) / 0.8

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        point5_x = {point5_x + 0.2:.4f};
                        point5_y = {point5_y:.4f};

                        point6_x = {point6_x + 0.2:.4f};
                        point6_y = {point6_y:.4f};                

                        size_ratio={(point6_x - point1_x) / 0.8:.4f};


                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};

                        Point(3) = {{point2_x, point2_y, 0, 1.0}};                
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};

                        Point(5) = {{point4_x, point4_y, 0, 1.0}};
                        //+
                        Point(6) = {{point5_x, point5_y, 0, 1.0}};

                        //+
                        Point(7) = {{point5_x+0.085*size_ratio, point5_y, 0, 1.0}};
                        //+
                        Point(8) = {{point5_x+0.20533*size_ratio, point5_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(9) = {{point5_x+0.275*size_ratio, point5_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(10) = {{point6_x+0.6*size_ratio, point6_y-(((point6_y-point5_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(11) = {{point6_x+0.6*size_ratio, point6_y-(((point6_y-point5_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(12) = {{point6_x+0.2*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(13) = {{point6_x+0.1*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(14) = {{point6_x+0.05*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(15) = {{point6_x+0.005, point6_y, 0, 1.0}};

                        Point(16) = {{(point6_x+0.005*size_ratio)+0.005, point6_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(17) = {{(point6_x+0.02*size_ratio)+0.005, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{point6_x+0.05*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point6_x+0.1*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{point6_x+0.2*size_ratio, point6_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(21) = {{point6_x+0.2*size_ratio, point6_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(22) = {{0, point6_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) = {{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 21}};
                        //+
                        Line(21) = {{21, 22}};

                        Line(22) = {{22, 1}};               

                        //+
                        Physical Curve("inlet") = {{22}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18,19}};
                        //+
                        Physical Curve("outlet") = {{10}};
                        //+
                        Physical Curve("far_field") = {{20, 21}};
                        //+
                        Transfinite Curve {{22}} = {(point6_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {ramp3 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {ramp4 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{13}} = {((point6_x + 0.1 * size_ratio) - (point6_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{14}} = {((point6_x + 0.05 * size_ratio) - (point6_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{11}} = {((point6_x + 0.6 * size_ratio) - (point6_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{9}} = {((point6_x + 0.6 * size_ratio) - (point6_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point6_x + 0.05 * size_ratio) - (point6_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{18}} = {((point6_x + 0.1 * size_ratio) - (point6_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{19}} = {((point6_x + 0.2 * size_ratio) - (point6_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{15}} = {((point6_x + 0.005 * size_ratio) - (point6_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{16}} = {((point6_x + 0.02 * size_ratio) - (point6_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{10}} = {((point6_y - 0.05 * size_ratio) - (point5_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{20}} = {((point6_y + 0.05 * size_ratio) - (point6_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {((point5_x + 0.075 * size_ratio) - (point5_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point5_x + 0.20533 * size_ratio) - (point5_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{21}} = {((point6_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{8}} = {((point5_x + 0.275 * size_ratio) - (point5_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{12}} = {((point6_x + 0.2 * size_ratio) - (point6_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20, 21,22}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization

                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18,19}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;

                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 11, 12, 13, 14, 15, 16, 17, 18,19}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features
                        Field[3].DistMin = {(point6_y - point5_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point6_y - point5_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field


                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file

            if ramp_num == "5":
                def create_geo_file(name_1, name_2, name_3, name_4,
                                    point1, point2, point3, point4, point5, point6, point7,
                                    ramp1, ramp2, ramp3, ramp4, ramp5,
                                    directory="geo files"):
                    """
                    Create a .geo file with the calculated point coordinates (using the provided code)
                    and then append meshing commands so that Gmsh meshes the file to create a .su2 file.
                    """
                    os.makedirs(directory, exist_ok=True)
                    file_name = f"{name_1}_{name_2}_{name_3}_{name_4}.geo"
                    full_path = os.path.join(directory, file_name)
                    now_str = datetime.now().strftime("%a %b %d %H:%M:%S %Y")

                    # Unpack the point coordinates from the input tuples.
                    point1_x, point1_y = point1
                    point2_x, point2_y = point2
                    point3_x, point3_y = point3
                    point4_x, point4_y = point4
                    point5_x, point5_y = point5
                    point6_x, point6_y = point6
                    point7_x, point7_y = point7

                    mesh_ratio = 1000
                    size_ratio = (point7_x - point1_x) / 1

                    # ----- DO NOT CHANGE THE CODE BELOW -----
                    geo_content = textwrap.dedent(f"""\
                        // Gmsh project created on {now_str}
                        SetFactory("OpenCASCADE");

                        point1_x = {point1_x + 0.2:.4f};
                        point1_y = {point1_y:.4f};

                        point2_x = {point2_x + 0.2:.4f};
                        point2_y = {point2_y:.4f};

                        point3_x = {point3_x + 0.2:.4f};
                        point3_y = {point3_y:.4f};

                        point4_x = {point4_x + 0.2:.4f};
                        point4_y = {point4_y:.4f};

                        point5_x = {point5_x + 0.2:.4f};
                        point5_y = {point5_y:.4f};

                        point6_x = {point6_x + 0.2:.4f};
                        point6_y = {point6_y:.4f};       

                        point7_x = {point7_x + 0.2:.4f};
                        point7_y = {point7_y:.4f};            

                        size_ratio={(point7_x - point1_x) / 1:.4f};


                        //+
                        Point(1) = {{0, 0, 0, 1.0}};
                        //+
                        Point(2) = {{point1_x, point1_y, 0, 1.0}};

                        Point(3) = {{point2_x, point2_y, 0, 1.0}};                
                        //+
                        Point(4) = {{point3_x, point3_y, 0, 1.0}};

                        Point(5) = {{point4_x, point4_y, 0, 1.0}};
                        //+
                        Point(6) = {{point5_x, point5_y, 0, 1.0}};

                        Point(7) = {{point6_x, point6_y, 0, 1.0}};

                        //+
                        Point(8) = {{point6_x+0.085*size_ratio, point6_y, 0, 1.0}};
                        //+
                        Point(9) = {{point6_x+0.20533*size_ratio, point6_y-0.015*size_ratio, 0, 1.0}};
                        //+
                        Point(10) = {{point6_x+0.275*size_ratio, point6_y-0.025*size_ratio, 0, 1.0}};
                        //+
                        Point(11) = {{point7_x+0.6*size_ratio, point7_y-(((point7_y-point6_y)*5.5)/2), 0, 1.0}};
                        //+
                        Point(12) = {{point7_x+0.6*size_ratio, point7_y-(((point7_y-point6_y)*1.5)/2), 0, 1.0}};
                        //+
                        Point(13) = {{point7_x+0.2*size_ratio, point7_y, 0, 1.0}};
                        //+
                        Point(14) = {{point7_x+0.1*size_ratio, point7_y, 0, 1.0}};
                        //+
                        Point(15) = {{point7_x+0.05*size_ratio, point7_y, 0, 1.0}};
                        //+
                        Point(16) = {{point7_x+0.005, point7_y, 0, 1.0}};

                        Point(17) = {{(point7_x+0.005*size_ratio)+0.005, point7_y+0.004*size_ratio, 0, 1.0}};
                        //+
                        Point(18) = {{(point7_x+0.02*size_ratio)+0.005, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(19) = {{point7_x+0.05*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(20) = {{point7_x+0.1*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(21) = {{point7_x+0.2*size_ratio, point7_y+0.008*size_ratio, 0, 1.0}};
                        //+
                        Point(22) = {{point7_x+0.2*size_ratio, point7_y+0.05*size_ratio, 0, 1.0}};
                        //+
                        Point(23) = {{0, point7_y+0.05*size_ratio, 0, 1.0}};

                        //+
                        Line(1) = {{1, 2}};
                        //+
                        Line(2) = {{2, 3}};
                        //+
                        Line(3) = {{3, 4}};
                        //+
                        Line(4) = {{4, 5}};
                        //+
                        Line(5) = {{5, 6}};
                        //+
                        Line(6) = {{6, 7}};
                        //+
                        Line(7) = {{7, 8}};
                        //+
                        Line(8) = {{8, 9}};
                        //+
                        Line(9) = {{9, 10}};
                        //+
                        Line(10) = {{10, 11}};
                        //+
                        Line(11) = {{11, 12}};
                        //+
                        Line(12) = {{12, 13}};
                        //+
                        Line(13) = {{13, 14}};
                        //+
                        Line(14) = {{14, 15}};
                        //+
                        Line(15) = {{15, 16}};
                        //+
                        Line(16) = {{16, 17}};
                        //+
                        Line(17) = {{17, 18}};
                        //+
                        Line(18) = {{18, 19}};
                        //+
                        Line(19) = {{19, 20}};
                        //+
                        Line(20) = {{20, 21}};
                        //+
                        Line(21) = {{21, 22}};

                        Line(22) = {{22, 23}};  

                        Line(23) = {{23, 1}};               

                        //+
                        Physical Curve("inlet") = {{23}};
                        //+
                        Physical Curve("axis") = {{1}};
                        //+
                        Physical Curve("wall") = {{2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18,19,20}};
                        //+
                        Physical Curve("outlet") = {{11}};
                        //+
                        Physical Curve("far_field") = {{21, 22}};
                        //+
                        Transfinite Curve {{23}} = {(point7_y + 0.05 * size_ratio) * mesh_ratio * 0.33:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{1}} = 151 Using Progression 1;
                        //+
                        Transfinite Curve {{2}} = {ramp1 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{3}} = {ramp2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{4}} = {ramp3 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{5}} = {ramp4 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{6}} = {ramp5 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{14}} = {((point7_x + 0.1 * size_ratio) - (point7_x + 0.05 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{15}} = {((point7_x + 0.05 * size_ratio) - (point7_x)) * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{12}} = {((point7_x + 0.6 * size_ratio) - (point7_x + 0.2 * size_ratio)) * 0.63 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{10}} = {((point7_x + 0.6 * size_ratio) - (point7_x + 0.275 * size_ratio)) * 0.84 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{18}} = {((point7_x + 0.05 * size_ratio) - (point7_x + 0.02 * size_ratio)) * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{19}} = {((point7_x + 0.1 * size_ratio) - (point7_x + 0.05 * size_ratio)) * 0.62 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{20}} = {((point7_x + 0.2 * size_ratio) - (point7_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{16}} = {((point7_x + 0.005 * size_ratio) - (point7_x)) * 2.2 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{17}} = {((point7_x + 0.02 * size_ratio) - (point7_x + 0.005 * size_ratio)) * 0.74 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{11}} = {((point7_y - 0.05 * size_ratio) - (point6_y - 0.115 * size_ratio)) * 2.38 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{21}} = {((point7_y + 0.05 * size_ratio) - (point7_y + 0.008 * size_ratio)) * 1.46 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{7}} = {((point6_x + 0.075 * size_ratio) - (point6_x)) * 1.35 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{8}} = {((point6_x + 0.20533 * size_ratio) - (point6_x + 0.075 * size_ratio)) * 0.77 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Transfinite Curve {{22}} = {((point7_x + 0.2 + (0.2 * size_ratio))) * 0.16 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{9}} = {((point6_x + 0.275 * size_ratio) - (point6_x + 0.20533 * size_ratio)) * 0.73 * mesh_ratio:.0f} Using Progression 1;
                        Transfinite Curve {{13}} = {((point7_x + 0.2 * size_ratio) - (point7_x + 0.1 * size_ratio)) * 0.51 * mesh_ratio:.0f} Using Progression 1;
                        //+
                        Curve Loop(1) = {{ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19,20, 21,22,23}};
                        //+
                        Plane Surface(1) = {{1}};

                        // --- Global Mesh Options ---
                        Mesh.Smoothing = 10;  // Apply 10 smoothing iterations
                        Mesh.Optimize = 1;      // Enable basic mesh optimization


                        Field[1] = BoundaryLayer;
                        Field[1].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18,19,20}};
                        Field[1].hwall_n = 0.0001;
                        Field[1].thickness = 0.001;
                        Field[1].hfar = 0.008;
                        Field[1].ratio = 1.2;
                        Field[1].IntersectMetrics = 0;
                        Field[1].Quads = 1;
                        BoundaryLayer Field = 1;

                        // Define the Background Mesh Size Field using a Distance field for key features
                        Field[2] = Distance;
                        Field[2].EdgesList = {{2, 3, 4, 5, 6, 7, 8, 9, 10, 12, 13, 14, 15, 16, 17, 18,19,20}}; // specify the curves near critical features

                        // Use a Threshold field to vary the mesh size based on the distance from Field[2]
                        Field[3] = Threshold;
                        Field[3].IField = 2;       // Use the distance from Field[2]
                        Field[3].LcMin = 0.0015;   // Fine mesh size near key features
                        Field[3].LcMax = 0.008;    // Coarse mesh size far from key features
                        Field[3].DistMin = {(point7_y - point6_y) / 4};   // Below this distance, use LcMin
                        Field[3].DistMax = {(point7_y - point6_y) / 2};   // Above this distance, use LcMax

                        // 7. Combine All Fields Using the Min Operator
                        Field[4] = Min;
                        Field[4].FieldsList = {{1, 3}}; // take the smallest mesh size computed by these fields
                        Background Field = 4;  // Set Field[7] as the background mesh size field

                        """)

                    # Append meshing directives
                    meshing_commands = textwrap.dedent("""\
                        // --- Additional meshing directives ---
                        Physical Surface("domain") = {1};
                        """)

                    geo_content += meshing_commands

                    with open(full_path, "w") as file:
                        file.write(geo_content)
                    print(f".geo file created: {full_path}")

                    # Mesh the .geo file to create the corresponding .su2 file.
                    convert_geo_to_su2(full_path, dimension=2)

                return create_geo_file



            else:
                raise ValueError("Unsupported ramp_num value. ")

        return determine_geo_file(ramp_num)
    else:
        raise ValueError("Unsupported answer.")

