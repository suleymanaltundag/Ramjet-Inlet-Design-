import math


def po2p1_normal_shock(Mach, gamma):
    """
    Computes the total-to-static pressure ratio (p0/p1) across a normal shock.
    """
    factor = ((gamma + 1.0) ** 2 * Mach ** 2) / (4.0 * gamma * Mach ** 2 - 2.0 * (gamma - 1.0))
    return ((gamma + 1.0) / 2.0) * Mach ** 2 * (factor ** (1.0 / (gamma - 1.0)))


def po2po1_normal_shock(Mach, gamma):
    """
    Computes the total-to-total pressure ratio (p0_2/p0_1) across a normal shock.
    """
    A = ((gamma + 1.0) / 2.0 * Mach ** 2) / (1.0 + (gamma - 1.0) / 2.0 * Mach ** 2)
    power1 = gamma / (gamma - 1.0)
    B = 1.0 / ((2.0 * gamma * Mach ** 2 / (gamma + 1.0)) - ((gamma - 1.0) / (gamma + 1.0)))
    power2 = 1.0 / (gamma - 1.0)
    return A ** power1 * B ** power2


def po2p1_iterate(po2p1, gamma):
    """
    Finds Mach number from a given total-to-static pressure ratio (p0/p1)
    using a Newton–Raphson iteration.
    """
    Mach = 2.0
    residual = 1e9
    dM = 0.001
    while residual > 1e-8:
        FM = po2p1_normal_shock(Mach, gamma) - po2p1
        dFdM = (po2p1_normal_shock(Mach + dM, gamma) - po2p1_normal_shock(Mach - dM, gamma)) / (2.0 * dM)
        Mach_new = Mach - FM / dFdM
        residual = abs(Mach_new - Mach)
        # Uncomment the next line to see the residual for debugging:
        # print(f"po2p1_iterate: residual = {residual}")
        Mach = Mach_new
    return Mach


def po2po1_iterate(po2po1, gamma):
    """
    Finds Mach number from a given total-to-total pressure ratio (p0_2/p0_1)
    using a Newton–Raphson iteration.
    """
    Mach = 2.0
    residual = 1e9
    dM = 0.001
    while residual > 1e-8:
        FM = po2po1_normal_shock(Mach, gamma) - po2po1
        dFdM = (po2po1_normal_shock(Mach + dM, gamma) - po2po1_normal_shock(Mach - dM, gamma)) / (2.0 * dM)
        Mach_new = Mach - FM / dFdM
        residual = abs(Mach_new - Mach)
        # Uncomment the next line to see the residual for debugging:
        # print(f"po2po1_iterate: residual = {residual}")
        Mach = Mach_new
    return Mach


def M2_normal_shock(M1, gamma):
    """
    Returns the downstream Mach number (M2) for a normal shock.
    """
    temp = (gamma - 1.0) / (gamma + 1.0)
    return math.sqrt((temp * M1 ** 2 + (1.0 - temp)) / ((1.0 + temp) * M1 ** 2 - temp))


def T2T1_normal_shock(M1, gamma):
    """
    Returns the static temperature ratio (T2/T1) across a normal shock.
    The formula is rearranged from the normal shock relations.
    """
    numerator = (1.0 + (gamma - 1.0) / 2.0 * M1 ** 2) * ((2.0 * gamma / (gamma - 1.0) * M1 ** 2) - 1.0)
    denominator = ((gamma + 1.0) ** 2) / (2.0 * (gamma - 1.0))
    return numerator / denominator / (M1 ** 2)


def normal_shock_calculator(gamma=1.4, M1_input=None, M2_input=None, T2T1_input=None,
                            p2p1_input=None, rho2rho1_input=None, u2u1_input=None,
                            po2po1_input=None, po2p1_input=None):
    """
    Calculates normal shock properties.

    The function tries to determine M1 from any one of the provided parameters,
    using the following (override) order:
      1. If M2 is provided.
      2. If po2po1 (total-to-total pressure ratio) is provided.
      3. If p2p1 (static pressure ratio) is provided.
      4. If T2T1 (static temperature ratio) is provided.
      5. If rho2rho1 (density ratio) is provided.
      6. If u2u1 (velocity ratio) is provided.
      7. If po2p1 (total-to-static pressure ratio) is provided.
      8. Otherwise, M1 is assumed to be provided.

    After determining M1, the remaining properties are computed.
    Returns a dictionary with the computed values.
    """
    # Convert gamma to float (if not already) and ensure a default.
    gamma = float(gamma)
    temp = (gamma - 1.0) / (gamma + 1.0)
    M1 = None

    # The order here follows the JavaScript code:
    if M2_input is not None:
        M2 = float(M2_input)
        M1 = math.sqrt((temp * M2 ** 2 + (1.0 - temp)) / ((1.0 + temp) * M2 ** 2 - temp))
    if po2po1_input is not None:
        M1 = po2po1_iterate(float(po2po1_input), gamma)
    if p2p1_input is not None:
        M1 = math.sqrt((float(p2p1_input) + temp) / (1.0 + temp))
    if T2T1_input is not None:
        T2T1_val = float(T2T1_input)
        # The following expression is taken directly from your code.
        B = ((-gamma ** 2 + 6.0 * gamma - 1.0) / (2.0 * gamma - 2.0)) - (
                    ((gamma + 1.0) ** 2) / (2.0 * (gamma - 1.0)) * T2T1_val)
        M1 = math.sqrt((-B + math.sqrt(B ** 2 + 4.0 * gamma)) / (2.0 * gamma))
    if rho2rho1_input is not None:
        rho_ratio = float(rho2rho1_input)
        M1 = math.sqrt((1.0 - temp) * rho_ratio / (1.0 - temp * rho_ratio))
    if u2u1_input is not None:
        u_ratio = float(u2u1_input)
        M1 = math.sqrt((1.0 - temp) * (1.0 / u_ratio) / (1.0 - temp * (1.0 / u_ratio)))
    if po2p1_input is not None:
        M1 = po2p1_iterate(float(po2p1_input), gamma)
    if M1 is None and M1_input is not None:
        M1 = float(M1_input)

    # If still no M1 could be determined, report an error.
    if M1 is None:
        raise ValueError("Insufficient input: you must provide at least one known ratio or M1.")

    # Now compute the other properties from M1.
    M2 = M2_normal_shock(M1, gamma)
    T2T1 = T2T1_normal_shock(M1, gamma)
    p2p1 = (1.0 + temp) * M1 ** 2 - temp
    rho2rho1 = M1 ** 2 / (temp * M1 ** 2 + (1.0 - temp))
    u2u1 = 1.0 / rho2rho1
    po2po1 = po2po1_normal_shock(M1, gamma)
    po2p1 = po2p1_normal_shock(M1, gamma)

    return {
        "gamma": gamma,
        "M1": M1,
        "M2": M2,
        "T2T1": T2T1,
        "p2p1": p2p1,
        "rho2rho1": rho2rho1,
        "u2u1": u2u1,
        "po2po1": po2po1,
        "po2p1": po2p1
    }


def get_float_input(prompt):
    """
    Prompts the user for input and returns a float or None if left blank.
    """
    value = input(prompt)
    if value.strip() == "":
        return None
    try:
        return float(value)
    except ValueError:
        print("Invalid input. Ignoring this parameter.")
        return None


def main():
    print("Normal Shock Calculator")
    print("------------------------")

    # Prompt the user for gamma (default is 1.4)
    gamma_input = input("Enter gamma (specific heat ratio) [default = 1.4]: ")
    if gamma_input.strip() == "":
        gamma = 1.4
    else:
        try:
            gamma = float(gamma_input)
        except ValueError:
            print("Invalid input. Using default gamma = 1.4.")
            gamma = 1.4

    # Prompt the user for known shock quantities.
    print("Enter the known value(s). Leave blank if unknown.")
    M1_input = get_float_input("Upstream Mach number, M1: ")
    M2_input = get_float_input("Downstream Mach number, M2: ")
    T2T1_input = get_float_input("Static Temperature Ratio, T2/T1: ")
    p2p1_input = get_float_input("Static Pressure Ratio, p2/p1: ")
    rho2rho1_input = get_float_input("Density Ratio, ρ2/ρ1: ")
    u2u1_input = get_float_input("Velocity Ratio, u2/u1: ")
    po2po1_input = get_float_input("Total-to-Total Pressure Ratio, p0_2/p0_1: ")
    po2p1_input = get_float_input("Total-to-Static Pressure Ratio, p0/p1: ")

    try:
        results = normal_shock_calculator(
            gamma=gamma,
            M1_input=M1_input,
            M2_input=M2_input,
            T2T1_input=T2T1_input,
            p2p1_input=p2p1_input,
            rho2rho1_input=rho2rho1_input,
            u2u1_input=u2u1_input,
            po2po1_input=po2po1_input,
            po2p1_input=po2p1_input
        )
    except ValueError as e:
        print(e)
        return

    # Display the results.
    print("\nComputed Normal Shock Parameters:")
    print(f"  Gamma               = {results['gamma']}")
    print(f"  Upstream Mach (M1)  = {results['M1']}")
    print(f"  Downstream Mach (M2)= {results['M2']}")
    print(f"  Temperature Ratio (T2/T1) = {results['T2T1']}")
    print(f"  Static Pressure Ratio (p2/p1) = {results['p2p1']}")
    print(f"  Density Ratio (ρ2/ρ1) = {results['rho2rho1']}")
    print(f"  Velocity Ratio (u2/u1) = {results['u2u1']}")
    print(f"  Total-to-Total Pressure Ratio (p0_2/p0_1) = {results['po2po1']}")
    print(f"  Total-to-Static Pressure Ratio (p0/p1) = {results['po2p1']}")


if __name__ == "__main__":
    main()
